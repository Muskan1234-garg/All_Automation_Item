package rmaseleniumPOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//Default Package Import Completed

public class RMA_POM_Comments {
	public static WebElement Element = null;

	//============================================================================================
	//FunctionName 			: RMAApp_Comments_Txt_TextEditor
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which TextEditor On RMA Comments Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-08-01-2016                                 
	//============================================================================================
	public static WebElement RMAApp_Comments_Txt_TextEditor(WebDriver driver)
	{
		Element = driver.findElement(By.xpath("//html/body")); 
		return Element;
	}
	
	//============================================================================================
		//FunctionName 			: RMAApp_Comments_Btn_SaveAndClose
		//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which SaveAndClose Button On RMA Comments Page Can Be Identified
		//Input Parameter 		: Driver Variable Of The Type WebDriver		 
		//Revision				: 0.0 - ImteyazAhmad-08-01-2016                                 
		//============================================================================================
		public static WebElement RMAApp_Comments_Btn_SaveAndClose(WebDriver driver)
		{
			Element = driver.findElement(By.id("btnSaveClose")); 
			return Element;
		}
}