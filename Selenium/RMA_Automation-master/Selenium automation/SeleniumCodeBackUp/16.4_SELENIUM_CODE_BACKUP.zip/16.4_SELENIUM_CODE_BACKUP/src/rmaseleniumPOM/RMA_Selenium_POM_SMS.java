package rmaseleniumPOM;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_Selenium_POM_SMS {
	public static WebElement Element = null;
	public static List<WebElement> ElementList = null;
	
//============================================================================================
//FunctionName 			: RMAApp_SMS_Btn_AddNewDS
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Add New Data Source Button On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
// ============================================================================================
public static WebElement RMAApp_SMS_Btn_AddNewDS(WebDriver driver)
{
	Element = driver.findElement(By.id("btn_addnewds")); //Unique Id Of Add New Data Source Button On RMA Application Security Management System Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Rdb_DBDriver
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which DBDriver RadioButton option On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Rdb_DBDriver(WebDriver driver,String DriverName)
{
	Element = driver.findElement(By.xpath(".//*[@id='dropzone']//*[text()='"+DriverName+"']/input")); //Unique xpath Of DBDriver RadioButton option On RMA Application Security Management System Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Btn_Next
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Next Button On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Btn_Next(WebDriver driver)
{
	Element = driver.findElement(By.id("btn_next")); //Unique Id Of Next Button On RMA Application Security Management System Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Txt_ServerName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Server Name textBox On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Txt_ServerName(WebDriver driver)
{
	Element = driver.findElement(By.id("txt_srevername")); //Unique Id Of Server Name textBox On RMA Application Security Management System Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Txt_DatabaseName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Database Name TextBox On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Txt_DatabaseName(WebDriver driver)
{
	Element = driver.findElement(By.id("txt_dbname")); //Unique Id Of Database Name TextBox On RMA Application Security Management System Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Txt_LoginUserName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Login User Name TextBox On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Txt_LoginUserName(WebDriver driver)
{
	Element = driver.findElement(By.id("txt_login_name")); //Unique Id Of Login User Name TextBox On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Txt_LoginPassword
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Login Password TextBox TextBox On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Txt_LoginPassword(WebDriver driver)
{
	Element = driver.findElement(By.id("txt_pwd")); //Unique Id Of Login Password TextBox On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Txt_UniqueDBConnName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which unique name for this database connection TextBox TextBox On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Txt_UniqueDBConnName(WebDriver driver)
{
	Element = driver.findElement(By.id("txt_uniquename")); //Unique Id Of unique name for this database connection TextBox On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Txt_ActivationCode
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which code provided by the product support to activate licenses TextBox On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Txt_ActivationCode(WebDriver driver)
{
	Element = driver.findElement(By.id("txt_code")); //Unique Id Of code provided by the product support to activate licenses TextBox On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMS_Lnk_LeftMenuLinkName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Left Menu Link Nam On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMS_Lnk_LeftMenuLinkName(WebDriver driver,String LinkName)
{
	WebElement Element = null;
	try {
		Element = driver.findElement(By.xpath(".//*[@id='"+LinkName+"']")); //Unique xpath Of Left Menu Link Name On RMA Application Security Management System Page Is Fetched
	} catch (Exception|Error e) {	
	}
	return Element;	
}
//============================================================================================
//FunctionName 			: RMAApp_SMS_Img_ExpandCollapseLeftMenuLink
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Left Menu Link Nam On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMS_Img_ExpandCollapseLeftMenuLink(WebDriver driver,String LinkName)
{
	WebElement Element = null;
	try {
		Element = driver.findElement(By.xpath(".//*[@id='"+LinkName+"']/preceding::i[2]")); //Unique xpath Of Left Menu Link Name On RMA Application Security Management System Page Is Fetched
	} catch (Exception|Error e) {	
	}
	return Element;	
}
//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Lbl_Step4Message
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Left Menu Link Nam On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Lbl_Step4Message(WebDriver driver)
{
	Element = driver.findElement(By.xpath(".//*[@id='dropzone']//*[@class='success']")); //Unique xpath Of Left Menu Link Name On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMSAddNewDS_Lbl_Step3Message
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Left Menu Link Name On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSAddNewDS_Lbl_Step3Message(WebDriver driver)
{
	Element = driver.findElement(By.xpath(".//*[@id='dropzone']//*[text()='Database Connection Wizard will now try to connect and validate the database you have selected Please click Next to start the connection and validation process.']")); //Unique xpath Of Left Menu Link Name On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMS_Btn_Delete
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Delete Button On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMS_Btn_Delete(WebDriver driver)
{
	Element = driver.findElement(By.id("btn_delete")); //Unique id Of Delete Button On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMSDelete_Btn_Delete
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Delete Button On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSDelete_Btn_Delete(WebDriver driver)
{
	Element = driver.findElement(By.id("btn_del")); //Unique id Of Delete Button On RMA Application Security Management System Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_SMSDelete_Btn_Cancel
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Delete Button On RMA Application Security Management System Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-12-26-2016                               
//============================================================================================
public static WebElement RMAApp_SMSDelete_Btn_Cancel(WebDriver driver)
{
	Element = driver.findElement(By.id("btn_cancel")); //Unique id Of Delete Button On RMA Application Security Management System Page Is Fetched
	return Element;
}
}