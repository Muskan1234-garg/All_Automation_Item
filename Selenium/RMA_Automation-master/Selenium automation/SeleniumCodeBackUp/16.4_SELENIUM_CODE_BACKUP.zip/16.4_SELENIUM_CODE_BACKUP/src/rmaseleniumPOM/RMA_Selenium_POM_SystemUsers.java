package rmaseleniumPOM;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_Selenium_POM_SystemUsers {
	public static WebElement Element = null;
	public static List<WebElement> ElementList = null;
	
//============================================================================================
//FunctionName 			: RMAApp_SystemUsers_Txt_FirstName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which FirstName Text Box On RMA Application System Users Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-11-17-2016                                 
// ============================================================================================
public static WebElement RMAApp_SystemUsers_Txt_FirstName(WebDriver driver)
{
	Element = driver.findElement(By.id("firstname")); //Unique Id Of FirstName Text Box On RMA Application System Users Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SystemUsers_Txt_LastName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which LastName Text Box On RMA Application System Users Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-11-17-2016                                 
//============================================================================================
public static WebElement RMAApp_SystemUsers_Txt_LastName(WebDriver driver)
{
	Element = driver.findElement(By.id("lastname")); //Unique Id Of LastName Text Box On RMA Application System Users Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SystemUsers_Lst_UserGroups
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which User Groups WebList On RMA Application System Users Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-11-17-2016                                 
//============================================================================================
public static WebElement RMAApp_SystemUsers_Lst_UserGroups(WebDriver driver)
{
	Element = driver.findElement(By.id("lstUserGroups")); //Unique Id Of User Groups WebList On RMA Application System Users Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SystemUsers_Table_SystemUser
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which System User Table On RMA Application System Users Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-11-17-2016                                 
//============================================================================================
public static WebElement RMAApp_SystemUsers_Table_SystemUser(WebDriver driver)
{
	Element = driver.findElement(By.id("gvUserList")); //Unique Id Of System User Table On RMA Application System Users Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SystemUsers_Generic_BtnName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Button On RMA Application System Users Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-11-17-2016                                 
//============================================================================================
public static WebElement RMAApp_SystemUsers_Generic_BtnName(WebDriver driver,String ButtonName)
{
	Element = driver.findElement(By.xpath(".//*[@value='"+ButtonName+"']")); //Unique xpath Of Button On RMA Application System Users Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_SystemUsers_Generic_RadioOption
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which RadioButton On RMA Application System Users Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - RenuVerma-11-17-2016                                 
//============================================================================================
public static WebElement RMAApp_SystemUsers_Generic_RadioOption(WebDriver driver,String RadioOption)
{
	Element = driver.findElement(By.id("rd"+RadioOption)); //Unique Id Of RadioButton On RMA Application System Users Page Is Fetched
	return Element;
}

}