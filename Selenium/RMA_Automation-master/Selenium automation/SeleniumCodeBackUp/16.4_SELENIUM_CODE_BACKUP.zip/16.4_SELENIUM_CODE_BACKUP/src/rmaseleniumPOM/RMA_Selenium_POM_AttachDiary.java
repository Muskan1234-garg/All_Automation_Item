package rmaseleniumPOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//Default Package Import Completed

public class RMA_Selenium_POM_AttachDiary {
	public static WebElement Element = null;

	//============================================================================================
	//FunctionName 			: RMAApp_AttachDiary_Btn_WorkActivities
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which WorkActivities Lookup Button On RMA Diary Attach Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-07-25-2016                                 
	//============================================================================================
	public static WebElement RMAApp_AttachDiary_Btn_WorkActivitiesLookup(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@id='AddActivity']")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_AttachDiary_Btn_WorkActivities
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Activity List On RMA Create Diary Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-07-25-2016                                 
	//============================================================================================
	public static WebElement RMAApp_AttachDiary_Lst_Activity(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@id='lstActivity']")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_AttachDiary_Txt_Activity
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Activity TextBox On RMA Create Diary Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-07-25-2016                                 
	//============================================================================================
	public static WebElement RMAApp_AttachDiary_Txt_Activity(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@id='txtActivity']")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_AttachDiary_Btn_Ok
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Ok Button On RMA Create Diary Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-07-25-2016                                 
	//============================================================================================
	public static WebElement RMAApp_AttachDiary_Btn_Ok(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@id='btnOk']"));
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_AttachDiary_Txt_TaskName
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which TaskName TextBox On RMA Attach Diary Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-07-25-2016                                 
	//============================================================================================
	public static WebElement RMAApp_AttachDiary_Txt_TaskName(WebDriver driver)
	{
		Element = driver.findElement(By.xpath(".//*[@id='EntryName']")); 
		return Element;
	}
	
}