package rmaseleniumPOM;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_POM_SMS {

	public static WebElement Element = null;

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Frm_ToolBarFrame
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which ToolBar Frame On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                
	// ============================================================================================

	public static WebElement RMAApp_SMS_Frm_ToolBarFrame(WebDriver driver)
	{
		Element = driver.findElement(By.id("ToolBar")); 
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Frm_LeftTreeFrame
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which LeftTree Frame On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                               
	// ============================================================================================

	public static WebElement RMAApp_SMS_Frm_LeftTreeFrame(WebDriver driver)
	{
		Element = driver.findElement(By.id("LeftTree")); 
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Frm_MainFrame
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Main Frame On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                
	// ============================================================================================

	public static WebElement RMAApp_SMS_Frm_MainFrame(WebDriver driver)
	{
		Element = driver.findElement(By.id("MainFrame")); 
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Img_AddNewUser
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Add New User Image On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                
	// ============================================================================================

	public static WebElement RMAApp_SMS_Img_AddNewUser(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnAddUser")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Txt_LastName
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which LastName TextBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                
	// ============================================================================================

	public static WebElement RMAApp_SMS_Txt_LastName(WebDriver driver)
	{
		Element = driver.findElement(By.id("lastname")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Txt_FirstName
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which FirstName TextBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Txt_FirstName(WebDriver driver)
	{
		Element = driver.findElement(By.id("firstname")); 
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Txt_Email
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Email TextBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Txt_Email(WebDriver driver)
	{
		Element = driver.findElement(By.id("email")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Lst_Manager
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Manager ListBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Lst_Manager(WebDriver driver)
	{
		Element = driver.findElement(By.id("manager")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Chk_PermitAccessToSMS
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Permit Access To SMS CheckBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Chk_PermitAccessToSMS(WebDriver driver)
	{
		Element = driver.findElement(By.id("SMSAccess")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Chk_PermitAccessToUserPrivilegesSetup
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Permit Access To User Privileges Setup CheckBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Chk_PermitAccessToUserPrivilegesSetup(WebDriver driver)
	{
		Element = driver.findElement(By.id("UserPrAccess")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Lst_DataSources
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which DataSources List On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Lst_DataSources(WebDriver driver)
	{
		Element = driver.findElement(By.id("lstDatasources")); 
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Img_Save
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Save Image On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Img_Save(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnSave")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Txt_LoginName
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which LoginName TextBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Txt_LoginName(WebDriver driver)
	{
		Element = driver.findElement(By.id("loginname")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Txt_Password
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Password TextBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Txt_Password(WebDriver driver)
	{
		Element = driver.findElement(By.id("password")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Lst_ModuleGroup
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which ModuleGroup List On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Lst_ModuleGroup(WebDriver driver)
	{
		Element = driver.findElement(By.id("lstModuleGroups")); 
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Img_ExpandCollapse
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Expand/Collapse Image On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Img_ExpandCollapse(WebDriver driver, String PartialText)
	{
		Element = driver.findElement(By.xpath("//a[contains(text(),'"+PartialText+"')]/preceding::a[1]"));		
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Img_Delete
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Delete Image On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Img_Delete(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnDelete"));		
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Img_AddNewModuleGroup
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which AddNewModuleGroup Image On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Img_AddNewModuleGroup(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnAddModule"));			
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMSModuleGrp_Txt_GroupName
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which GroupName TextBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMSModuleGrp_Txt_GroupName(WebDriver driver)
	{
		Element = driver.findElement(By.id("groupname"));			
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMSModuleGrp_Btn_OK
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which GroupName TextBox On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMSModuleGrp_Btn_OK(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnOk"));			
		return Element;
	}
	//============================================================================================
	//FunctionName 			: RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which GrantPermissionToSelectedAndSubModule Image On RMA Application SMS Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
	// ============================================================================================

	public static WebElement RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnAssignPermissions"));			
		return Element;
	}
	//============================================================================================
		//FunctionName 			: RMAApp_SMS_Img_ExpandCollapseModulesecurityGroup
		//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which GrantPermissionToSelectedAndSubModule Image On RMA Application SMS Page Can Be Identified
		//Input Parameter 		: Driver Variable Of The Type WebDriver		 
		//Revision				: 0.0 - ImteyazAhmad-02-22-2016                                 
		// ============================================================================================

	public static WebElement RMAApp_SMS_Img_ExpandCollapseModulesecurityGroup(WebDriver driver, String PartialText)
	{
		Element = driver.findElement(By.xpath("//a[contains(text(),'"+PartialText+"')]/following::div/table[2]/tbody/tr/td[4]/a"));		
		return Element;
	}
	//============================================================================================
			//FunctionName 			: RMAApp_SMS_Lnk_UserNameUnderModuleGroup
			//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which GrantPermissionToSelectedAndSubModule Image On RMA Application SMS Page Can Be Identified
			//Input Parameter 		: Driver Variable Of The Type WebDriver		 
			//Revision				: 0.0 - ImteyazAhmad-02-29-2016                                 
			// ============================================================================================

		public static WebElement RMAApp_SMS_Lnk_UserNameUnderModuleGroup(WebDriver driver, String PartialText)
		{
			Element = driver.findElement(By.xpath("//a[contains(text(),'"+PartialText+"')]/following::div/table/tbody/tr/td[7]/a"));		
			return Element;
		}
	

}