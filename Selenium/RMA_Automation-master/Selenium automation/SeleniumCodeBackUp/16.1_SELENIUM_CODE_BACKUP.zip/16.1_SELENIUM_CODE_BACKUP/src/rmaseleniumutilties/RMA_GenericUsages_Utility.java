package rmaseleniumutilties;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;
//import org.openqa.selenium.support.ui.ExpectedConditions;
import com.relevantcodes.extentreports.LogStatus;
import javax.swing.JLabel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
//RMA Package Import Completed


public class RMA_GenericUsages_Utility extends rmaseleniumtestscripts.RMA_TC_BaseTest{
	static int IntRandomNum;
	static String StrGeneratedUCaseRandomString;
	static String StrAlertMessage;
	static RMA_GenericUsages_Utility color = new RMA_GenericUsages_Utility();
	static JLabel label = new JLabel(); //Created JLabel instance

	//============================================================================================
	//FunctionName 		: RMA_CurrentDateInfo_Utility
	//Description  		: To Retrieve The Current System Date in "yyyyMMdd"
	//Input Parameter 	: None 
	//Revision			: 0.0 - KumudNaithani-10-21-2015                                 
	// ============================================================================================
	public static String RMA_CurrentDateInfo_Utility() throws Exception,Error
	{
		String Strdated = null;
		try
		{
			DateFormat dateformat = new SimpleDateFormat("yyyyMMdd"); //Date Format Is Defined
			Date date = new Date();
			Strdated = dateformat.format(date); //Retrieved Date Is Formatted

		}catch(Exception|Error e)
		{
			System.out.println("Following Error Occurred While Generating Current Date : " +" " +e.getMessage());
			throw(e);
		}
		return Strdated;
	}

	//============================================================================================
	//FunctionName 		: RMA_CurrentTimeInfo_Utility
	//Description  		: To Retrieve The Current System Time in "hhmmss" format 
	//Input Parameter 	: None 
	//Revision			: 0.0 - KumudNaithani-10-22-2015                                 
	//============================================================================================
	public static String RMA_CurrentTimeInfo_Utility() throws Exception,Error
	{
		String Strdated = null;
		try
		{
			DateFormat dateformat = new SimpleDateFormat("hhmmss"); //Date Format Is Defined
			Date date = new Date();
			Strdated = dateformat.format(date); //Retrieved Date Is Formatted
		}catch(Exception|Error e)
		{
			System.out.println("Following Error Occurred While Generating Current Time : " +" " +e.getMessage());
			throw(e);
		}
		return Strdated;
	}

	//============================================================================================
	//FunctionName 		: RMA_WindowsMessageHandler_Utility
	//Description  		: Handles Any Type Of Windows Pop Up And Accepts Or Rejects The Same (Say Clicking On Yes Or No Button) 
	//Input Parameter 	: Instance Of The WebDriver Class 'Driver' And Value Of The String 'StrAccept'
	////Revision		: 0.1 - KumudNaithani-12-17-2015 - Added try catch specific to NoAlertPresentException exception
	//					: 0.0 - KumudNaithani-10-20-2015                                  
	//============================================================================================
	public static void RMA_WindowsMessageHandler_Utility(WebDriver driver, String StrAccept)throws Exception, Error
	{
		Alert alert;
		try {
			alert = driver.switchTo().alert(); // A Switch To The Displayed Alert Message Is Done
			if (StrAccept == "Yes") // If The User Chooses To Accept The Alert That Is The Positive Option Say "Yes", "OK" Or "Leave The Page" Then Alert Window Is Accepted And Desired Action Is Done Like Refereshing The Page
			{
				//Thread.sleep(10000);
				alert.accept(); 
				Thread.sleep(15000);		
			}
			else
			{
				alert.dismiss(); // If The User Chooses To Decline The Alert That Is The Negative Option Say "No", "Cancel" Or "Stay On The Page" Then Alert Window Is Dismissed And Desired Action Is Done Like Staying On The Page
			} 
		}
		catch (NoAlertPresentException ex)
		{
			//Following Catch Has Been Added To Handle The Scenario Where Existence Of The Window's Pop Up Depends On The Application Behavior (Scenario Executed Before Function Call)
		}
		catch (Exception|Error e) 
		{
			System.out.println("Exception Occurred While Handling The Windows PopUp" + e.getMessage()); //Try Catch Statement Is Used To Handle Any Type Of Unhandled Exception And Print Log Of It
			throw (e);
		}

	}

	//============================================================================================
	//FunctionName 		: RMA_RandomIntGeneration_Utility
	//Description  		: To Generate A Random Number Based On The Maximum And Minimum Integer Limit Provided
	//Input Parameter 	: IntMinRange, IntMaxRange Of The Type Integer To Specify The Range Of The Generated Random Number
	//Revision			: 0.0 - KumudNaithani-11-02-2015                                 
	//============================================================================================
	public static int RMA_RandomIntGeneration_Utility(int IntMinRange, int IntMaxRange) throws Exception, Error
	{
		// To Concatenate The Return Value To A Fixed Desired Starting Value User Needs To Call This Function Store The Value In A Variable And Then Concatenate Using + Operator
		try 
		{
			Random rand = new Random();
			IntRandomNum = rand.nextInt((IntMaxRange - IntMinRange) + 1) + IntMinRange; // Since nextInt Is Exclusive Of The Maximum Value So 1 Is Added To Make It Inclusive	
		} catch (Exception|Error e) {
			System.out.println("Random Number Was Not Generated As" + e.getMessage()); //Try Catch Statement Is Used To Handle Any Type Of Exception And Print Log Of It
			throw (e);
		}
		return IntRandomNum;
	}

	//============================================================================================
	//FunctionName 		: RMA_RandomStringGeneration_Utility
	//Description  		: To Generate A Random String
	//Input Parameter 	: IntStringLength Of The Type Integer Which Specifies Character Length Of The Generated Random String, AppendString Of Type String Which Is Appended To The Generated Random String
	//Revision			: 0.1 - KumudNaithani-12-17-2015 - Added Code To Append Any String Provided By The User To The Generated Random String
	//					: 0.0 - KumudNaithani-11-02-2015
	//============================================================================================
	public static String RMA_RandomStringGeneration_Utility(int IntStringLength, String AppendString) throws Exception, Error
	{	
		//To Concatenate The Return Value To A Fixed Desired Starting Value User Needs To Call This Function Store The Value In A Variable And Then Concatenate Using + Operator
		try
		{
			String GeneratedRandomString = RandomStringUtils.random(IntStringLength, true, false);
			StrGeneratedUCaseRandomString = GeneratedRandomString.toUpperCase();
			StrGeneratedUCaseRandomString = AppendString + StrGeneratedUCaseRandomString; //Final Value Of Address 1 After Random String Append Is Fetched
		} catch (Exception|Error e) {
			System.out.println("Random String Was Not Generated As" + e.getMessage()); //Try Catch Statement Is Used To Handle Any Type Of Exception And Print Log Of It
			throw (e);
		}
		return StrGeneratedUCaseRandomString;
	}

	//============================================================================================
	//FunctionName 		: RMA_WebPageRefresh_Utility
	//Description  		: Refreshes The RMA WebPage 
	//Input Parameter 	: None
	//Revision			: 0.0 - KumudNaithani-11-02-2015                                 
	//============================================================================================
	public static void RMA_WebPageRefresh_Utility(int logval) throws Exception, Error 
	{	
		try {
			String StrAccept = "Yes";
			driver.navigate().refresh(); //Web page Is Refreshed
			if (logval ==0)
			{
				parentlogger.log(LogStatus.INFO, "Web Page Is Refreshed");
			}
			else{
				logger.log(LogStatus.INFO, "Web Page Is Refreshed");
			}

			//Thread.sleep(10000);

			WebDriverWait wait = new WebDriverWait(driver, 10);			
			wait.until(org.openqa.selenium.support.ui.ExpectedConditions.alertIsPresent());
			
			RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Alert Window Is Refreshed

			if (logval == 0)
			{
				parentlogger.log(LogStatus.INFO, "Windows PopUp That Appears On Web Page Refresh Is Accepted And WebPage Is Leaved");
			}
			else{
				logger.log(LogStatus.INFO, "Windows PopUp That Appears On Web Page Refresh Is Accepted And WebPage Is Leaved");
			}

			//Thread.sleep(10000);
			driver.switchTo().parentFrame(); // A Switch To The Parent Web Page Frame Is Created
			Thread.sleep(5000);
			driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver)); //A Switch To The Frame Containing RMA Application Menu Option Is Done

		} catch (Exception|Error e) {

			if (logval == 0)
			{
				parentlogger.log(LogStatus.FAIL, "Web Page Was Not Refreshed Due To Following Reason:" + " " +color.RMA_ChangeColor_Utility(e.getMessage(),1));
			}
			else{
				logger.log(LogStatus.FAIL, "Web Page Was Not Refreshed Due To Following Reason:" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1)); //Try Catch Statement Is Used To Handle Any Type Of Un-handled Exception And Print Log Of It
			}
			throw (e);
		}
	}

	//============================================================================================
	//FunctionName 		: RMA_WindowSwitching_Utility
	//Description  		: To Switch The Multiple Windows That Are Opened In RMA Application
	//Input Parameter 	: None
	//Revision			: 0.0 - KumudNaithani-11-30-2015                                 
	//============================================================================================
	public static void RMA_WindowSwitching_Utility() throws Exception, Error 
	{
		try {
		    //WebDriverWait wait = new WebDriverWait(driver, 10);			
			//wait.until(ExpectedConditions.numberOfWindowsToBe(2));
			String StrPrimaryWindowHandle = driver.getWindowHandle(); //Window Handle Of The Current Window Is Fetched
			Set<String> strWindowHandles = driver.getWindowHandles(); //Entire Set Of The Present Window Handles Is Fetched
			Iterator<String>windowiterator = strWindowHandles.iterator(); //Entire Set Of The Present Window Handles Is Iterated
			while (windowiterator.hasNext())
			{
				String ChildWindow = windowiterator.next();
				if (!StrPrimaryWindowHandle.equalsIgnoreCase(ChildWindow)) //If The Fetched Child Window Is Not Equal To the Parent Window Then A Switch To The Child Window Is Done
				{
					driver.switchTo().window(ChildWindow);
					//Thread.sleep(10000);
				}
			}
		} catch (Exception|Error e) {
			System.out.println("Following Error Occurred While Switching Window :" +" " +e.getMessage());
			throw (e);
		}
	}

	//============================================================================================
	//FunctionName 		: RMA_ChangeColor
	//Description  		: Changes Text Color, Parameter 1 Is For Red, 2 For Green, 3 For Blue, 4 For Orange
	//Input Parameter 	: None
	//Revision			: 0.0 - ImteyazAhmad-11-30-2015                                 
	//============================================================================================
	public String RMA_ChangeColor_Utility (String text, int num) throws Exception, Error {
		String colouredText = null ;
		try {
			switch(num){
			case 1: //text color is changed to Red
				label.setText("<span style='color:red'><b>" + text+ "</b></script></span>");
				colouredText = label.getText();
				break;
			case 2: //text color is changed to Green
				label.setText("<span style='color:green'><b>" + text+ "</b></script></span>");
				colouredText = label.getText();
				break;
			case 3: //text color is changed to Blue
				label.setText("<span style='color:blue'><b>" + text+ "</b></script></span>");
				colouredText = label.getText();
				break;
			case 4: //text color is changed to Orange
				label.setText("<span style='color:orange'><b>" + text+ "</b></script></span>");
				colouredText = label.getText();
				break;
			}
		}
		catch (Exception|Error e)
		{
			System.out.println("Error has occured while changing text color :" +" " +e.getMessage());
			throw(e);
		}
		return colouredText;
	}

	//============================================================================================
	//FunctionName 		: RMA_FrameNavigation
	//Description  		: Enables The User To Navigate To A Particular Frame On The Basis Of A Static Value Present In The Frame ID
	//Input Parameter 	: String Text Contains The Static Value Present In The Frame ID
	//Revision			: 0.0 - KumudNaithani-11-08-2015                                 
	//============================================================================================
	public static int RMA_FrameNavigation (String text) throws Exception, Error {
		try {
			List<WebElement> ele  = driver.findElements(By.tagName("IFRAME"));
			int ListSize = ele.size();
			for (IntRandomNum=0; IntRandomNum<ListSize; IntRandomNum++)
			{String attribute = ele.get(IntRandomNum).getAttribute("id"); //Returns the Id of a frame.
			System.out.println(attribute);
			if (attribute.contains(text))
			{
				break;
			}
			}

		} catch (Exception|Error e) {
			System.out.println("Error Occurred While Navigating Frame :" +" " +e.getMessage());
			throw(e);
		}

		return IntRandomNum;
	}

	//============================================================================================
	//FunctionName 		: RMA_StaticWait
	//Description  		: Provide Static Wait
	//Input Parameter 	: Provide Time In Seconds For Which Application Would Wait For 
	//Revision			: 0.0 - KumudNaithani-11-08-2015                                 
	//============================================================================================
	public static void RMA_StaticWait (int sec, int logval, String WaitReason) throws Exception, Error {
		try{
			int sec1=sec*1000;
			Thread.sleep(sec1);
			if (logval == 0)
			{
				parentlogger.log(LogStatus.INFO, "Successfully Waited For :" +" " +sec +" " +"Seconds" +" " + "Due To Reason::" +  " " + color.RMA_ChangeColor_Utility(WaitReason,4) );	
			}
			else
			{
				logger.log(LogStatus.INFO, "Successfully Waited For :" +" " +sec +" " +"Seconds" +" " + "Due To Reason::" +  " " + color.RMA_ChangeColor_Utility(WaitReason,4) );
			}
		}catch(Exception|Error e)	
		{
			if (logval ==0)
			{
				parentlogger.log(LogStatus.FAIL ,"Error Occurred While Wait :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1));
			}
			else
			{
				logger.log(LogStatus.FAIL ,"Error Occurred While Wait :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1));
			}
			throw(e);
		}
	}
	//============================================================================================
	//FunctionName 		: RMA_WindowSwitchingBasedOnTitle
	//Description  		: To Switch To Particular Window Based On Title Name
	//Input Parameter 	: Provide Title Name As String Parameter Of Window To Be Switched To 
	//Revision			: 0.0 - ImteyazAhmad-02-02-2016                                 
	//============================================================================================
	public static void RMA_WindowSwitchingBasedOnTitle (String TitleName) throws Exception, Error {
		try{
			String strTitle;
			Boolean TitleFound;
			TitleFound = false;
			TitleName = TitleName.toUpperCase();
			TitleName = TitleName.trim();
			Set<String> strWindowHandles = driver.getWindowHandles(); //Entire Set Of The Present Window Handles Is Fetched
			Iterator<String> windowiterator = strWindowHandles.iterator(); //Entire Set Of The Present Window Handles Is Iterated
			while (windowiterator.hasNext())
			{
				String ChildWindow = windowiterator.next();					
				driver.switchTo().window(ChildWindow);
				Thread.sleep(4000);
				strTitle = driver.getTitle();
				strTitle = strTitle.toUpperCase();
				//System.out.println(strTitle);
				if (strTitle.contains(TitleName))
				{		
					TitleFound = true;
					return;
				}
			}	

			if (TitleFound == false)
			{
				System.out.println("Of All Opened Windows ,The Window With Provided Title Name :" + " " + TitleName +" " + ", Is Not Found Hence Switching To Required Window Can Not Be Done");
			}

		}catch(Exception|Error e)	
		{
			System.out.println("Error Occurred While Switching Window Based On Provided Title Name And Error Message Is :" +" " +e.getMessage());
			throw(e);
		}
	}

	//============================================================================================
	//FunctionName 		: RMA_CloseWindowBasedOnTitle
	//Description  		: To Close A Particular Window Based On Title Name
	//Input Parameter 	: Provide Title Name As String Parameter Of Window To Be Closed 
	//Revision			: 0.0 - ImteyazAhmad-02-02-2016                                 
	//============================================================================================
	public static void RMA_CloseWindowBasedOnTitle (String TitleName) throws Exception, Error {
		try{
			String strTitle;
			Boolean TitleFound;
			TitleFound = false;
			TitleName = TitleName.toUpperCase();
			TitleName = TitleName.trim();
			Set<String> strWindowHandles = driver.getWindowHandles(); //Entire Set Of The Present Window Handles Is Fetched
			Iterator<String> windowiterator = strWindowHandles.iterator(); //Entire Set Of The Present Window Handles Is Iterated
			while (windowiterator.hasNext())
			{
				String ChildWindow = windowiterator.next();					
				driver.switchTo().window(ChildWindow);
				Thread.sleep(4000);
				strTitle = driver.getTitle();
				strTitle = strTitle.toUpperCase();
				//System.out.println(strTitle);
				if (strTitle.contains(TitleName))
				{	
					driver.close();
					TitleFound = true;
					return;
				}
			}		
			if (TitleFound == false)
			{
				System.out.println("Of All Opened Windows ,The Window With Provided Title Name :" + " " + TitleName +" " + ", Is Not Found Hence Required Window Can Not Be Closed");
			}

		}catch(Exception|Error e)	
		{
			System.out.println("Error Occurred While Closing Window Based On Provided Title Name And Error Message Is :" +" " +e.getMessage());
			throw(e);
		}
	}
		//============================================================================================
	//FunctionName 		: RMA_GetDataFromDataBase
	//Description  		: To Update,Delete,Match,Match Partially,Fetch Record From DataBase
	//Input Parameter 	: Provide DsnName,SqlQuery,OperationType,ExpectedValue,ColumnName,logval
	//Revision			: 0.0 - ImteyazAhmad-02-15-2016                                 
	//============================================================================================
	public static String RMA_GetDataFromDataBase(String DsnName, String SqlQuery, String OperationType, String ExpectedValue, String ColumnName, int logval) throws Exception,Error
	{
		try
		{
			ResultSet Results;
			Connection Conn;
			String ConnectionString;
			String UserName;
			String Password;
			String Value;
			String DataBaseName;
			int RecordNumber;
			boolean Found;

			Found = false;
			Conn = null;
			DataBaseName = null;
			DsnName = DsnName.trim();
			SqlQuery = SqlQuery.trim().toUpperCase();
			OperationType = OperationType.trim().toUpperCase();
			ExpectedValue = ExpectedValue.trim().toUpperCase();
			ColumnName = ColumnName.trim().toUpperCase();

			if (DsnName.equalsIgnoreCase("RMA_SeleniumAutomation1_ACOFF"))
			{
				DataBaseName = "RMACDR154_SeleniumAutomation1_ACOFF";
			}

			else if(DsnName.equalsIgnoreCase("RMA_SeleniumAutomation2_ACOFF"))
			{
				DataBaseName = "RMACDR154_SeleniumAutomation2_ACOFF";
			}      
			DataBaseName = DataBaseName.trim();			
			ConnectionString = "jdbc:sqlserver://20.201.110.208:1433;DatabaseName="+DataBaseName;
			UserName = "sa";
			Password = "csc1234$";	

			//Loading the required JDBC Driver class 
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");	
			//Creating a connection to the database 
			Conn = DriverManager.getConnection(ConnectionString,UserName,Password); 
			if (Conn == null)
			{
				if (logval == 0)
				{
					parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("The Connection To Database Is Not Established",1));
				}
				else
				{
					logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("The Connection To Database Is Not Established",1));
				}

			}
			Statement Stat = Conn.createStatement();

			switch (OperationType)
			{
			case  "UPDATE" :

				RecordNumber = Stat.executeUpdate(SqlQuery);
				if (logval == 0)
				{
					parentlogger.log(LogStatus.PASS, "The Update Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On DSN :" +" " + DsnName +",  " + "And Number Of Rows Updated Is :" +" " +color.RMA_ChangeColor_Utility(String.valueOf(RecordNumber),2));

				}
				else 
				{
					logger.log(LogStatus.PASS, "The Update Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On DSN :" +" " + DsnName +",  " + "And Number Of Rows Updated Is :" +" " +color.RMA_ChangeColor_Utility(String.valueOf(RecordNumber),2));
				}
				break;

			case "DELETE" :

				RecordNumber = Stat.executeUpdate(SqlQuery);
				if (logval == 0)
				{
					parentlogger.log(LogStatus.PASS, "The Delete Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On DSN :" +" " + DsnName +",  " + "And Number Of Rows Deleted Is :" +" " +color.RMA_ChangeColor_Utility(String.valueOf(RecordNumber),2));

				}
				else 
				{
					logger.log(LogStatus.PASS, "The Delete Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On DSN :" +" " + DsnName +",  " + "And Number Of Rows Deleted Is :" +" " +color.RMA_ChangeColor_Utility(String.valueOf(RecordNumber),2));
				}

				break;

			case "MATCH" :

				Results = Stat.executeQuery(SqlQuery);
				if (Results.next())
				{
					do
					{
						Value = Results.getString(ColumnName);
						if (Value.trim().equalsIgnoreCase(ExpectedValue))
						{
							if (logval == 0)
							{
								parentlogger.log(LogStatus.PASS, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "And Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +",  " + "Is Matched With Actual Value :" +" " +color.RMA_ChangeColor_Utility(Value,2));
							}
							else
							{
								logger.log(LogStatus.PASS, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "And Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +",  " + "Is Matched With Actual Value :" +" " +color.RMA_ChangeColor_Utility(Value,2));
							}
							Found = true;
							break;
						}

					} while (Results.next());

					if (Found == false)
					{						
						if (logval == 0)
						{
							parentlogger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "But Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +"  " +color.RMA_ChangeColor_Utility(", Does Not Exists In ResultSet Hence Verification Can Not Be Done",1));
						}
						else
						{
							logger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "But Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +"  " +color.RMA_ChangeColor_Utility(", Does Not Exists In ResultSet Hence Verification Can Not Be Done",1));
						}	
					}
				}
				else
				{
					if (logval == 0)
					{
						parentlogger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " +color.RMA_ChangeColor_Utility("But ResultSet Has No Record Hence Verification Can Not Be Done",1));
					}
					else
					{
						logger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " +color.RMA_ChangeColor_Utility("But ResultSet Has No Record Hence Verification Can Not Be Done",1));
					}					
				}

				break;

			case "MATCH PARTIALLY" :

				Results = Stat.executeQuery(SqlQuery);
				if (Results.next())
				{
					do
					{
						Value = Results.getString(ColumnName);
						if (Value.trim().toUpperCase().contains(ExpectedValue))
						{
							if (logval == 0)
							{
								parentlogger.log(LogStatus.PASS, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "And Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +",  " + "Is Available InActual Value :" +" " +color.RMA_ChangeColor_Utility(Value,2));
							}
							else
							{
								logger.log(LogStatus.PASS, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "And Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +",  " + "Is Available In Actual Value :" +" " +color.RMA_ChangeColor_Utility(Value,2));
							}
							Found = true;
							break;
						}

					} while (Results.next());

					if (Found == false)
					{						
						if (logval == 0)
						{
							parentlogger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "But Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +"  " +color.RMA_ChangeColor_Utility(", Does Not Exists In ResultSet Hence Verification Can Not Be Done",1));
						}
						else
						{
							logger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + "But Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +"  " +color.RMA_ChangeColor_Utility(", Does Not Exists In ResultSet Hence Verification Can Not Be Done",1));
						}	
					}
				}
				else
				{
					if (logval == 0)
					{
						parentlogger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " +color.RMA_ChangeColor_Utility("But ResultSet Has No Record Hence Verification Can Not Be Done",1));
					}
					else
					{
						logger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " +color.RMA_ChangeColor_Utility("But ResultSet Has No Record Hence Verification Can Not Be Done",1));
					}					
				}
				break;

			case "FETCH" :

				Results = Stat.executeQuery(SqlQuery);
				if (Results.next())
				{					
					Value = Results.getString(ColumnName);                      
					if (logval == 0)
					{
						parentlogger.log(LogStatus.PASS, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + " And Fetched Value Is :" +" " +color.RMA_ChangeColor_Utility(Value,2));
					}
					else
					{
						logger.log(LogStatus.PASS, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " + " And Fetched Value Is :" +" " +color.RMA_ChangeColor_Utility(Value,2));
					}					
					return Value;
				}

				else
				{
					if (logval == 0)
					{
						parentlogger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " +color.RMA_ChangeColor_Utility("But ResultSet Has No Record Hence Value Can Not Be Fetched ",1));
					}
					else
					{
						logger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Executed Successfully On Dsn :" +" " + DsnName +",  " +color.RMA_ChangeColor_Utility("But ResultSet Has No Record Hence Value Can Not Be Fetched",1));
					}	
				}
				break;				
			}

		}catch(Exception|Error e)
		{
			if (logval == 0)
			{
				parentlogger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Not Executed Successfully, And Error Message Is : " +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1 ));
			}
			else
			{
				logger.log(LogStatus.FAIL, "The Sql Query :" +" " +color.RMA_ChangeColor_Utility(SqlQuery,3) +",  " +"Is Not Executed Successfully, And Error Message Is : " +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1 ));	
			}
			throw(e);
		}
		return null;
	}	
	
	//============================================================================================
	//FunctionName 		: RMA_WindMsgHandlerAndTextVerify_Utility
	//Description  		: Handles Any Type Of Windows Pop Up, Reads And Compares The Message Displayed And Accepts Or Rejects The Same (Say Clicking On Yes Or No Button) 
	//Input Parameter 	: Instance Of The WebDriver Class 'Driver', Value Of The String 'StrAccept', CompareFlg Value According To Which Partial Or Full Comparison Of The Message Text Is Done
	////Revision		: 0.1 - KumudNaithani-02-22-2016                                
	//============================================================================================
	public static void RMA_WindMsgHandlerAndTextVerify_Utility(String StrAccept, String CompareFlg, String ExpMsg, String PopUpVerifyMessage, int logval)throws Exception, Error
	{
		Alert alert;
		try {
			alert = driver.switchTo().alert(); // A Switch To The Displayed Alert Message Is Done
			StrAlertMessage = alert.getText();
			if (StrAccept == "Yes") // If The User Chooses To Accept The Alert That Is The Positive Option Say "Yes", "OK" Or "Leave The Page" Then Alert Window Is Accepted And Desired Action Is Done Like Refereshing The Page
			{
				//Thread.sleep(10000);
				alert.accept(); 
				Thread.sleep(15000);		
			}
			else
			{
				alert.dismiss(); // If The User Chooses To Decline The Alert That Is The Negative Option Say "No", "Cancel" Or "Stay On The Page" Then Alert Window Is Dismissed And Desired Action Is Done Like Staying On The Page
			} 
			if (CompareFlg == "Complete")
			{
			RMA_Verification_Utility.RMA_TextCompare(ExpMsg, StrAlertMessage, PopUpVerifyMessage, logval);
			}
			else
			{
			RMA_Verification_Utility.RMA_PartialTextVerification(ExpMsg, StrAlertMessage, PopUpVerifyMessage, logval);
			}
		}
		catch (NoAlertPresentException ex)
		{
			//Following Catch Has Been Added To Handle The Scenario Where Existence Of The Window's Pop Up Depends On The Application Behavior (Scenario Executed Before Function Call)
		}
		catch (Exception|Error e) 
		{
			System.out.println("Exception Occurred While Handling The Windows PopUp" + e.getMessage()); //Try Catch Statement Is Used To Handle Any Type Of Unhandled Exception And Print Log Of It
			throw (e);
		}
	}
}
