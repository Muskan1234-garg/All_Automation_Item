package rmaseleniumutilties;

import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

public class RMA_NegativeVerification_Utility extends rmaseleniumtestscripts.RMA_TC_BaseTest {
	static RMA_GenericUsages_Utility color = new RMA_GenericUsages_Utility();
//============================================================================================
//FunctionName 		: RMA_WebElementNotExist_Utility
//Description  		: To Check The Non-Existence Of A Web Element 
//Input Parameter 	: WebElement Element : WebElement Whose Existence Is To Be Checked And ObjectDescription : Description Of The Object Whose Existence Needs To Be Checked
//Revision			: 0.0 - KumudNaithani-11-30-2015                                 
//============================================================================================
public static void RMA_ElementNotExist_Utility(WebElement Element, String ObjectDescription,int logval) throws Exception, Error
{
	
	try {
		ObjectDescription = color.RMA_ChangeColor_Utility(ObjectDescription, 4);
		if (Element == null)
		{
			if (logval ==0)
			{
				parentlogger.log(LogStatus.PASS, "Following Object:" + " " + ObjectDescription + " "+ "Is Not Found On Application Screen And Hence We Can Continue With Testing");
			}
			else
			{
				logger.log(LogStatus.PASS, "Following Object:" + " " + ObjectDescription + " "+ "Is Not Found On Application Screen And Hence We Can Continue With Testing");
			}
		}
		else
		{
			if (logval ==0)
			{
				parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("Following Object", 1)+ " " + ObjectDescription + " "+ color.RMA_ChangeColor_Utility("Is Found On Application Screen And Hence Testing Is DisContinued", 1));
		}
			else
			{
			logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("Following Object", 1) + " " + ObjectDescription + " "+ color.RMA_ChangeColor_Utility("Is Found On Application Screen And Hence Testing Is DisContinued", 1));
			}
		}
		Assert.assertTrue(Element == null);
	} catch (Exception|Error e) {
		if (logval ==0)
		{
			parentlogger.log(LogStatus.FAIL, "Following Object"+ " " + ObjectDescription + " "+ "Negative Existence Verification Is Unsuccessful Due To Reason" + " " + color.RMA_ChangeColor_Utility(e.getMessage(), 1) );
	}
		else
		{
			logger.log(LogStatus.FAIL, "Following Object"+ " " + ObjectDescription + " "+ "Negative Existence Verification Is Unsuccessful Due To Reason" + " " + color.RMA_ChangeColor_Utility(e.getMessage(), 1) );
		}
		throw (e);
	}
	}
}
