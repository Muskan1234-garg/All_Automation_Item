package rmaseleniumutilties;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
//RMA Package Import Completed

public class RMA_Verification_Utility extends rmaseleniumtestscripts.RMA_TC_BaseTest{
public static String ReturnValue;
public static String StrActualVal1;
public static String StrActualVal2;
public static int IntTable_RowsCount;

static RMA_GenericUsages_Utility color = new RMA_GenericUsages_Utility();

//============================================================================================
//FunctionName 		: RMA_WebElementExist_Utility
//Description  		: To Check The Existence Of A Web Element On The Web Page
//Input Parameter 	: None
//Revision			: 0.0 - KumudNaithani-11-30-2015                                 
//============================================================================================
public static void RMA_ElementExist_Utility(WebElement Element, String ObjectDescription, int logval) throws Exception, Error
{
	try {
		if (Element != null)
		{
		 	if (logval ==0)
		 	{
		 		parentlogger.log(LogStatus.PASS, "Following Object:" + " " + color.RMA_ChangeColor_Utility(ObjectDescription, 4) + " "+ "Is Found On Application Screen And Hence We Can Continue With Testing");
		 	}
		 	else
		 	{
		 		logger.log(LogStatus.PASS, "Following Object:" + " " + color.RMA_ChangeColor_Utility(ObjectDescription, 4) + " "+ "Is Found On Application Screen And Hence We Can Continue With Testing");
		 	}
		}
			else
			{
				if (logval ==0)
				{
					parentlogger.log(LogStatus.FAIL, "Following Object:" + " " + color.RMA_ChangeColor_Utility(ObjectDescription, 4) + " "+ color.RMA_ChangeColor_Utility("Is Not Found On Application Screen And Hence Testing Is DisContinued", 1));	
				}
				else
				{
					logger.log(LogStatus.FAIL, "Following Object:" + " " + color.RMA_ChangeColor_Utility(ObjectDescription, 4) + " "+ color.RMA_ChangeColor_Utility("Is Not Found On Application Screen And Hence Testing Is DisContinued", 1));
			}
		}
		Assert.assertTrue(Element != null);
	} catch (Exception|Error e) {
		if (logval ==0)
		{
			 parentlogger.log(LogStatus.FAIL, "Existence Verification For Following Object :" + " " + color.RMA_ChangeColor_Utility(ObjectDescription, 4) + " "+ "Failed As Following Error Occurred" + color.RMA_ChangeColor_Utility(e.getMessage(),1));
		}
		else
		{
			 logger.log(LogStatus.FAIL, "Existence Verification For Following Object :" + " " + color.RMA_ChangeColor_Utility(ObjectDescription, 4) + " "+ "Failed As Following Error Occurred" + color.RMA_ChangeColor_Utility(e.getMessage(),1));
		}
			
		throw (e);
	}
	}


//============================================================================================
//FunctionName 		: RMA_AttributeFetch_Utility
//Description  		: To Fetch The Value Of The Attribute Based On The WebElement And Attribute To Fetch Provided By the User
//Input Parameter 	: Element Of Type WebElement and AttributeToFetch Of Type String
//Revision			: 0.0 - KumudNaithani-12-02-2015                                 
//============================================================================================
public static String RMA_AttributeFetch_Utility(WebElement Element, String AttributeToFetch) throws Exception, Error
{//In Case The User Wants To Select An IntegerValue Then The User Needs To Convert The Integer Value To String Using String.valueOf() Function And Then Pass As An Argument Into The Function
	try {
		ReturnValue  = Element.getAttribute(AttributeToFetch);
	} catch (Exception|Error e) {
		throw (e);
	}
	return ReturnValue;
}

//============================================================================================
//FunctionName 		: RMA_TableVerifyText_Utility
//Description  		: To Verify Any Two Text Values (In Two Different Columns) In A Table Based On The User Provided Search Value
//Input Parameter 	: Element: Table Element, SearchText: Text To Be Searched, col1 and col2: Columns In Which The Value Is To Be Verified, ExpVal1, ExpVall2: Values To Be Verified, TableName: Name Of The Table
//Revision			: 0.0 - KumudNaithani-12-02-2015                                 
//============================================================================================
public static void RMA_TableVerifyText_Utility(WebElement Element, String SearchText, int col1, String ExpVal1, int col2, String ExpVal2, String TableName, int logval) throws Exception, Error
{
	try {
		int IntTable_RowsCount;
		int IntTable_ColumnsCount;
		String IntTable_CellText;
		//Local Variable Declaration
		
		List<WebElement> reservetable_rows = Element.findElements(By.tagName("tr")); //All The Row Elements Of The Table Are Fetched In A List
		IntTable_RowsCount = reservetable_rows.size(); //RowCount Is Stored In Variable IntTable_RowsCount

breakloop:
for (int row=0; row<IntTable_RowsCount; row++){ //Loop Is Iterated Through All The Rows Of The Table
		List<WebElement> table_rows_columns = reservetable_rows.get(row).findElements(By.tagName("td")); //All The Column Elements Of The Table Are Fetched In A List
		IntTable_ColumnsCount = table_rows_columns.size(); //Count Of The Number Of Columns In The Row Is Taken
		for (int column=0; column<IntTable_ColumnsCount; column++){//Loop Is Iterated Through All The Columns Of The Row
			  IntTable_CellText = table_rows_columns.get(column).getText(); //Value In The Particular Cell Of A Table Is Fetched
			   if (SearchText.equalsIgnoreCase(IntTable_CellText)){
				   StrActualVal1 = table_rows_columns.get(col1).getText();
				   StrActualVal2 = table_rows_columns.get(col2).getText();
				   if (StrActualVal1.equalsIgnoreCase(ExpVal1) && StrActualVal2.equalsIgnoreCase(ExpVal2)){
					   if (logval ==0)
					   {
						   parentlogger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ "And Searched Text Value::" + " " + color.RMA_ChangeColor_Utility(SearchText, 4)+ " "+ "Expected Values::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + "And" + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + "Are Equal To Actual Values" + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + "And" + " " +  color.RMA_ChangeColor_Utility(StrActualVal2, 2) + " " + "Hence Table Value Verification Is Successful" );  
					   }
					   else
					   {
						   logger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "And Searched Text Value::" + " " + color.RMA_ChangeColor_Utility(SearchText, 4)+ " " + "Expected Values::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + "And" + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + "Are Equal To Actual Values" + " " +   color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + "And" + " " +  color.RMA_ChangeColor_Utility(StrActualVal2, 2)+ " " + "Hence Table Value Verification Is Successful" );
					   }
					   }
				   else{
					   
					   if (logval ==0)
					   {
						   parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + color.RMA_ChangeColor_Utility("And Searched Text Value::", 1)+ " "+ color.RMA_ChangeColor_Utility(SearchText, 4)+ color.RMA_ChangeColor_Utility("Expected Values::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " +  color.RMA_ChangeColor_Utility("And", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + color.RMA_ChangeColor_Utility("Are Not Equal To Actual Values::", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + color.RMA_ChangeColor_Utility("And", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal2, 2) + " " + color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Not Successful", 1) );  
					   }
					   else
					   {
						   logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + color.RMA_ChangeColor_Utility("And Searched Text Value::", 1)+ " "+ color.RMA_ChangeColor_Utility(SearchText, 4)+ color.RMA_ChangeColor_Utility("Expected Values::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + color.RMA_ChangeColor_Utility("And", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + color.RMA_ChangeColor_Utility("Are Not Equal To Actual Values::", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + color.RMA_ChangeColor_Utility("And", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal2, 2) + " " + color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Not Successful", 1));   
					   }
				   }
					break breakloop;
					}
				   }
			   }
			  
		Assert.assertTrue((StrActualVal1.equalsIgnoreCase(ExpVal1)) && (StrActualVal2.equalsIgnoreCase(ExpVal2)));
	} catch (Exception|Error e) {
		if (logval ==0)
		   {
			   parentlogger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Table Value Verification Failed Due To Reason:" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1) );  
		   }
		   else
		   {
			   logger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Table Value Verification Failed Due To Reason:" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1) );   
		   }
		throw(e);
	}
	 }

//============================================================================================
//FunctionName 		: RMA_EnbDisbStateVerify_Utility
//Description  		: To Verify The Enabled Or Disabled State Of The Given Control
//Input Parameter 	: Element: Web Element Whose State Is To Be Verified
//Revision			: 0.0 - KumudNaithani-12-04-2015                                 
//============================================================================================
public static void RMA_EnbDisbStateVerify_Utility (WebElement Element, String State, String ControlName, int logval) throws Exception, Error
{
	try {
		switch (State){
		case "enable":
		if (Element.isEnabled())
		{ 
			if (logval ==0)
				{
				parentlogger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In Enabled State And Hence Enabled State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");	
				}
			else
				{
				logger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In Enabled State And Hence Enabled State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");
				}
		}
		else
		{
			if (logval ==0)
			{
				parentlogger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Disabled State And Hence Enabled State Verification For", 1)  + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
			}
			else
			{
				logger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Disabled State And Hence Enabled State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
			}
		}
		Assert.assertTrue(Element.isEnabled());
		break;
		case "disable":
			if (!Element.isEnabled())
			{
				if (logval ==0)
				{
				parentlogger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In Disabled State And Hence Disabled State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is Successful");
				}
				else
				{
				logger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In Disabled State And Hence Disabled State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is Successful");
				}
			}
			else
			{
				if (logval ==0)
				{
				parentlogger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Enabled State And Hence Disabled State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
				}
				else
				{
				logger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Enabled State And Hence Disabled State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
				}
			}
			Assert.assertFalse(Element.isEnabled());
		break;

		}
	} catch (Exception|Error e) {
		if (logval ==0)
		{
			parentlogger.log(LogStatus.FAIL,  "Enabled/Disabled State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Was Unsuccessful Due To Following Reason" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1));
		}
		else
		{
			logger.log(LogStatus.FAIL,  "Enabled/Disabled State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Was Unsuccessful Due To Following Reason" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1));
		}
		throw (e);
	}
}

//============================================================================================
//FunctionName 		: RMA_SelectDeselecStateVerify_Utility
//Description  		: To Verify The Selected Or DeSelected State Of The Given Control
//Input Parameter 	: Element: Web Element Whose State Is To Be Verified
//Revision			: 0.0 - KumudNaithani-12-04-2015                                 
//============================================================================================
public static void RMA_SelectDeselecStateVerification_Utility (WebElement Element, String State, String ControlName, int logval) throws Exception, Error
{
	try {
		switch (State){
		case "select":
		if (Element.isSelected())
		{
			if (logval ==0)
			{
			parentlogger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In Selected State And Hence Selected State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");
			}
			else
			{
			logger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In Selected State And Hence Selected State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");
			}
		}
		else
		{
			if (logval ==0)
			{
			parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Deselected State And Hence Selected State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));	
			}
			else{
			logger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Deselected State And Hence Selected State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
			}
		}
		Assert.assertTrue(Element.isSelected());
		break;
		case "deselect":
			if (!Element.isSelected())
			{
				if (logval==0){
				parentlogger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In DeSelected State And Hence Deselected State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");	
				}
				else{
				logger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is In DeSelected State And Hence Deselected State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");
				}
			}
			else
			{
				if (logval ==0){
				parentlogger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Selected State And Hence Deselected State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));	
				}
				else{
				logger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is In Selected State And Hence Deselected State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
				}
			}
			Assert.assertFalse(Element.isSelected());
		break;

		}
	} catch (Exception|Error e) {
		if (logval ==0){
			parentlogger.log(LogStatus.FAIL,  "Selected Or Deselected State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) +  "CouldNot Be Done Due To Error" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1));	
			}
			else{
			logger.log(LogStatus.FAIL,  "Selected Or Deselected State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) +  "CouldNot Be Done Due To Error" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1));	
			}
		throw (e);
	}
}

//============================================================================================
//FunctionName 		: RMA_ObjectDisplayVerify_Utility
//Description  		: To Verify That Whether The Given Control Is Displayed Or Not Displayed
//Input Parameter 	: Element: Web Element Whose State Is To Be Verified
//Revision			: 0.0 - KumudNaithani-12-07-2015                                 
//============================================================================================
public static void RMA_ObjectDisplayVerify_Utility (WebElement Element, String State, String ControlName, int logval) throws Exception, Error
{//Note:: User Should Use Not Displayed Case Only When The Control Is Present In Hidden State On Application Screen At Present
	try {
		switch (State){
		case "displayed": 
		if (Element.isDisplayed())
		{
			if (logval == 0)
			{
			parentlogger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");
			}
			else{
			logger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");
			}
		}
		else
		{
			if (logval==0)
			{
			parentlogger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is Not Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
			}
			else
			{
			logger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is Not Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
			}
		}
		Assert.assertTrue(Element.isDisplayed());
		break;
		case "notdisplayed":
			if (!Element.isDisplayed())
			{
				if (logval ==0)
				{
				parentlogger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is Not Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");	
				}
				else
				{
				logger.log(LogStatus.PASS,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + "Is Not Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + "Is Successful");
				}
			}
			else
			{
				if (logval ==0)
				{
				parentlogger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
				}
				else
				{
				logger.log(LogStatus.FAIL,  color.RMA_ChangeColor_Utility(ControlName, 4) + " " + color.RMA_ChangeColor_Utility("Is Not Displayed On Application Screen And Hence Displayed/Not Displayed State Verification For", 1) + " " + color.RMA_ChangeColor_Utility(ControlName, 4)+ " " + color.RMA_ChangeColor_Utility("Is Unsuccessful", 1));
				}
			}
			Assert.assertFalse(Element.isDisplayed());
		break;

		}
	} catch (Exception|Error e) {
		if (logval ==0){
			parentlogger.log(LogStatus.FAIL,  "Displayed/NotDisplayed State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) +  "CouldNot Be Done Due To Error" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1));	
			}
			else{
			logger.log(LogStatus.FAIL,  "Displayed/NotDisplayed State Verification For" + " " + color.RMA_ChangeColor_Utility(ControlName, 4) +  "CouldNot Be Done Due To Error" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1));		
			}
		throw (e);
	}
}

//============================================================================================
//FunctionName 		: RMA_TextCompare
//Description  		: To Compare Two String Values 
//Input Parameter 	: ExpectedString, ActualString Containing The Values Of The Values To Be Compared And ObjjDesc Contains Comparison Description To Be Passed In Log Statement
//Revision			: 0.0 - KumudNaithani-12-07-2015                                 
//============================================================================================
public static void RMA_TextCompare(String ExpectedString, String ActualString, String ObjDesc, int logval) throws Exception, Error
{
 try {
	 String ActualStringLabel;
	 String ExpectedStringLabel;
	 //Local Variable Declaration
	 
	 ActualStringLabel = color.RMA_ChangeColor_Utility(ActualString, 2);
	 ExpectedStringLabel = color.RMA_ChangeColor_Utility(ExpectedString, 3);
	 
	if (ExpectedString.equalsIgnoreCase(ActualString)){
		if (logval == 0)
		{
		   parentlogger.log(LogStatus.PASS, "Expected Value" + " "+ ExpectedStringLabel + " " + "And Actual Value" + " " + ActualStringLabel + " "  + "Are Same And Hence" + " " + ObjDesc + " " + "Verification Is Successful" );
		}
		else
		
		   logger.log(LogStatus.PASS, "Expected Value" + " "+ ExpectedStringLabel + " " + "And Actual Value" + " " + ActualStringLabel + " "  + "Are Same And Hence" + " " + ObjDesc + " " + "Verification Is Successful" );
	 }
	 else{
		 if (logval == 0)
		 {
			parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("Expected Value", 1) + " "+ ExpectedStringLabel + " " + color.RMA_ChangeColor_Utility("And Actual Value", 1) + " " + ActualStringLabel + " "  + color.RMA_ChangeColor_Utility("Are Not Same And Hence", 1) + " " + ObjDesc + " " + color.RMA_ChangeColor_Utility("Verification Is Not Successful", 1) ); 
		 }
		 
		 else
		 {
		    logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("Expected Value", 1) + " "+ ExpectedStringLabel + " " + color.RMA_ChangeColor_Utility("And Actual Value", 1) + " " + ActualStringLabel + " "  + color.RMA_ChangeColor_Utility("Are Not Same And Hence", 1) + " " + ObjDesc + " " + color.RMA_ChangeColor_Utility("Verification Is Not Successful", 1) );
		 }
		 }
	 Assert.assertTrue(ExpectedString.equalsIgnoreCase(ActualString));
} catch (Exception|Error e) {
	if (logval ==0)
	{
		parentlogger.log(LogStatus.FAIL, "Value Comparison For Expected Value" + " "+ color.RMA_ChangeColor_Utility(ExpectedString, 3) + " " + "And Actual Value" + " " + color.RMA_ChangeColor_Utility(ActualString, 3) + " "  + "Is Not Successful And Error Occurred Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1));
	}
	else
	{
		logger.log(LogStatus.FAIL, "Value Comparison For Expected Value" + " "+ color.RMA_ChangeColor_Utility(ExpectedString, 3) + " " + "And Actual Value" + " " + color.RMA_ChangeColor_Utility(ActualString, 3) + " "  + "Is Not Successful And Error Occurred Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1));
	}
	throw (e);
}
}


//============================================================================================
//FunctionName 		: RMA_TableSingleTextVerify_Utility
//Description  		: To Verify The Text In A Table Based On The User Provided Search Value
//Input Parameter 	: Element: Table Element, SearchText: Text To Be Searched, col1: Column In Which The Value Is To Be Verified, ExpVal1: Value To Be Verified, TableName: Name oF The Table
//Revision			: 0.0 - KumudNaithani-12-18-2015                                 
//============================================================================================
public static void RMA_TableSingleTextVerify_Utility(WebElement Element, String SearchText, int col1, String ExpVal1, String TableName, int logval) throws Exception, Error
{
	try {
		int IntTable_RowsCount;
		int IntTable_ColumnsCount;
		String IntTable_CellText;
		//Local Variable Declaration
		
		List<WebElement> table_rows = Element.findElements(By.tagName("tr")); //All The Row Elements Of The Table Are Fetched In A List
		IntTable_RowsCount = table_rows.size(); //RowCount Is Stored In Variable IntTable_RowsCount
		breakloop:
			for (int row=0; row<IntTable_RowsCount; row++){ //Loop Is Iterated Through All The Rows Of The Table
				List<WebElement> table_rows_columns = table_rows.get(row).findElements(By.tagName("td")); //All The Column Elements Of The Table Are Fetched In A List
				IntTable_ColumnsCount = table_rows_columns.size(); //Count Of The Number Of Columns In The Row Is Taken
				for (int column=0; column<IntTable_ColumnsCount; column++){//Loop Is Iterated Through All The Columns Of The Row
					IntTable_CellText = table_rows_columns.get(column).getText(); //Value In The Particular Cell Of A Table Is Fetched
					if (SearchText.equalsIgnoreCase(IntTable_CellText)){
						StrActualVal1 = table_rows_columns.get(col1).getText();
						if (StrActualVal1.equalsIgnoreCase(ExpVal1)){
							if (logval==0)
							{
							parentlogger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ "And Searched Text Value::" + " " + color.RMA_ChangeColor_Utility(SearchText, 4)+ " "+ "Expected Value::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " +  "Is Equal To Actual Value" + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + "And" +" " + "Hence Table Value Verification Is Successful" );
							}
							else
							{
							logger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "  + "And Searched Text Value::" + " " + color.RMA_ChangeColor_Utility(SearchText, 4)+ " " + "Expected Value::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " +  "Is Equal To Actual Value" + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + "And" +" " + "Hence Table Value Verification Is Successful" );
							}
							}
						else{
							if (logval==0)
							{
							parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + color.RMA_ChangeColor_Utility("And Searched Text Value::", 1)+ " "+ color.RMA_ChangeColor_Utility(SearchText, 4)+ " "+color.RMA_ChangeColor_Utility("Expected Value::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + color.RMA_ChangeColor_Utility("Is Not Equal To Actual Value", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Not Successful", 1) );   
							}
							else
							{
							logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + color.RMA_ChangeColor_Utility("And Searched Text Value::", 1)+ " "+ color.RMA_ChangeColor_Utility(SearchText, 4)+ " "+color.RMA_ChangeColor_Utility("Expected Value::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + color.RMA_ChangeColor_Utility("Is Not Equal To Actual Value", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Not Successful", 1) );  
							}
							break breakloop;
					}
						}
					}
				}
			  
		Assert.assertTrue(StrActualVal1.equalsIgnoreCase(ExpVal1));
	} catch (Exception|Error e) {
		if (logval==0)
		{
		parentlogger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Value Verification Is Not Successful Due To The Following Reason" + color.RMA_ChangeColor_Utility(e.getMessage(),1) );  
		}
		else
		{
		logger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Value Verification Is Not Successful Due To The Following Reason" + color.RMA_ChangeColor_Utility(e.getMessage(),1) ); 
		}
		
		throw (e);
	}
	}

//============================================================================================
//FunctionName 		: RMA_FilterNGGridVerify_Utility
//Description  		: To Verify The Text In Test NG Grid After Filtering The Grid On The Basis Of The User Provided Input
//Input Parameter 	: Element1, Table Element, SearchText: Text On The Basis Of Which Test NG Grid Is To Be Filtered, String ExpVal1: Expected Value In The Grid, ObDesc: Description Of the NG Grid, logval: logger value, 
//Revision			: 0.0 - KumudNaithani-12-28-2015                                 
//============================================================================================
public static void RMA_FilterNGGridVerify_Utility(String ExpVal1, String ObjDesc, WebElement Element1, int logval) throws Exception, Error
{
	
		try {
			StrActualVal1 = Element1.getText();
			if (StrActualVal1.equalsIgnoreCase(ExpVal1)){
				if (logval == 0){
				parentlogger.log(LogStatus.PASS, "For NG Grid Table::" + " " + color.RMA_ChangeColor_Utility(ObjDesc, 4)+ " " + "Expected Value::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + "Is Equal To Actual Value" + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + "And" +" " + "Hence Table Value Verification Is Successful" );
				}
				else
				{
				logger.log(LogStatus.PASS, "For NG Grid Table::" + " " + color.RMA_ChangeColor_Utility(ObjDesc, 4) + " " + "Expected Value::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + "Is Equal To Actual Value" + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + "And" +" " + "Hence Table Value Verification Is Successful" );
				}
			}
		else
			{
				if (logval == 0){
				parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For NG Grid Table::", 1) + " " + color.RMA_ChangeColor_Utility(ObjDesc, 4) + " " + color.RMA_ChangeColor_Utility("Expected Value::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + color.RMA_ChangeColor_Utility("Is Not Equal To Actual Value", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " +color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Unsuccessful", 1) );
				}
				else
				{
				logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For NG Grid Table::", 1) + " " + color.RMA_ChangeColor_Utility(ObjDesc, 4) + " " + color.RMA_ChangeColor_Utility("Expected Value::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + color.RMA_ChangeColor_Utility("Is Not Equal To Actual Value", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Unsuccessful", 1) );
				}
				
		Assert.assertEquals(StrActualVal1, ExpVal1);
				
 }
		} catch (Exception|Error e) {
			if (logval==0)
			{
			parentlogger.log(LogStatus.FAIL, "For NG Grid::" + " " + color.RMA_ChangeColor_Utility(ObjDesc, 4) + " " + "Value Verification Is Not Successful Due To The Following Reason" + color.RMA_ChangeColor_Utility(e.getMessage(),1) );  
			}
			else
			{
			logger.log(LogStatus.FAIL, "For NG Grid::" + " " + color.RMA_ChangeColor_Utility(ObjDesc, 4) + " " + "Value Verification Is Not Successful Due To The Following Reason" + color.RMA_ChangeColor_Utility(e.getMessage(),1) ); 
			}
			throw (e);
		}
}

//============================================================================================
//FunctionName 		: RMA_TableVerifyPartialText_Utility
//Description  		: To Verify The Partial Text In A Table Based On The User Provided Search Value
//Input Parameter 	: Element: Table Element, SearchText: Text To Be Searched, col1: Columns In Which The Value Is To Be Verified, ExpVal1, ExpVall2: Values To Be Verified, TableName: Name oF The Table
//Revision			: 0.0 - KumudNaithani-01-05-2015                                 
//============================================================================================
public static void RMA_TableVerifyPartialText_Utility(WebElement Element, String SearchText, int col1, String ExpVal1, String ExpVal2, String TableName, int logval) throws Exception, Error
{
	try {
		int IntTable_RowsCount;
		int IntTable_ColumnsCount;
		String IntTable_CellText;
		//Local Variable Declaration
		
		List<WebElement> reservetable_rows = Element.findElements(By.tagName("tr")); //All The Row Elements Of The Table Are Fetched In A List
		IntTable_RowsCount = reservetable_rows.size(); //RowCount Is Stored In Variable IntTable_RowsCount

breakloop:
for (int row=0; row<IntTable_RowsCount; row++){ //Loop Is Iterated Through All The Rows Of The Table
		List<WebElement> table_rows_columns = reservetable_rows.get(row).findElements(By.tagName("td")); //All The Column Elements Of The Table Are Fetched In A List
		IntTable_ColumnsCount = table_rows_columns.size(); //Count Of The Number Of Columns In The Row Is Taken
		for (int column=0; column<IntTable_ColumnsCount; column++){//Loop Is Iterated Through All The Columns Of The Row
			  IntTable_CellText = table_rows_columns.get(column).getText(); //Value In The Particular Cell Of A Table Is Fetched
			   if (SearchText.equalsIgnoreCase(IntTable_CellText)){
				   StrActualVal1 = table_rows_columns.get(col1).getText();
				   if (StrActualVal1.contains(ExpVal1)&& StrActualVal1.contains(ExpVal2)){
					   if (logval ==0)
					   {
						   parentlogger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "And Searched Text Value::" + " " + color.RMA_ChangeColor_Utility(SearchText, 4)+ " " + "Expected Values::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + "And" + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + "Are Present In Actual Value" + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + "Hence Table Value Verification Is Successful" );  
					   }
					   else
					   {
						   logger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "And Searched Text Value::" + " " + color.RMA_ChangeColor_Utility(SearchText, 4)+ " " +"Expected Values::" + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + "And" + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + "Are Present In Actual Value" + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " +"Hence Table Value Verification Is Successful" );
					   }
					   }
				   else{
					   
					   if (logval ==0)
					   {
						   parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + color.RMA_ChangeColor_Utility("And Searched Text Value::", 1)+ " "+ color.RMA_ChangeColor_Utility(SearchText, 4)+ " "+color.RMA_ChangeColor_Utility("Expected Values::", 1) + " " + color.RMA_ChangeColor_Utility("Expected Values::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + color.RMA_ChangeColor_Utility("And", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + color.RMA_ChangeColor_Utility("Are Not Present In Actual Value", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Not Successful", 1) );  
					   }
					   else
					   {
						   logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " +color.RMA_ChangeColor_Utility("And Searched Text Value::", 1)+ " "+ color.RMA_ChangeColor_Utility(SearchText, 4)+ " " + color.RMA_ChangeColor_Utility("Expected Values::", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal1, 3) + " " + color.RMA_ChangeColor_Utility("And", 1) + " " + color.RMA_ChangeColor_Utility(ExpVal2, 3) + " " + color.RMA_ChangeColor_Utility("Are Not Present In Actual Value", 1) + " " +  color.RMA_ChangeColor_Utility(StrActualVal1, 2) + " " + color.RMA_ChangeColor_Utility("Hence Table Value Verification Is Not Successful", 1) );   
					   }
				   }
					   
					break breakloop;

				   }
		}
		}
		Assert.assertTrue((StrActualVal1.contains(ExpVal1))&& (StrActualVal1.contains(ExpVal2)));

	}catch (Exception|Error e) {
		if (logval==0)
		{
		parentlogger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Partial Text Value Verification Is Not Successful Due To The Following Reason" + color.RMA_ChangeColor_Utility(e.getMessage(),1) );  
		}
		else
		{
		logger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Partial Text Value Verification Is Not Successful Due To The Following Reason" + color.RMA_ChangeColor_Utility(e.getMessage(),1) ); 
		}
		throw(e);
	}
	 }


//============================================================================================
//FunctionName 		: RMA_ContainsText
//Description  		: To Compare Two String Values 
//Input Parameter 	: ExpectedString, ActualString Containing The Values Of The Values To Be Compared And ObjjDesc Contains Comparison Description To Be Passed In Log Statement
//Revision			: 0.0 - KumudNaithani-12-07-2015                                 
//============================================================================================
public static void RMA_PartialTextVerification(String ExpectedString, String ActualString, String ObjDesc, int logval) throws Exception, Error
{
try {
	 String ActualStringLabel;
	 String ExpectedStringLabel;
	 //Local Variable Declaration
	 
	 ActualStringLabel = color.RMA_ChangeColor_Utility(ActualString, 2);
	 ExpectedStringLabel = color.RMA_ChangeColor_Utility(ExpectedString, 3);
	 
	if (ActualString.contains(ExpectedString)){
		if (logval == 0)
		{
		   parentlogger.log(LogStatus.PASS, "Expected Value" + " "+ ExpectedStringLabel + " " + "Is Contained In Actual Value" + " " + ActualStringLabel + " "  + "Hence" + " " + ObjDesc + " " + "Partial Text Verification Is Successful" );
		}
		else
		{
		
			logger.log(LogStatus.PASS, "Expected Value" + " "+ ExpectedStringLabel + " " + "Is Contained In Actual Value" + " " + ActualStringLabel + " "  + "Hence" + " " + ObjDesc + " " + "Partial Text Verification Is Successful" );
	 }
	}
	 else{
		 if (logval == 0)
		 {
			parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("Expected Value", 1) + " "+ ExpectedStringLabel + " " + color.RMA_ChangeColor_Utility("Is Not Present Partially In Actual Value", 1) + " " + ActualStringLabel + " "  + color.RMA_ChangeColor_Utility("Hence Partial Text Verification Is Not Successful For ", 1) + " " + ObjDesc); 
		 }
		 
		 else
		 {
		    logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("Expected Value", 1) + " "+ ExpectedStringLabel + " " + color.RMA_ChangeColor_Utility("Is Not Present Partially In Actual Value", 1) + " " + ActualStringLabel + " "  + color.RMA_ChangeColor_Utility("Hence Partial Text Verification Is Not Successful For ", 1)+ " " + ObjDesc ); 
	 }
	 }
	 Assert.assertTrue(ActualString.contains(ExpectedString));
} catch (Exception|Error e) {
	if (logval ==0)
	{
		parentlogger.log(LogStatus.FAIL, "Partial Text Value Comparison For Expected Value" + " "+ color.RMA_ChangeColor_Utility(ExpectedString, 3) + " " + "And Actual Value" + " " + color.RMA_ChangeColor_Utility(ActualString, 3) + " "  + "Is Not Successful And Error Occurred Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1));
	}
	else
	{
		logger.log(LogStatus.FAIL, "Partial Text Value Comparison For Expected Value" + " "+ color.RMA_ChangeColor_Utility(ExpectedString, 3) + " " + "And Actual Value" + " " + color.RMA_ChangeColor_Utility(ActualString, 3) + " "  + "Is Not Successful And Error Occurred Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(),1));
	}
	throw (e);
}
}

//============================================================================================
	//FunctionName 		: RMA_VerifyRowDataForTwoCol_NgGrid
	//Description  		: To Verify The Text In Particular Column of  A Table Based On The User Provided Two Search Value, 
	//Input Parameter 	: Element: Table Element, SearchText1: Text1 To Be Searched,SearchText2: Text2 To Be Searched, ExpectedValue: Expected value To Be Verified,  ExpectedCol: Column In Which The Value Is To Be Verified, idvalue:idvalue of NgGrid Table,  ObjDes: Name oF The Table
	//Revision			: 0.0 - ImteyazAhmad-12-29-2015                                 
	//============================================================================================
	public static void RMA_VerifyRowDataForTwoCol_NgGrid(WebElement Element,String SrchedText1, String SrchedText2, String ExpectedValue, int ExpectedCol, String idvalue, String ObjDes, int logval ) throws Exception,Error

	{
		try
		{
			String Found = "False";
			List<WebElement> EvenRowCount = Element.findElements(By.xpath(".//*[@class='ng-scope ngRow even']"));
			List<WebElement> OddRowCount = Element.findElements(By.xpath(".//*[@class='ng-scope ngRow odd']"));
			List<WebElement> ColumnCount = EvenRowCount.get(0).findElements(By.className("ng-binding"));
			int RowCount = EvenRowCount.size() + OddRowCount.size();
			System.out.println("Row Count is : "+RowCount);
			System.out.println("Col  Count is : "+ColumnCount.size());

			for (int i=1; i<=RowCount; i++)
			{				 
				//RMA_Selenium_POM_Home.RMAApp_TestNGGridLinkIterator(driver, y, x, tagname, idvalue)
				if (RMA_CheckTextInRowExists_NgGrid(SrchedText1,i,ColumnCount.size(),idvalue) && RMA_CheckTextInRowExists_NgGrid(SrchedText2,i,ColumnCount.size(),idvalue))
				{
					String Text = RMA_Selenium_POM_Home.RMAApp_TestNGGridLinkIterator(driver, i,ExpectedCol , "span", idvalue).getText();
					Found ="True";
					if (Text.equalsIgnoreCase(ExpectedValue))
					{
						if (logval == 0)
						{
							parentlogger.log(LogStatus.INFO, "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +"matched with Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",in Column :" +" " +ExpectedCol +" " +",Corresponding to indentifiers " +" " +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"and " +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", in"+" " +color.RMA_ChangeColor_Utility(ObjDes,4));
						}

						else
						{
							logger.log(LogStatus.INFO, "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +"matched with Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",in Column :" +" " +ExpectedCol +" " +",Corresponding to indentifiers " +" " +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"and " +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", in"+" " +color.RMA_ChangeColor_Utility(ObjDes,4));	
						}


					}
					else 
					{
						String ErrorMsg1 = "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +",not matched with Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",in Column :" +" " +ExpectedCol +" " +",Corresponding to indentifiers " +" " +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"and " +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", in"+" " +ObjDes;
						if (logval == 0)
						{
							parentlogger.log(LogStatus.FAIL,color.RMA_ChangeColor_Utility(ErrorMsg1, 1) );
							Assert.fail();
						}

						else
						{
							logger.log(LogStatus.FAIL,color.RMA_ChangeColor_Utility(ErrorMsg1, 1) );
							Assert.fail();
						}
					}				
				}
			}

			if (Found == "False")
			{
				String Errormsg = "Corresponding identifiers SrchedText1 :" +" " +SrchedText1 +" and SrchedText2 :" +" " +SrchedText2 +" "+"  do not exists in " +" " +ObjDes;
				if (logval == 0)
				{
					parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(Errormsg, 1) );
					Assert.fail();
				}
				else
				{
					logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(Errormsg, 1) );
					Assert.fail();
				}
			}

		}catch(Exception|Error e)
		{
			if (logval == 0)
			{
				parentlogger.log(LogStatus.FAIL, "Unexpected Error has occurred while calling method : RMA_VerifyRowDataForTwoCol_NgGrid and Error message is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(), 1));
				Assert.fail();
				throw(e);
			}

			else
			{
				logger.log(LogStatus.FAIL, "Unexpected Error has occurred while calling method : RMA_VerifyRowDataForTwoCol_NgGrid and Error message is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(), 1));
				Assert.fail();
				throw(e);
			}
		}
	}

	//============================================================================================
	//FunctionName 		: RMA_CheckTextInRowExists_NgGrid
	//Description  		: To Verify The Text In Particular Row of  A Table Based On The User Provided Search Value, 
	//Input Parameter 	: SearchedText: Text To Be Searched,Row: Row in which Text to be searched, ColumnCount1: Column Count of Row, idvalue:idvalue of NgGrid table
	//Revision			: 0.0 - ImteyazAhmad-12-29-2015                                 
	//============================================================================================
	private static Boolean RMA_CheckTextInRowExists_NgGrid(String SearchedText, int Row, int ColumnCount1, String idvalue )

	{
		Boolean TextFound = true;
		Boolean TextNotFound = false;

		//ColumnCount = ColumnCount-1;
		//loop:
			for (int j=1; j<=ColumnCount1; j++ )
			{
				String CellTextValue = RMA_Selenium_POM_Home.RMAApp_TestNGGridLinkIterator(driver, Row, j, "span", idvalue).getText();	
				if (CellTextValue.equalsIgnoreCase(SearchedText))
				{
					System.out.println("The Text value is :" +" " +CellTextValue);
					return TextFound;
				}

			}
		return TextNotFound;

	}
	
//============================================================================================
//FunctionName 		: RMA_RowColCountVerify_Utility
//Description  		: To Verify Number Of Rows And Column In A Table Based On The User Provided Row And Column Count
//Input Parameter 	: Element: Table Element, SearchText: Text To Be Searched, col1 and col2: Columns In Which The Value Is To Be Verified, ExpVal1, ExpVall2: Values To Be Verified, TableName: Name Of The Table
//Revision			: 0.0 - KumudNaithani-02-01-2016                                
//============================================================================================
public static int RMA_RowColCountVerify_Utility(WebElement Element, int ExpCol, int ExpRow, boolean RowVerify , boolean ColVerify, String TableName, int logval) throws Exception, Error
{
	try {
		int IntTable_ColumnsCount;
		//Local Variable Declaration
		
		List<WebElement> table_rows = Element.findElements(By.tagName("tr")); //All The Row Elements Of The Table Are Fetched In A List
		IntTable_RowsCount = table_rows.size(); //RowCount Is Stored In Variable IntTable_RowsCount
		//System.out.println(IntTable_RowsCount);
		for (int row=0; row<IntTable_RowsCount; row++){ //Loop Is Iterated Through All The Rows Of The Table
			List<WebElement> table_rows_columns = table_rows.get(row).findElements(By.tagName("td")); //All The Column Elements Of The Table Are Fetched In A List
			IntTable_ColumnsCount = table_rows_columns.size(); //Count Of The Number Of Columns In The Row Is Taken
			//System.out.println("fun"+IntTable_ColumnsCount);
			if (ColVerify == true)
			{
				System.out.println("reached col");
				if (ExpCol == IntTable_ColumnsCount){
					
					if (logval==0)
					{
						parentlogger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ "Expected Column Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+ "And Actual Column Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + "Are Equal Hence Column Count Verification Is Successful" );  
					}
					else
					{
						logger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ "Expected Column Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+ "And Actual Column Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + "Are Equal Hence Column Count Verification Is Successful" );
					}
				}
				
				else
				{
					if (logval==0)
					{
						parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ color.RMA_ChangeColor_Utility("Expected Column Count::", 1) + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+ color.RMA_ChangeColor_Utility("And Actual Column Count::", 1) + " " + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + color.RMA_ChangeColor_Utility("Are Not Equal Hence Column Count Verification Is Successful", 1) );  
					}
					else
					{
						logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ color.RMA_ChangeColor_Utility("Expected Column Count::", 1) + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+  color.RMA_ChangeColor_Utility("And Actual Column Count::", 1) + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + color.RMA_ChangeColor_Utility("Are Not Equal Hence Column Count Verification Is Successful", 1));
					}
				}
		
			Assert.assertTrue(ExpCol == IntTable_ColumnsCount);
		}
		}
		
		if (RowVerify == true)
		{
			if (ExpRow == IntTable_RowsCount){
				
				if (logval==0)
				{
					parentlogger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ "Expected Row Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+ "And Actual Row Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + "Are Equal Hence Row Count Verification Is Successful" );  
				}
				else
				{
					logger.log(LogStatus.PASS, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ "Expected Row Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+ "And Actual Row Count::" + " " + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + "Are Equal Hence Row Count Verification Is Successful" );
				}
			}
			
			else
			{
				if (logval==0)
				{
					parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ color.RMA_ChangeColor_Utility("Expected Row Count::", 1) + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+ color.RMA_ChangeColor_Utility("And Actual Row Count::", 1) + " " + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + color.RMA_ChangeColor_Utility("Are Not Equal Hence Row Count Verification Is Successful", 1) );  
				}
				else
				{
					logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility("For Table::", 1) + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " "+ color.RMA_ChangeColor_Utility("Expected Row Count::", 1) + " " + color.RMA_ChangeColor_Utility(String.valueOf(ExpRow), 3)+ " "+  color.RMA_ChangeColor_Utility("And Actual Row Count::", 1) + color.RMA_ChangeColor_Utility(String.valueOf(IntTable_RowsCount), 2) + " " + color.RMA_ChangeColor_Utility("Are Not Equal Hence Row Count Verification Is Successful", 1));
				}
			}
			Assert.assertTrue(ExpRow == IntTable_RowsCount);	
		}
		
		
	} catch (Exception|Error e) {
		if (logval ==0)
		   {
			   parentlogger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Column And Row Count Verification Failed Due To Reason:" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1) );  
		   }
		   else
		   {
			   logger.log(LogStatus.FAIL, "For Table::" + " " + color.RMA_ChangeColor_Utility(TableName, 4) + " " + "Column And Row Count Verification Failed Due To Reason:" + " " + color.RMA_ChangeColor_Utility(e.getMessage(),1) );   
		   }
		throw(e);
	}
	
	return IntTable_RowsCount;
	 }
	 
	 	//============================================================================================
	//FunctionName 		: RMA_VerifyRowDataForTwoColTablePartially
	//Description  		: To Verify The Text In Particular Column of  A Table Based On The User Provided Two Search Value, 
	//Input Parameter 	: Element: Table Element, SearchText1: Text1 To Be Searched,SearchText2: Text2 To Be Searched, ExpectedValue: Expected value To Be Verified,  ExpectedCol: Column In Which The Value Is To Be Verified, ObjDes: Name oF The Table
	//Revision			: 0.0 - ImteyazAhmad-02-04-2016                                
	//============================================================================================
	public static void RMA_VerifyRowDataForTwoColTablePartially(WebElement Element,String SrchedText1, String SrchedText2, String ExpectedValue, int ExpectedCol, String ObjDes, int logval ) throws Exception,Error
	{
		try
		{
			SrchedText1 = SrchedText1.toUpperCase();
			SrchedText2 = SrchedText2.toUpperCase();
			ExpectedValue = ExpectedValue.toUpperCase();
			ExpectedValue = ExpectedValue.trim();
			String Found = "False";			
			List<WebElement> TableRows = Element.findElements(By.tagName("tr"));
			loop:
			for (int i=0; i<TableRows.size(); i++)				
			{	
				List<WebElement> TableCol = TableRows.get(i).findElements(By.tagName("td"));				
				if (RMA_CheckTextInRowExistsTablePartially(TableCol,  SrchedText1) && RMA_CheckTextInRowExistsTablePartially(TableCol, SrchedText2))
				{ 
					String Text = TableCol.get(ExpectedCol-1).getText();
					Text = Text.toUpperCase();
					if (Text.contains(ExpectedValue))
					{
						Found ="True";
						if (logval == 0)
						{
							parentlogger.log(LogStatus.PASS, "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +"Available In Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",In Column :" +" " +ExpectedCol +" " +",Corresponding To Indentifiers SearchedText1 :" +" "  +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"And SearchedText2 :" +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", In"+" " +color.RMA_ChangeColor_Utility(ObjDes,4) +" "+", And Hence Verification Is Successfull");
						}

						else
						{
							logger.log(LogStatus.PASS, "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +"Available In Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",In Column :" +" " +ExpectedCol +" " +",Corresponding To Indentifiers SearchedText1 :" +" "  +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"And SearchedText2 :" +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", In"+" " +color.RMA_ChangeColor_Utility(ObjDes,4) +" "+", And Hence Verification Is Successfull");	
						}


					}
					else 
					{
						String ErrorMsg1 = "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +",Is Not Available In Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",In Column :" +" " +ExpectedCol +" " +",Corresponding To Indentifiers SearchedText1 :" +" " +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"And SearchedText2 : " +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", In"+" " +color.RMA_ChangeColor_Utility(ObjDes,4)+" "+" , And Hence Verification Is Not Successfull";
						if (logval == 0)
						{
							parentlogger.log(LogStatus.FAIL,color.RMA_ChangeColor_Utility(ErrorMsg1, 1) );
							Assert.fail();
						}

						else
						{
							logger.log(LogStatus.FAIL,color.RMA_ChangeColor_Utility(ErrorMsg1, 1) );
							Assert.fail();
						}
					}				
				break loop;
				}
			}

			if (Found == "False")
			{
				String Errormsg = "Corresponding Identifiers SearchedText1 :" +" " +SrchedText1 +" And SearchedText2 :" +" " +SrchedText2 +" "+"  Do Not Exists In Same Row Of Table " +" " +color.RMA_ChangeColor_Utility(ObjDes,4);
				if (logval == 0)
				{
					parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(Errormsg, 1) );
					Assert.fail();
				}
				else
				{
					logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(Errormsg, 1) );
					Assert.fail();
				}
			}

		}catch(Exception|Error e)
		{
			if (logval == 0)
			{
				parentlogger.log(LogStatus.FAIL, " Error Has Occurred While Calling Method : RMA_VerifyRowDataForTwoCol_NgGrid and Error Message Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(), 1));
			}
			else
			{
				logger.log(LogStatus.FAIL, "Error Has Occurred While Calling Method : RMA_VerifyRowDataForTwoCol_NgGrid and Error Message Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(), 1));
			}			
			throw(e);
		}
	}

	//============================================================================================
	//FunctionName 		: RMA_CheckTextInRowExistsTablePartially
	//Description  		: To Verify The Text In Particular Row of  A Table Based On The User Provided Search Value, 
	//Input Parameter 	: SearchedText: Text To Be Searched, TableCol : Collection of WebElement With Tag td
	//Revision			: 0.0 - ImteyazAhmad-12-29-2015                                 
	//============================================================================================
	private static Boolean RMA_CheckTextInRowExistsTablePartially(List<WebElement> TableCol , String SearchedText)
	{
		Boolean TextFound = true;
		Boolean TextNotFound = false;
		SearchedText = SearchedText.trim();
		
		for (int j = 0; j<TableCol.size(); j++)
		{
			String CellTextValue =  TableCol.get(j).getText();
			CellTextValue = CellTextValue.toUpperCase();
			if (CellTextValue.contains(SearchedText))
			{
				//System.out.println("The Text value is :" +" " +CellTextValue);
				return TextFound;
			}
		}
		return TextNotFound;
	}
	//============================================================================================
		//FunctionName 		: RMA_VerifyRowDataForTwoColTable
		//Description  		: To Verify The Text In Particular Column of  A Table Based On The User Provided Two Search Value, 
		//Input Parameter 	: Element: Table Element, SearchText1: Text1 To Be Searched,SearchText2: Text2 To Be Searched, ExpectedValue: Expected value To Be Verified,  ExpectedCol: Column In Which The Value Is To Be Verified, ObjDes: Name oF The Table
		//Revision			: 0.0 - ImteyazAhmad-02-04-2016                                
		//============================================================================================
		public static void RMA_VerifyRowDataForTwoColTable(WebElement Element,String SrchedText1, String SrchedText2, String ExpectedValue, int ExpectedCol, String ObjDes, int logval ) throws Exception,Error
		{
			try
			{
				ExpectedValue = ExpectedValue.trim();
				String Found = "False";			
				List<WebElement> TableRows = Element.findElements(By.tagName("tr"));
				loop:
				for (int i=0; i<TableRows.size(); i++)				
				{	
					List<WebElement> TableCol = TableRows.get(i).findElements(By.tagName("td"));				
					if (RMA_CheckTextInRowExistsTable(TableCol,  SrchedText1) && RMA_CheckTextInRowExistsTable(TableCol, SrchedText2))
					{ 
						String Text = TableCol.get(ExpectedCol-1).getText();
						if (Text.equalsIgnoreCase(ExpectedValue))
						{
							Found ="True";
							if (logval == 0)
							{
								parentlogger.log(LogStatus.PASS, "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +"Matched With Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",In Column :" +" " +ExpectedCol +" " +",Corresponding To Indentifiers SearchedText1 :" +" "  +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"And SearchedText2 :" +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", In"+" " +color.RMA_ChangeColor_Utility(ObjDes,4) +" "+", And Hence Verification Is Successfull");
							}

							else
							{
								logger.log(LogStatus.PASS, "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +"Matched With Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",In Column :" +" " +ExpectedCol +" " +",Corresponding To Indentifiers SearchedText1 :" +" "  +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"And SearchedText2 :" +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", In"+" " +color.RMA_ChangeColor_Utility(ObjDes,4) +" "+", And Hence Verification Is Successfull");	
							}


						}
						else 
						{
							String ErrorMsg1 = "Expected Value : " +" " +color.RMA_ChangeColor_Utility(ExpectedValue,3) +" " +", Not Matched With Actual Value :"+" " +color.RMA_ChangeColor_Utility(Text,2) +" " +",In Column :" +" " +ExpectedCol +" " +",Corresponding To Indentifiers SearchedText1 :" +" " +color.RMA_ChangeColor_Utility(SrchedText1,2) +" " +"And SearchedText2 : " +" " +color.RMA_ChangeColor_Utility(SrchedText2,2)+" " +", In"+" " +color.RMA_ChangeColor_Utility(ObjDes,4)+" "+" , And Hence Verification Is Not Successfull";
							if (logval == 0)
							{
								parentlogger.log(LogStatus.FAIL,color.RMA_ChangeColor_Utility(ErrorMsg1, 1) );
								Assert.fail();
							}

							else
							{
								logger.log(LogStatus.FAIL,color.RMA_ChangeColor_Utility(ErrorMsg1, 1) );
								Assert.fail();
							}
						}				
					break loop;
					}
				}

				if (Found == "False")
				{
					String Errormsg = "Corresponding Identifiers SearchedText1 :" +" " +SrchedText1 +" And SearchedText2 :" +" " +SrchedText2 +" "+"  Do Not Exists In Same Row Of Table " +" " +color.RMA_ChangeColor_Utility(ObjDes,4);
					if (logval == 0)
					{
						parentlogger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(Errormsg, 1) );
						Assert.fail();
					}
					else
					{
						logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(Errormsg, 1) );
						Assert.fail();
					}
				}

			}catch(Exception|Error e)
			{
				if (logval == 0)
				{
					parentlogger.log(LogStatus.FAIL, " Error Has Occurred While Calling Method : RMA_VerifyRowDataForTwoCol_NgGrid and Error Message Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(), 1));
				}
				else
				{
					logger.log(LogStatus.FAIL, "Error Has Occurred While Calling Method : RMA_VerifyRowDataForTwoCol_NgGrid and Error Message Is :" +" " +color.RMA_ChangeColor_Utility(e.getMessage(), 1));
				}			
				throw(e);
			}
		}

		//============================================================================================
		//FunctionName 		: RMA_CheckTextInRowExistsTable
		//Description  		: To Verify The Text In Particular Row of  A Table Based On The User Provided Search Value, 
		//Input Parameter 	: SearchedText: Text To Be Searched, TableCol : Collection of WebElement With Tag td
		//Revision			: 0.0 - ImteyazAhmad-12-29-2015                                 
		//============================================================================================
		private static Boolean RMA_CheckTextInRowExistsTable(List<WebElement> TableCol , String SearchedText)
		{
			Boolean TextFound = true;
			Boolean TextNotFound = false;
			SearchedText = SearchedText.trim();	
			
			for (int j = 0; j<TableCol.size(); j++)
			{
				String CellTextValue =  TableCol.get(j).getText();
				if (CellTextValue.equalsIgnoreCase(SearchedText))
				{
					//System.out.println("The Text value is :" +" " +CellTextValue);
					return TextFound;
				}
			}
			return TextNotFound;
		}
}