package rmaseleniumutilties;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import rmaseleniumPOM.RMA_POM_SMS;
import com.relevantcodes.extentreports.LogStatus;
import rmaseleniumPOM.RMA_Selenium_POM_FinancialReserves;
import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentsCollections;


public class RMA_Functionality_Utility extends rmaseleniumtestscripts.RMA_TC_BaseTest {
static RMA_GenericUsages_Utility color = new RMA_GenericUsages_Utility();
public static String ReturnValue;
	
//====================================================================================================
//FunctionName 		: RMA_PaymentAddition_Utility
//Description  		: Enables The User To Add Payment 
//Input Parameter 	: Driver Of The Type Driver, BnkAccnt, PayeeType, TransType, Amount, LastName Of The Type String, Amount Of The Type Integer	 
//Revision			: 0.0 - KumudNaithani-01-19-2016                               
// ====================================================================================================
public static String RMA_PaymentAddition_Utility(String BankAccnt,String PayeeType, String TransType, int Amount, String LastName, String DisType, int val) throws Exception, Error
{
	try {
		logger = reports.startTest("TC_Payment Addition", "User Makes A New  Payment");
		String StrPrimaryWindowHandle;
		String StrSecPrimaryWindowHandle;
		//Local Variable Declaration
		
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FinReserves_Btn_AddPayment(driver), "Add Payment Button On Reserve Creation Page",val);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added Payment Addition Page Is Loaded");
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Lst_BankAccount(driver), BankAccnt, "Bank Account Drop Down List", "Payment Creation Page",val);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Lst_PayeeType(driver), PayeeType, "Payee Type Drop Down List", "Payment Creation Page",val);
		RMA_Input_Utility.RMA_SetTextValueandTabOut_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Txt_DistributionType(driver), "Distribution Type TextBox On Payment Creation Page", DisType,val);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added As Distribution Type Is Selected");
		RMA_Input_Utility.RMA_SetTextValueandTabOut_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Txt_LastName(driver), "Last Name Text Box On Payment Creation Page", LastName,val);
		
		StrSecPrimaryWindowHandle = driver.getWindowHandle(); //Window Handle Of The Current Window Is Fetched
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains Last Name Is Done
		RMA_Selenium_POM_PaymentsCollections.RMAApp_LastName_Lst_LastNameSelection(driver).sendKeys(Keys.ARROW_DOWN); //Intended Last Name Is Selected From LastName Selector On Last Name Selection Window On Payment Creation Page
		LastName = color.RMA_ChangeColor_Utility(LastName, 3);
		//logger.log(LogStatus.INFO, "Intended Last Name Selected From LastName Selector On Last Name Selection Window On Payment Creation Page Is" + " " + "::" + " "  + LastName.toUpperCase());
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentsCollections.RMAApp_LastName_Btn_ChooseHighLighted(driver), "Choose Highlighted Button On Last Name Selection Window On Payment Creation Page",val);
		driver.switchTo().window(StrSecPrimaryWindowHandle); //A Switch To The Parent Window Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added As A Switch To The Window Containing Financial Reserves Screen Is Done");
		//Bank Account, Payee Type, Distribution Type, Last Name Are Added
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver)); //A Switch To The Frame Containing RMA Application Menu Option Is Done
		int Resframeid = RMA_GenericUsages_Utility.RMA_FrameNavigation("ReservesFinancials");	
		driver.switchTo().frame(Resframeid); //A Switch To The Frame Containing Financial/Reserves Control Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added As A Switch To Financial/Reserves Frame Is Done");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Tab_TransactionDetail(driver), "Transaction Details Tab On On Payment Creation Page",val);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, val, "Wait Is Added As Transaction Tab Is Clicked");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Btn_AddNewPayment(driver), "Add Payment Button On Reserve Creation Page",val);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added As Add New Payment Button Is Clicked");
		//Add New Button Is Clicked And Funds Split Details View Is Opened
		
		StrPrimaryWindowHandle = driver.getWindowHandle(); //Window Handle Of The Current Window Is Fetched
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains Fund Splits Details Is Done
		RMA_Input_Utility.RMA_SetTextValueandTabOut_Utility(RMA_Selenium_POM_FinancialReserves.RMAApp_FundsSplitDetails_Lst_TransactionType(driver), "Transaction Type DropDown On Funds Details Window On Payment Creation Page", TransType,val);	
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_FinancialReserves.RMAApp_FundsSplitDetails_Txt_Amount(driver), "Amount TextBox On Funds Details Window On Payment Creation Page", String.valueOf(Amount),val);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FundsSplitDetails_Btn_OK(driver), "OK Button On Funds Details Window On Payment Creation Page",val);// OK Button Is Clicked  On Funds Details Window On Payment Creation Page
		// Payment Is Added And Funds Split Details View Is Closed
		
		driver.switchTo().window(StrPrimaryWindowHandle);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added As A Switch To The Window Containing Financial Reserves Screen Is Done");
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver)); //A Switch To The Frame Containing RMA Application Menu Option Is Done
		//driver.switchTo().frame(2); //A Switch To The Frame Containing Financial/Reserves Control Is Done
		Resframeid = RMA_GenericUsages_Utility.RMA_FrameNavigation("ReservesFinancials");	
		driver.switchTo().frame(Resframeid);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added As A Switch To Financial/Reserves Frame Is Done");;
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_Payment_Btn_Save(driver), "Save Button On Payment Creation Page",val);// Save Button Is Clicked On Payment Creation Page
		RMA_GenericUsages_Utility.RMA_StaticWait(5, val, "Wait Is Added As Payment Transaction Is Getting Saved");
		//Save Button Is Clicked To Save The Transaction
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Tab_Transaction(driver), "Transaction Tab On Payment Creation Page",val);// Transaction Tab On Payment Creation Page Is Clicked
		ReturnValue = RMA_Selenium_POM_FinancialReserves.RMAApp_Payment_Txt_ControlNumber(driver).getAttribute("value"); //Generated Control Number Is Stored In Variable StrControlNumber
		String StrlogControlNumber_RMA_TC_006 = color.RMA_ChangeColor_Utility(ReturnValue, 2);
		logger.log(LogStatus.PASS, "Payment Is Suceessfully Done And The Generated Control Number Is" + " " + "_"+ " " + StrlogControlNumber_RMA_TC_006);
		RMA_ExcelDataRetrieval_Utility.WriteDataToExcel(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMASeleniumAutomationTestData.xlsx","RMA_TC_006", 10, 0, ReturnValue);  //Control Number Is Written In RMA_TC_006 Excel Sheet
		logger.log(LogStatus.INFO, "Generated ControlNumber:" + " " + StrlogControlNumber_RMA_TC_006 + " " + "Is Also Written In The Corresponding Excel Data Sheet RMA_TC_006");
		return ReturnValue;
	
	} catch (Exception|Error e) {
		throw (e);
	}
}


//====================================================================================================
//FunctionName 		: RMA_ReserveAddition_Utility
//Description  		: Enables The User To Add Reserve 
//Input Parameter 	: Driver Of The Type Driver, Reserve Amount, Status, ReserveType Of The Type String, Amount Of The Type Integer	 
//Revision			: 0.0 - KumudNaithani-01-19-2016                               
//====================================================================================================
public static void RMA_ReserveAddition_Utility( int ReserveAmount, String Status, int logval, String ReserveType, String StrHold, String StrErrMsg, String StrExpReserveStatus, String CompFlg, String PopUpVerifyMessage) throws Exception, Error
{
	try {
		logger = reports.startTest("Reserve Creation", "A New Reserve Is Created");
		String StrExpected_ReserveTable_ReserveAmount;
		int iterator;
		//Local Variable Declaration
	
		StrExpected_ReserveTable_ReserveAmount = "$"+ReserveAmount+ ".00";

		iterator =  RMA_GenericUsages_Utility.RMA_FrameNavigation("ReservesFinancials");
		driver.switchTo().frame(iterator); //A Switch To The Frame Containing Financial/Reserves Control Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As A Switch To Reserves/Financials Frame Is Done");
		
		if (ReserveType.equalsIgnoreCase("M Medical"))
		{
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FinReserves_Lnk_M_Medical(driver), "Created General Claim's Medical Reserve Option On Financial Reserves Page",logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Created General Claim's Medical Reserve Option On Financial Reserves Page Is Clicked");
		}
		else if (ReserveType.equalsIgnoreCase("L Litigation"))
		{
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FinReserves_Lnk_L_Litigation(driver), "Created General Claim's Litigation Reserve Option On Financial Reserves Page",logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Created General Claim's Litigation Reserve Option On Financial Reserves Page Is Clicked");
		}
		else if (ReserveType.equalsIgnoreCase("E Expense"))
		{
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FinReserves_Lnk_E_Expense(driver), "Created General Claim's Expense Reserve Option On Financial Reserves Page",logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Created General Claim's Expense Reserve Option On Financial Reserves Page Is Clicked");
		}
		else if (ReserveType.equalsIgnoreCase("B BodilyInjury"))
		{
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FinReserves_Lnk_BI_Bodily_Injury(driver), "Created General Claim's BodilyInjury Reserve Option On Financial Reserves Page",logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Created General Claim's BodilyInjury Reserve Option On Financial Reserves Page Is Clicked");
		}
		else if (ReserveType.equalsIgnoreCase("I Indemnity"))
		{
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FinReserves_Lnk_I_Indemnity(driver), "Created General Claim's Indemnity Reserve Option On Financial Reserves Page",logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Created General Claim's Indemnity Reserve Option On Financial Reserves Page Is Clicked");
		}
		else if (ReserveType.equalsIgnoreCase("RC REC Recovery"))
		{
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_FinReserves_Lnk_RC_REC_Recovery(driver), "Created General Claim's Recovery Reserve Option On Financial Reserves Page",logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Created General Claim's Recovery Reserve Option On Financial Reserves Page Is Clicked");
		}
			
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_FinancialReserves.RMAApp_ReserveCreation_Txt_ReserveAmount(driver), "Reserve Amount Field On Reserve Creation Page", String.valueOf(ReserveAmount),logval);	
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_FinancialReserves.RMAApp_ReserveCreation_Lst_Status(driver), Status,"User/Group List Box","Reserve Status List Box On Reserve Creation Page",logval);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_FinancialReserves.RMAApp_ReserveCreation_Btn_Modify(driver), "Modify Button Is Clicked On Reserve Creation Page",logval);	
		RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As Modify Button Is Clicked On Reserve Creation Page Is Clicked");
		
		
		if (StrHold == "Yes"){
			RMA_GenericUsages_Utility.RMA_WindMsgHandlerAndTextVerify_Utility("Yes", CompFlg, StrErrMsg, PopUpVerifyMessage, logval);
		}
		RMA_Verification_Utility.RMA_TableVerifyText_Utility(RMA_Selenium_POM_FinancialReserves.RMAApp_ReserveCreation_Tbl_Reserve(driver), ReserveType, 4, StrExpected_ReserveTable_ReserveAmount, 5, StrExpReserveStatus, "ReserveGrid",logval);

	} catch (Exception|Error e) {
		throw (e);
		}
		}
	//====================================================================================================
	//FunctionName 		: RMA_UserAdditionUtility
	//Description  		: Enables To Add Users In SMS
	//Input Parameter 	:  Input Parameters are UserNameStatic,Email,Manager,DSN,ModuleGroup and logval
	//Revision			: 0.0 - ImteyazAhmad-01-22-2016                               
	//====================================================================================================
	public static String RMA_UserAdditionUtility(String UserNameStatic, String Email, String Manager, String DSN, String ModuleGroup, int logval) throws Exception, Error
	{
		String UserName;
		String UserFisrtAndLastName;
		String UserActual = null;
		String ObjDescription;
		boolean Found = false;
		try{
			logger = reports.startTest("User Addition", "A New User Is Added");
			DSN = DSN.trim();
			ModuleGroup = ModuleGroup.trim();
			Email = Email.trim();
			Manager = Manager.trim();
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(logval);
			String StrPrimaryWindowHandle = driver.getWindowHandle();
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", logval);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,4), "Security-->User Privileges SetUp Menu Option", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(7, logval, "Wait Is Added As SMS Window Is Loaded");
			RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility();
			driver.manage().window().maximize();			
			UserName = RMA_GenericUsages_Utility.RMA_RandomStringGeneration_Utility(2, UserNameStatic);
			UserName = UserName.trim().toUpperCase();
			UserFisrtAndLastName = UserName+" "+UserName;
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_AddNewUser(driver), "AddNewUser Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As AddNewUser Image On SMS Page Is Clicked");
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_POM_SMS.RMAApp_SMS_Txt_LastName(driver), "LastName TextBox On SMS Page", UserName, logval);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_POM_SMS.RMAApp_SMS_Txt_FirstName(driver), "FisrtName TextBox On SMS Page", UserName, logval);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_POM_SMS.RMAApp_SMS_Txt_Email(driver), "Email TextBox On SMS Page", Email, logval);

			if (Manager == "")
			{
				RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_POM_SMS.RMAApp_SMS_Lst_Manager(driver), 0, "Manager", "SMS", logval);	
			}
			else
			{
				RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_POM_SMS.RMAApp_SMS_Lst_Manager(driver),Manager , "Manager DropDown", "SMS", logval);	
			}

			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_POM_SMS.RMAApp_SMS_Chk_PermitAccessToSMS(driver), "check", "PermitAccessToSMS CheckBox", "SMS Page", logval);
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_POM_SMS.RMAApp_SMS_Chk_PermitAccessToUserPrivilegesSetup(driver), "check", "PermitAccessToUserPrivilegesSetup CheckBox", "SMS Page", logval);
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_POM_SMS.RMAApp_SMS_Lst_DataSources(driver), DSN, "DataSources DropDown", "SMS", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");			
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_Save(driver), "Save Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As SMS Page Is Saved");
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");			
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_POM_SMS.RMAApp_SMS_Txt_LoginName(driver), "LoginName On SMS Page", UserName, logval);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_POM_SMS.RMAApp_SMS_Txt_Password(driver), "Password On SMS Page", UserName, logval);
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_POM_SMS.RMAApp_SMS_Lst_ModuleGroup(driver), ModuleGroup, "ModuleGroup DropDown", "SMS", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");			
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_Save(driver), "Save Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As SMS Page Is Saved");

			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(4, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_LeftTreeFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As Switch To LeftTree Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_ExpandCollapse(driver, "RISKMASTER SECURITY"), "Expand Image Corresponding To RISKMASTER SECURITY On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, logval, "Wait Is Added As Expand Image Corresponding To RISKMASTER SECURITY Is Clicked");
			WebElement Element = driver.findElement(By.xpath("//a[contains(text(),'"+ModuleGroup+"')]/following::div"));
			List<WebElement> ElementTable = Element.findElements(By.tagName("table"));
			outerloop:
				for (int i=0; i< ElementTable.size(); i++)				
				{
					System.out.println("First For Loop :" +i);
					List<WebElement> ElementTd = ElementTable.get(i).findElements(By.tagName("td"));
					for (int j = 0; j < ElementTd.size(); j++)
					{
						System.out.println("Second For Loop :" +j);			
						List<WebElement> ElementA = ElementTd.get(j).findElements(By.tagName("a"));

						for ( int k = 0; k < ElementA.size(); k++)
						{
							System.out.println("Third For Loop :" +k);
							UserActual = ElementA.get(k).getText();
							//System.out.println(UserActual);
							if (UserActual.equalsIgnoreCase(UserFisrtAndLastName))
							{
								Found = true;
								logger.log(LogStatus.PASS, "Expected User Name :" +" "+color.RMA_ChangeColor_Utility(UserFisrtAndLastName,3) +" " +"Is Equal To Actual User Name :" +" " +color.RMA_ChangeColor_Utility(UserActual,2) +" " +"And Added To Module Group :" +" " +color.RMA_ChangeColor_Utility(ModuleGroup, 4));
								break outerloop;
							}
						}

					}

				}
			if (Found == false){
				ObjDescription = "Expected User Name :" +" "+color.RMA_ChangeColor_Utility(UserFisrtAndLastName,3) +" " +"Is Not Equal To Actual User Name :" +" " +color.RMA_ChangeColor_Utility(UserActual,2) +" " +"Which Is Verified Under Module Group :" +" " +color.RMA_ChangeColor_Utility(ModuleGroup, 4);
				//System.out.println("Not Matched");
				logger.log(LogStatus.FAIL, color.RMA_ChangeColor_Utility(ObjDescription, 1));
				logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "UserAdditionNotSuccessful", "UserAdditionUtility")));
			    Assert.fail();
			}			
			logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "UserAddition", "UserAdditionUtility")));
			driver.close();
			driver.switchTo().window(StrPrimaryWindowHandle);
		}catch(Exception|Error e){
			//System.out.println("Error Message is :" +e.getMessage());
			throw(e);
		}
		return UserName;
	}
	
	//====================================================================================================
	//FunctionName 		: RMA_UserDeletionUtility
	//Description  		: Enables To Add Users In SMS
	//Input Parameter 	:  Input Parameters Are : UserNameDelete and logval
	//Revision			: 0.0 - ImteyazAhmad-01-22-2016                               
	//====================================================================================================

	public static void RMA_UserDeletionUtility(String UserNameDelete, int logval) throws Exception, Error 
	{
		try{
			logger = reports.startTest("User Deletion", "User Is Deleted");	
			UserNameDelete = UserNameDelete.trim();
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(logval);
			String StrPrimaryWindowHandle = driver.getWindowHandle();
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", logval);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,4), "Security-->User Privileges SetUp Menu Option", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(7, logval, "Wait Is Added As SMS Window Is Loaded");
			RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility();
			driver.manage().window().maximize();			
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_LeftTreeFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To LeftTree Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_ExpandCollapse(driver, "User"), "Expand Image Corresponding To Users On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Expand Image Corresponding To Users Is Clicked");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect(UserNameDelete, "SMS Page", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_Delete(driver), "Delete Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As Delete Image Is Clicked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, "Yes");
			driver.close();
			driver.switchTo().window(StrPrimaryWindowHandle);
		}catch(Exception|Error e){
			//System.out.println("Error Message Is :" +e.getMessage());
			throw(e);
		}
	}

	//====================================================================================================
	//FunctionName 		: RMA_ModuleGroupAddition
	//Description  		: Enables To Add ModuleGroup In SMS
	//Input Parameter 	: Input Parameters Are : ModuleGrpNameStatic, DSN and logval
	//Revision			: 0.0 - ImteyazAhmad-01-23-2016                               
	//====================================================================================================
	public static String RMA_ModuleGroupAddition (String ModuleGrpNameStatic, String DSN, int logval) throws Exception, Error
	{  
		String ModuleGroupName;
		try
		{
			logger = reports.startTest("ModuleGroup Addition", "A New ModuleGroup Is Added");	
			String Text1;
			String StrModuleSecurity;			
			StrModuleSecurity = "Module Security Groups";
			ModuleGroupName =  RMA_GenericUsages_Utility.RMA_RandomStringGeneration_Utility(2, ModuleGrpNameStatic);
			ModuleGroupName = ModuleGroupName.trim();
			DSN = DSN.trim();
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(logval);
			String StrPrimaryWindowHandle = driver.getWindowHandle();
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", logval);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,4), "Security-->User Privileges SetUp Menu Option", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(7, logval, "Wait Is Added As SMS Window Is Loaded");
			RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility();
			driver.manage().window().maximize();			
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_LeftTreeFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To LeftTree Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_ExpandCollapse(driver, "Data Source"), "Expand Image Corresponding To Data Sources On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Expand Image Corresponding To Data Sources Is Clicked");
			Text1 = "Expand Image Corresponding To Data Sources :" +" "+DSN+" " +"On SMS Page";
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_ExpandCollapse(driver, DSN), Text1, logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Expand Image Corresponding To DataSources Is Clicked");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect(StrModuleSecurity, "SMS Page", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_AddNewModuleGroup(driver), "AddNewModuleGroup Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As AddNewModuleGroup Image Is Clicked");
			RMA_GenericUsages_Utility.RMA_WindowSwitchingBasedOnTitle("Add New Module Gr");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_POM_SMS.RMAApp_SMSModuleGrp_Txt_GroupName(driver), "GroupName TextBox On SMS>>Module Group Window", ModuleGroupName, logval);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMSModuleGrp_Btn_OK(driver), "Ok Button On SMS>>Module Group Window", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As Ok Button On SMS>>Module Group Window Is Clicked");
			RMA_GenericUsages_Utility.RMA_WindowSwitchingBasedOnTitle("RiskMaster Secu");

			//Permission Is Granted To Riskmaster And Its Sub Module
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("RISKMASTER", "SMS", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(15, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");

			//Permission Is Granted To Utilities And Its Sub Module
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Utilities", "SMS", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(8, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");
			
			//Permission Is Granted To Standard Reports And Its Sub Module
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Standard Reports", "SMS", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(8, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");

			
			//Permission Is Granted To SORTMASTER And Its Sub Module
			/*driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("SORTMASTER", "SMS", logval);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(15, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");

			

			//Permission Is Granted To Quick Entry And Its Sub Module
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Quick Entry", "SMS", logval);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(15, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");

			//Permission Is Granted To Data Import System And Its Sub Module
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Data Import System", "SMS", logval);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(10, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");

			//Permission Is Granted To Event Scheduler And Its Sub Module
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Event Scheduler", "SMS", logval);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(15, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");

			
			//Permission Is Granted To Executive Summary And Its Sub Module
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Executive Summary", "SMS", logval);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(15, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked");

			//Permission Is Granted To DCC.net And Its Sub Module
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_MainFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To MainFrame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("DCC.net", "SMS", logval);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To ToolBar Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_GrantPermissionToSelectedAndSubModule(driver), "GrantPermissionToSelectedAndSubModule Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(15, logval, "Wait Is Added GrantPermissionToSelectedAndSubModule Image Is Clicked"); */

			driver.close();
			driver.switchTo().window(StrPrimaryWindowHandle);

		}catch(Exception|Error e)
		{
			//System.out.println("Error Message Is :" +" " +e.getMessage());
			throw(e);
		}
		return ModuleGroupName;
	}

	//====================================================================================================
	//FunctionName 		: RMA_ModuleGroupDeletion
	//Description  		: Enables To Delete ModuleGroup In SMS
	//Input Parameter 	: Input Parameters Are :
	//Revision			: 0.0 - ImteyazAhmad-01-23-2016                               
	//====================================================================================================
	public static void RMA_ModuleGroupDeletion(String ModuleGroupName, String DSN, int logval) throws Exception, Error
	{
		try{
			logger = reports.startTest("ModuleGroup Deletion", "ModuleGroup Is Deleted");	
			String Text1;
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(logval);
			ModuleGroupName = ModuleGroupName.trim();
			DSN = DSN.trim();
			String StrPrimaryWindowHandle = driver.getWindowHandle();
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", logval);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,4), "Security-->User Privileges SetUp Menu Option", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(7, logval, "Wait Is Added As SMS Window Is Loaded");
			RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility();
			driver.manage().window().maximize();			
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_LeftTreeFrame(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To LeftTree Frame On SMS Page Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_ExpandCollapse(driver, "Data Source"), "Expand Image Corresponding To Data Sources On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Expand Image Corresponding To Data Sources Is Clicked");
			Text1 = "Expand Image Corresponding To Data Sources :" +" "+DSN+" " +"On SMS Page";
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_ExpandCollapse(driver, DSN), Text1, logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Expand Image Corresponding To DataSources On SMS Page Is Clicked");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_ExpandCollapseModulesecurityGroup(driver, DSN), "Expand Image Corresponding To Module Security Group On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Expand Image Corresponding To  Module Security Group On SMS Page Is Clicked");
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect(ModuleGroupName, "SMS Page", logval);
			driver.switchTo().defaultContent();
			RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Switch To Default Frame On SMS Page Is Done");
			driver.switchTo().frame(RMA_POM_SMS.RMAApp_SMS_Frm_ToolBarFrame(driver));
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_SMS.RMAApp_SMS_Img_Delete(driver), "Delete Image On SMS Page", logval);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, logval, "Wait Is Added As Delete Image Is Clicked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, "Yes");
			driver.close();
			driver.switchTo().window(StrPrimaryWindowHandle);
			
		}catch(Exception|Error e)
		{
			//System.out.println("Error Message Is :" +" " + e.getMessage());
			throw(e);
		}
	}	
	}
