package rmaseleniumPOM;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_Selenium_POM_Litigation {
	public static WebElement Element = null;
	public static List<WebElement> ElementList = null;
//============================================================================================
//FunctionName 			: RMAApp_Litigation_Txt_DocketNumber
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which DocketNumber Text Box On RMA Application Claim Litigation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
// ============================================================================================
public static WebElement RMAApp_Litigation_Txt_DocketNumber(WebDriver driver)
{
	Element = driver.findElement(By.id("docketnumber")); //Unique Id DocketNumber Text Box On RMA Application Claim Litigation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_Litigation_Img_Save
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Save Image On RMA Application Claim Litigation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
//============================================================================================
public static WebElement RMAApp_Litigation_Img_Save(WebDriver driver)
{
	Element = driver.findElement(By.id("save")); //Unique Id Of Save Image On RMA Application Claim Litigation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_Litigation_Img_Delete
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Delete Image On RMA Application Claim Litigation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
//============================================================================================
public static WebElement RMAApp_Litigation_Img_Delete(WebDriver driver)
{
	Element = driver.findElement(By.id("Delete")); ////Unique Id Of Save Image On RMA Application Claim Litigation Page Is Fetched
	return Element;
}

}
