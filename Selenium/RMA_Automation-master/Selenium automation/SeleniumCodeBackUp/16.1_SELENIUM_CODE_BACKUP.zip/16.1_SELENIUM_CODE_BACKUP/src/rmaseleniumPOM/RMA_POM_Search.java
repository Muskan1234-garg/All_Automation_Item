package rmaseleniumPOM;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_POM_Search {

	public static WebElement Element = null;

	//============================================================================================
	//FunctionName 			: RMAApp_SearchFunds_Txt_ControlNumber
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Funds Control Number Text Box on Search Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-01-11-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_SearchFunds_Txt_ControlNumber(WebDriver driver)
	{
		Element = driver.findElement(By.id("FLD35000")); //Unique Id  Of  Funds Control Number on Search Page Is Fetched
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_Search_Chk_Soundex
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which  Soundex CheckBox  on Search Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-01-11-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Search_Chk_Soundex(WebDriver driver)
	{
		Element = driver.findElement(By.id("soundex")); //Unique Id  Of  Soundex CheckBox on Search Page Is Fetched
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_Search_Btn_Submit
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Submit Button on Search Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-01-11-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Search_Btn_Submit(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnSubmit")); //Unique Id  Of  Submit Button on Search Page Is Fetched
		return Element;
	}
}
