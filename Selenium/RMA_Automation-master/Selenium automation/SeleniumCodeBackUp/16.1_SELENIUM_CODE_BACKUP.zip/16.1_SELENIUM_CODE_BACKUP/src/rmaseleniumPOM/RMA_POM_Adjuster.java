package rmaseleniumPOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_POM_Adjuster {

	public static WebElement Element = null;

	//============================================================================================
	//FunctionName 			: RMAApp_Adjuster_Txt_LastName
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Adjuster Last Name On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-22-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Adjuster_Txt_LastName(WebDriver driver)
	{
		Element = driver.findElement(By.id("adjlastname")); //Unique Id  Of  Adjuster Last Name On RMA Application Bank Account Page Is Fetched
		return Element;
	}


	//============================================================================================
	//FunctionName 			: RMAApp_Adjuster_Btn_AddNew
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Add New Button On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-22-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Adjuster_Btn_AddNew(WebDriver driver)
	{
		Element = driver.findElement(By.id("cmdKeep4")); //Unique Id  Of AddNew Button On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_Adjuster_Btn_RiskMasterLogin
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which RiskMasterLogin button On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-22-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Adjuster_Btn_RiskMasterLogin(WebDriver driver)
	{
		Element = driver.findElement(By.id("adjrmsysuser_rmsyslookupbtn")); //Unique Id  Of RiskMasterLogin Button On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_Adjuster_Tbl_SystemUsers
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which SystemUsers Table On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-22-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Adjuster_Tbl_SystemUsers(WebDriver driver)
	{
		Element = driver.findElement(By.id("gvUserList")); //Unique Id  Of SystemUsers Table On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_Adjuster_Btn_SystemUsers_Ok
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Ok on SystemUsers Table On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-22-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Adjuster_Btn_SystemUsers_Ok(WebDriver driver)
	{
		Element = driver.findElement(By.id("btnOkResrc")); //Unique Id  Of Ok on SystemUsers Table On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	//============================================================================================
	//FunctionName 			: RMAApp_Adjuster_Img_Save
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Save On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-22-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_Adjuster_Img_Save(WebDriver driver)
	{
		Element = driver.findElement(By.id("save")); //Unique Id  Of Save On RMA Application Bank Account Page Is Fetched
		return Element;
	}

}
