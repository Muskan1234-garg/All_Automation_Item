package rmaseleniumPOM;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_Selenium_POM_WorkersComp {
	public static WebElement Element = null;
	public static List<WebElement> ElementList = null;
//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_ClaimType
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which Claim Type TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
// ============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_ClaimType(WebDriver driver)
{
	Element = driver.findElement(By.id("claimtypecode_codelookup")); //Unique Id Of Claim Type TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_DepartmentID
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which Department ID TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_DepartmentID(WebDriver driver)
{
	Element = driver.findElement(By.id("ev_depteid")); //Unique Id Of Department ID TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_EmployeeNumber
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which Employee Number TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_EmployeeNumber(WebDriver driver)
{
	Element = driver.findElement(By.id("empemployeenumber")); //Unique Id Of Employee Number TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_EventNumber
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which Event Number TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_EventNumber(WebDriver driver)
{
	Element = driver.findElement(By.id("ev_eventnumber")); //Unique Id Of Event Number TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_ClaimNumber
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which Claim Number TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_ClaimNumber(WebDriver driver)
{
	Element = driver.findElement(By.id("claimnumber")); //Unique Id Of Claim Number TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_DateOfEvent
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which DateOfEvent TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_DateOfEvent(WebDriver driver)
{
	Element = driver.findElement(By.id("ev_dateofevent")); //Unique Id Of DateOfEvent TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_TimeOfEvent
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which TimeOfEvent TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_TimeOfEvent(WebDriver driver)
{
	Element = driver.findElement(By.id("ev_timeofevent")); //Unique Id Of TimeOfEvent TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_TimeOfClaim
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which TimeOfClaim TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_TimeOfClaim(WebDriver driver)
{
	Element = driver.findElement(By.id("timeofclaim")); //Unique Id Of TimeOfClaim TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_WorkersComp_Txt_DateOfClaim
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which DateOfClaim TextBox On RMA Application Workers Compensation Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-29-2015                                 
//============================================================================================
public static WebElement RMAApp_WorkersComp_Txt_DateOfClaim(WebDriver driver)
{
	Element = driver.findElement(By.id("dateofclaim")); //Unique Id Of DateOfClaim TextBox On RMA Application Worker's Compensation Page Is Fetched
	return Element;
}
}
