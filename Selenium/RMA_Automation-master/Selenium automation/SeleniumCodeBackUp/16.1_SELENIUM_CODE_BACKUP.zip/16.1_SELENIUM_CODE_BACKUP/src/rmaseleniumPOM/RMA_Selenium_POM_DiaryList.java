package rmaseleniumPOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//Default Package Import Completed

public class RMA_Selenium_POM_DiaryList {
 public static WebElement Element = null;
 
//============================================================================================
//FunctionName 			: RMAApp_Diaries_Frm_DiariesHome
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Diaries Frame On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-01-05-2015                                 
//============================================================================================
public static WebElement RMAApp_Diaries_Frm_DiariesHome(WebDriver driver)
{
	Element = driver.findElement(By.id("DiarieszDiaryListDiaryListDiary ListUI/Diaries/Diary ListFalseFalse")); //Unique Id Of Diaries Frame On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_Diaries_Frm_DiariesHome
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Diaries Table On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-01-05-2015                                 
//============================================================================================
public static WebElement RMAApp_Diaries_Tbl_DiariesHome(WebDriver driver)
{
	Element = driver.findElement(By.id("lstDiary_ctl00")); //Unique Id Of Diaries Table On RMA Application Default View Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_Diaries_Txt_TaskName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Task Name TextBox on Diaries Table On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - ImteyazAhmad-01-14-2015                                 
//============================================================================================
public static WebElement RMAApp_Diaries_Txt_TaskName(WebDriver driver)
{
	Element = driver.findElement(By.id("lstDiary_ctl00_ctl02_ctl02_FilterTextBox_tasksubject")); //Unique Id Of  Task Name TextBox on Diaries Table On RMA Application Default View Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_Diaries_Btn_TaskNameFilter
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Task Name Filtet Button on Diaries Table On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - ImteyazAhmad-01-14-2015                                 
//============================================================================================
public static WebElement RMAApp_Diaries_Btn_TaskNameFilter(WebDriver driver)
{
	Element = driver.findElement(By.id("lstDiary_ctl00_ctl02_ctl02_Filter_tasksubject")); //Unique Id Of  Task Name Filter Button on Diaries Table On RMA Application Default View Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_Diaries_Lnk_EqualTo
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which EqualTo Link on Diaries Table On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - ImteyazAhmad-02-12-2016                                
//============================================================================================
public static WebElement RMAApp_Diaries_Lnk_EqualTo(WebDriver driver)
{
	Element = driver.findElement(By.partialLinkText("EqualTo"));
	return Element;
}


}
