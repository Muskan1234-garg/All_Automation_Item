package rmaseleniumPOM;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//Default Package Import Completed

public class RMA_Selenium_POM_Home {
	public static WebElement Element = null;
	public static List<WebElement> ElementList = null;
//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Frm_MenuOptionFrame
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of DefaultFrame (containing menu options) On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
// ============================================================================================
public static WebElement RMAApp_DefaultView_Frm_MenuOptionFrame(WebDriver driver)
{
	Element = driver.findElement(By.id("cphMainBody_uwtPortal_frame0")); //Unique Id  Of DefaultFrame (containing menu options) On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Mnu_Options
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Menu Option On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
//===========================================================================================
public static WebElement RMAApp_DefaultView_Mnu_Options(WebDriver driver, int x, int y)
{
	Element = driver.findElement(By.xpath(".//*[@id='MDIMenu_"+x+"_"+y+"']"+"/tbody/tr/td[2]/nobr")); //Unique Id  Of SubMenu Options On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_FrmEventCreation
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Event Creation Frame On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-19-2015                                 
// ============================================================================================
public static WebElement RMAApp_DefaultView_FrmEventCreation(WebDriver driver)
{
	Element = driver.findElement(By.id("Document-1eventEventEvent (New)FalseFalse")); //Unique Id  Of Event Creation Frame On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Mnu_GeneralClaim
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Document Menu Option On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
// ============================================================================================
public static WebElement RMAApp_DefaultView_Mnu_Options(WebDriver driver, int x)
{
	Element = driver.findElement(By.xpath(".//*[@id='MDIMenu_"+x+"']/tbody/tr/td[2]/nobr")); //Unique Id  Of Menu Options On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Mnu_Options
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Context Menu Option On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
//============================================================================================
public static WebElement RMAApp_DefaultView_Mnu_Options(WebDriver driver, int x, int y, int z)
{
	Element = driver.findElement(By.xpath(".//*[@id='MDIMenu_"+x+"_"+y+"_"+z+"']"+"/tbody/tr/td[2]/nobr")); //Unique Id  Of Context Menu Options On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Frm_GeneralClaim
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which General Claim Frame On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-21-2015                                 
// ============================================================================================
public static WebElement RMAApp_DefaultView_Frm_GeneralClaim(WebDriver driver)
{
	Element = driver.findElement(By.id("Document-2-1claimgcGeneral ClaimGeneral Claim (New)FalseFalse")); //Unique Id  Of General Claim Frame On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Frm_LineOfBusinessParameterSetUp
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Line Of Business Parameter SetUp Frame On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-19-2015                                 
// ============================================================================================
public static WebElement RMAApp_DefaultView_Frm_LineOfBusinessParameterSetUp(WebDriver driver)
{
	Element = driver.findElement(By.id("UtilitieszLOBParametersLOBParametersLine Of Business Parameter SetupUI/Utilities/Manager/Line Of Business Parameter SetupFalseFalse")); //Unique Id  Of  Line Of Business Parameter SetUp Frame On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Lnk_LogOut
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which LogOut Link On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-20-2015                                 
// ============================================================================================
public static WebElement RMAApp_DefaultView_Lnk_LogOut(WebDriver driver)
{
	Element = driver.findElement(By.id("cphMainBody_Loginstatus1")); //Unique Id  Of  LogOut Link On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_LeftHandNavTree_Img_GCExpander
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which GC Expander On Left Hand Navigation Tree Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-21-2015                                 
// ============================================================================================
public static WebElement RMAApp_LeftHandNavTree_Img_GCExpander(WebDriver driver)
{
	Element = driver.findElement(By.xpath(".//*[@id='navTree']/table[6]/tbody/tr[2]/td[3]/a/img")); // Unique Id Of Expander On Left Hand Navigation Tree Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_LeftHandNavTree_Lnk_FinancialReserves
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Financial/Reserves Link On Left Hand Navigation Tree Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-24-2015                                 
// ============================================================================================
public static WebElement RMAApp_LeftHandNavTree_Lnk_FinancialReserves(WebDriver driver)
{
	//Element = driver.findElement(By.xpath(".//*[@id='navTreet10']/span")); // Unique Id Of Financial/ Reserves Link On Left Hand Navigation Tree Is Fetched
	Element = driver.findElement(By.linkText("Financials/Reserves"));
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Frm_Address
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Maintenance-->Address Frame On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
//============================================================================================
public static WebElement RMAApp_DefaultView_Frm_Maint_Address(WebDriver driver)
{
	Element = driver.findElement(By.id("MaintenancezAddressAddressAddressUI/FDM/?recordID=(NODERECORDID)AddressFalseFalse")); //Unique Id  Of Maintenance-->Address Frame On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			:RMAApp_DefaultView_Btn_Close
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Close Button On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
//============================================================================================
public static WebElement RMAApp_DefaultView_Btn_Close(WebDriver driver)
{
	Element = driver.findElement(By.xpath(".//*[@id='closeButton']/img")); //Unique Id  Of Close Button On RMA Application Default View Page Is Fetched
		return Element;
	}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Err_StaticErrorText
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of DefaultFrame (containing menu options) On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-16-2015                                 
//============================================================================================
public static WebElement RMAApp_DefaultView_Err_StaticErrorText(WebDriver driver)
{
	WebElement ErrElement = null;
	 try {
		 ErrElement = driver.findElement(By.xpath(".//*[@id='lblError']/font")); //Unique Id  Of DefaultFrame (containing menu options) On RMA Application Default View Page Is Fetched	
	} catch (Exception|Error e) {	
	}
	return ErrElement;	
}

//============================================================================================
//FunctionName 			: RMAApp_TestNGGridLinkIterator
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which TestNG Grid Iterator On RMA Application Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-12-08-2015                                 
//============================================================================================
public static WebElement RMAApp_TestNGGridLinkIterator(WebDriver driver,int y, int x, String tagname, String idvalue)
{
	Element = driver.findElement(By.xpath(".//*[@id='"+idvalue+"']div/div[2]/div/div["+y+"]/div["+x+"]/div[2]/div/"+tagname)); //Unique Id Of Address Grid Link Iterator On RMA Application's Maintenance-->Address-->AddressSearch Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_LeftHandNavTree_Lnk_Adjuster
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Adjustor Link On Left Hand Navigation Tree Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-10-24-2015                                 
//============================================================================================
public static WebElement RMAApp_LeftHandNavTree_Lnk_Adjuster(WebDriver driver)
{
	Element = driver.findElement(By.partialLinkText("Adjuster")); // Unique Id Of Adjustor Link On Left Hand Navigation Tree Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_LeftHandNavTree_Lnk_AdjustorAddnew
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Add New Link For Adjustor On Left Hand Navigation Tree On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-01-08-2016                                 
// ============================================================================================
public static WebElement RMAApp_LeftHandNavTree_Lnk_AdjustorAddNew(WebDriver driver)
{
	Element = driver.findElement(By.xpath("//div[@id='Add New ']/span")); //Unique Id  Of Add New Link For Adjustor On Left Hand Navigation Tree On RMA Application Default View Page Is Fetched
	return Element;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_LoginUserName
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Login User Name Link On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - ImteyazAhmad-01-11-2016                               
//============================================================================================
public static WebElement RMAApp_DefaultView_LoginUserName(WebDriver driver)
{
	Element = driver.findElement(By.id("cphMainBody_LoginName1")); //Unique Id  Of Login User Name Link On RMA Application Default View Page Is Fetched
	return Element;
}
//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Img_Reload
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Reload Image On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - ImteyazAhmad-01-11-2016                                 
//============================================================================================
public static WebElement RMAApp_DefaultView_Img_Reload(WebDriver driver)
{
	Element = driver.findElement(By.xpath(".//*[@id='reloadButton']/img"));//Unique Id  Of Reload Image On RMA Application Default View Page Is Fetched
	return Element;
}


//============================================================================================
//FunctionName 			: RMAApp_GenericErrMsg1
//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Error Messages On RMA Application Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - ImteyazAhmad-01-11-2016                                 
//============================================================================================
public static WebElement RMAApp_Err_GenericErrMsg1(WebDriver driver)
{   WebElement ErrElement_01 = null;
try{
	ErrElement_01 = driver.findElement(By.xpath(".//*[@id='ErrorControl1_lblError']/table/tbody/tr/td[2]/ul/li"));//Unique Id Of Error Messages On RMA Application Is Fetched
} catch (Exception|Error e) {	
}
return ErrElement_01;
}

//============================================================================================
//FunctionName 			: RMAApp_DefaultView_Err_StaticErrorText_01
//Description  			: To Fetch Unique Property (Such As Id, X-path, Name ) On The Basis Of Which Static Error Text (Like: Following Error Occurred) On RMA Application Default View Page Can Be Identified
//Input Parameter 		: Driver Variable Of The Type WebDriver		 
//Revision				: 0.0 - KumudNaithani-04-13-2015                                 
//============================================================================================
public static WebElement RMAApp_DefaultView_Err_StaticErrorText_01(WebDriver driver)
{
	WebElement ErrElement_02 = null;
	 try {
		 ErrElement_02 = driver.findElement(By.xpath(".//*[@id='ErrorControl1_lblError']/font")); //Unique Id Of Static Error Text (Like: Following Error Occurred) On RMA Application Default View Page Is Fetched	
	} catch (Exception|Error e) {	
	}
	return ErrElement_02;	
}
}