package rmaseleniumPOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RMA_POM_BankAccount {


	public static WebElement Element = null;


	//============================================================================================
	//FunctionName 			: RMAApp_BankAccount_Frm_SwitchFrame
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Bank Account Frame On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_BankAccount_Frm_SwitchFrame(WebDriver driver)
	{
		Element = driver.findElement(By.id("Funds-1bankaccountBank AccountUI/FDM/?recordID=(NODERECORDID)Bank AccountFalseFalse")); //Unique Id  Of  Bank Account Frame On RMA Application Bank Account Page Is Fetched
		return Element;
	}




	//============================================================================================
	//FunctionName 			: RMAApp_BankAccount_Img_Save
	//Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Save Image On RMA Application Bank Account Page Can Be Identified
	//Input Parameter 		: Driver Variable Of The Type WebDriver		 
	//Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	// ============================================================================================
	public static WebElement RMAApp_BankAccount_Img_Save(WebDriver driver)
	{
		Element = driver.findElement(By.id("save")); //Unique Id  Of  Save Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}


	/*============================================================================================
		FunctionName 			: RMAApp_BankAccount_Img_Delete
		Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Delete Image On RMA Application Bank Account Page Can Be Identified
		Input Parameter 		: Driver Variable Of The Type WebDriver		 
		Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
		 ============================================================================================ */
	public static WebElement RMAApp_BankAccount_Img_Delete (WebDriver driver)
	{
		Element = driver.findElement(By.id("delete")); //Unique Id  Of  Delete Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}



	/*============================================================================================
	FunctionName 			: RMAApp_BankAccount_Img_LookUp
	Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which LookUp Image On RMA Application Bank Account Page Can Be Identified
	Input Parameter 		: Driver Variable Of The Type WebDriver		 
	Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	 ============================================================================================ */
	public static WebElement RMAApp_BankAccount_Img_LookUp (WebDriver driver)
	{
		Element = driver.findElement(By.id("lookup")); //Unique Id  Of  LookUp Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	
	/*============================================================================================
	FunctionName 			: RMAApp_BankAccount_Img_RecordSummary
	Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which RecordSummary Image On RMA Application Bank Account Page Can Be Identified
	Input Parameter 		: Driver Variable Of The Type WebDriver		 
	Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	 ============================================================================================ */
	public static WebElement RMAApp_BankAccount_Img_RecordSummary (WebDriver driver)
	{
		Element = driver.findElement(By.id("recordsummary")); //Unique Id  Of  RecordSummary Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	
	/*============================================================================================
	FunctionName 			: RMAApp_BankAccount_Img_CheckStock
	Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which CheckStock Image On RMA Application Bank Account Page Can Be Identified
	Input Parameter 		: Driver Variable Of The Type WebDriver		 
	Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	 ============================================================================================ */
	public static WebElement RMAApp_BankAccount_Img_CheckStock (WebDriver driver)
	{
		Element = driver.findElement(By.id("btnCheckStocks")); //Unique Id  Of  CheckStock Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}
	
	
	/*============================================================================================
	FunctionName 			: RMAApp_BankAccount_Img_Balance
	Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Balance Image On RMA Application Bank Account Page Can Be Identified
	Input Parameter 		: Driver Variable Of The Type WebDriver		 
	Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	 ============================================================================================ */
	public static WebElement RMAApp_BankAccount_Img_Balance (WebDriver driver)
	{
		Element = driver.findElement(By.id("btnBalance")); //Unique Id  Of  Balance Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	
	
	/*============================================================================================
	FunctionName 			: RMAApp_BankAccount_Img_AccountBalance
	Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which AccountBalance Image On RMA Application Bank Account Page Can Be Identified
	Input Parameter 		: Driver Variable Of The Type WebDriver		 
	Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	 ============================================================================================ */
	public static WebElement RMAApp_BankAccount_Img_AccountBalance (WebDriver driver)
	{
		Element = driver.findElement(By.id("btnAccountBalance")); //Unique Id  Of  AccountBalance Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}

	
	/*============================================================================================
	FunctionName 			: RMAApp_BankAccount_Img_Deposit
	Description  			: To Fetch Unique Property (Such As Id, Xpath, Name ) On The Basis Of Which Deposit Image On RMA Application Bank Account Page Can Be Identified
	Input Parameter 		: Driver Variable Of The Type WebDriver		 
	Revision				: 0.0 - ImteyazAhmad-12-03-2015                                 
	 ============================================================================================ */
	public static WebElement RMAApp_BankAccount_Img_Deposit (WebDriver driver)
	{
		Element = driver.findElement(By.id("btnDeposit")); //Unique Id  Of  Deposit Image On RMA Application Bank Account Page Is Fetched
		return Element;
	}










}
