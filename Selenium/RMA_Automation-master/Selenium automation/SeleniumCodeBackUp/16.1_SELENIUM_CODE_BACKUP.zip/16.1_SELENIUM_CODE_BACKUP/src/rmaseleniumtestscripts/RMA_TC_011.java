package rmaseleniumtestscripts;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_UserPrivilegesSetUp;
import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_011
//Description    : Verify that  Payment Limits can be set at group level in User Privileges Setup
//Depends On TC  : None
//Revision       : 0.0 - KumudNaithani-12-17-2015 
//=================================================================================================
public class RMA_TC_011 extends rmaseleniumtestscripts.RMA_TC_BaseTest{
	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;
@Test 
public void RMA_TC_011_test () throws Exception, Error 
//Verify that  Payment Limits can be set at group level in User Privileges Setup
{
	try {
		logger = reports.startTest("TC_011_GroupLevel Payment Limit SetUp", "Payment Limits Set At GroupLevel In User Privileges SetUp Are Validated");

		String RMAApp_UserPrev_Lst_LOB;
		String RMAApp_UserPrev_Lst_CurrAdjGrp;
		String RMAApp_UserPrev_Lst_CurrAdjMgrGrp1;
		String RMAApp_UserPrev_Lst_CurrAdjMgrGrp2;
		String RMAApp_UserPrev_Lst_LoginMgrGrp1;
		String RMAApp_UserPrev_Lst_LoginMgrGrp2;
		String RMAApp_UserPrev_Lst_LoginUsrGrp;
		int RMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt;
		int RMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt;
		int RMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt;
		int RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt;
		int RMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt;
		int RMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt;
		String StrRMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt;
		String StrRMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt;
		String StrRMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt;
		String StrRMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt;
		String StrRMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt;
		String StrRMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt;
		String StrPrimaryWindowHandle;
		String StrAccept;
		String ObjectName;
		//Local Variable Declaration
		
		StrAccept = "Yes";
		RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMA_Suite_01_SprVsrApprovalTestData.xlsx"); //Excel WorkBook RMASeleniumAutomationTestData IS Fetched To Retrieve Data 
		RMAApp_UserPrev_Lst_LOB = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_011", 1, 0); //Line Of Business Name Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_CurrAdjGrp = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_011", 1, 1); // RMAApp_UserPrev_Lst_CurrAdjGrp Name Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_CurrAdjMgrGrp1 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_011", 1, 2); // RMAApp_UserPrev_Lst_CurrAdjMgrGrp1 Name Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_CurrAdjMgrGrp2 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_011", 1, 3); // RMAApp_UserPrev_Lst_CurrAdjMgrGrp2 Name Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_LoginUsrGrp = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_011", 1, 6); // RMAApp_UserPrev_Lst_LoginUsrGrp Name Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_LoginMgrGrp1 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_011", 1, 4); // RMAApp_UserPrev_Lst_LoginMgrGrp1 Name Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_LoginMgrGrp2 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_011", 1, 5); // RMAApp_UserPrev_Lst_LoginMgrGrp2 Name Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_011", 1, 7); // RMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_011", 1, 8); // RMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_011", 1, 9); // RMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_011", 1, 12); // RMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_011", 1, 10); // RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt Is Fetched From DataSheet RMA_TC_011
		RMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_011", 1, 11); // RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt Is Fetched From DataSheet RMA_TC_011
		
		StrPrimaryWindowHandle = driver.getWindowHandle();
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1);
		RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8).click(); //Security Menu Option Is Selected
		ObjectName = color.RMA_ChangeColor_Utility("Security Menu Option", 4);
		logger.log(LogStatus.INFO, ObjectName+ " " + "Is Clicked On RISKMASTER Default View Page");

		Thread.sleep(2000);
		RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8, 5).click(); //User Privileges Set Up Menu Option Is Selected
		ObjectName = color.RMA_ChangeColor_Utility("Security-->User Privileges SetUp Menu Option", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "Is Clicked On RISKMASTER Default View Page");

		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
		logger.log(LogStatus.INFO, "User-Privileges SetUp Page Of RMA Application Is Opened");

		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver).click();
		ObjectName = color.RMA_ChangeColor_Utility("Payment Limits Tab", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User-Privileges SetUp Page Is Clicked");
		
		Thread.sleep(2000);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Rdb_Groups(driver).click(); //Groups Radio Button On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked
		ObjectName = color.RMA_ChangeColor_Utility("Groups Radio Button", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked");
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_CurrAdjGrp,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver).sendKeys(String.valueOf(RMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt));
		StrRMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt = color.RMA_ChangeColor_Utility(String.valueOf(RMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt), 3);
		ObjectName = color.RMA_ChangeColor_Utility("Max Amount TextBox", 4);
		logger.log(LogStatus.INFO, "Amount Selected In" + " " + ObjectName + " " +  "For CurrAdjGrp Group's Payment Limit Is" + " " + StrRMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt);

		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver).click();
		ObjectName = color.RMA_ChangeColor_Utility("Add Button", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked");
		
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_CurrAdjGrp, 3, String.valueOf(RMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt), "Payment Limits Grid Table",1);
		// Payment Limit Is Added To "CurrAdjGrp" Group Is Added Above
		
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_CurrAdjMgrGrp1,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver).sendKeys(String.valueOf(RMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt));
		StrRMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt = color.RMA_ChangeColor_Utility(String.valueOf(RMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt), 3);
		ObjectName = color.RMA_ChangeColor_Utility("Max Amount TextBox", 4);
		logger.log(LogStatus.INFO, "Amount Selected In" + " " + ObjectName + " " +  "For CurrAdjMgrGrp1 Group's Payment Limit Is" + " " + StrRMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt);
	
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver).click();
		ObjectName = color.RMA_ChangeColor_Utility("Add Button", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked");	
		
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_CurrAdjMgrGrp1, 3, String.valueOf(RMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt), "Payment Limits Grid Table",1);
		// Payment Limit Is Added To "CurrAdjMgrGrp1" Group
		
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_CurrAdjMgrGrp2,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver).sendKeys(String.valueOf(RMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt));
		StrRMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt = color.RMA_ChangeColor_Utility(String.valueOf(RMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt), 3);
		ObjectName = color.RMA_ChangeColor_Utility("Max Amount TextBox", 4);
		logger.log(LogStatus.INFO, "Amount Selected In" + " " + ObjectName + " " +  "For CurrAdjMgrGrp2 Group's Payment Limit Is" + " " + StrRMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt );
	
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver).click();
		ObjectName = color.RMA_ChangeColor_Utility("Add Button", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked");	
		
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_CurrAdjMgrGrp2, 3, String.valueOf(RMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt), "Payment Limits Grid Table",1);
		// Payment Limit Is Added To "CurrAdjMgrGrp2" Group
		
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_LoginUsrGrp,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver).sendKeys(String.valueOf(RMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt));
		StrRMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt = color.RMA_ChangeColor_Utility(String.valueOf(RMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt), 3);
		ObjectName = color.RMA_ChangeColor_Utility("Max Amount TextBox", 4);
		logger.log(LogStatus.INFO, "Amount Selected In" + " " + ObjectName + " " +  "For LoginUsrGrp Group's Payment Limit Is" + " " + StrRMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt );
	
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver).click();
		ObjectName = color.RMA_ChangeColor_Utility("Add Button", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked");	
		
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginUsrGrp, 3, String.valueOf(RMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt), "Payment Limits Grid Table",1);
		// Payment Limit Is Added To "LoginUsrGrp" Group
		
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_LoginMgrGrp1,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver).sendKeys(String.valueOf(RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt));
		StrRMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt = color.RMA_ChangeColor_Utility(String.valueOf(RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt), 3);
		ObjectName = color.RMA_ChangeColor_Utility("Max Amount TextBox", 4);
		logger.log(LogStatus.INFO, "Amount Selected In" + " " + ObjectName + " " +  "For LoginUsrGrp Group's Payment Limit Is" + " " + StrRMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt);
	
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver).click();
		ObjectName = color.RMA_ChangeColor_Utility("Add Button", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked");	
		
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginMgrGrp1, 3, String.valueOf(RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt), "Payment Limits Grid Table",1);
		// Payment Limit Is Added To "LoginMgrGrp1" Group
		
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_LoginMgrGrp2,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver).sendKeys(String.valueOf(RMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt));
		StrRMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt = color.RMA_ChangeColor_Utility(String.valueOf(RMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt), 3);
		ObjectName = color.RMA_ChangeColor_Utility("Max Amount TextBox", 4);
		logger.log(LogStatus.INFO, "Amount Selected In" + " " + ObjectName + " " +  "For LoginUsrGrp Group's Payment Limit Is" + " " + StrRMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt);
		
		RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver).click();
		ObjectName = color.RMA_ChangeColor_Utility("Add Button", 4);
		logger.log(LogStatus.INFO, ObjectName + " " + "On RMA Application's User Privileges Set Up Page's Payment Limits Tab Is Clicked");	
		
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginMgrGrp2, 3, String.valueOf(RMAApp_UserPrev_Lst_LoginMgrGrp2_MaxAmt), "Payment Limits Grid Table",1);
		// Payment Limit Is Added To "LoginMgrGrp2" Group
		
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "check", "Enable Payment Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",1);
		//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked
		Thread.sleep(2000);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		Thread.sleep(3000);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "check", "Restrict Unspecified Users CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",1);
		//Restrict Unspecified User CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab is Checked
		Thread.sleep(2000);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "select", "Enable Payment Limits CheckBox",1);
		Thread.sleep(4000);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "select", "Restrict Unspecified Users CheckBox",1);
		
		driver.close();
		driver.switchTo().window(StrPrimaryWindowHandle);
		
	} catch (Exception|Error e) {
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		throw (e);
	}
	
	}

@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String StrScreenShotTCName;
		StrScreenShotTCName = "TC_011";
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1);
		}
		reports.endTest(logger);
	} catch (Exception |Error e) {
		throw (e);
	}
}
}
	