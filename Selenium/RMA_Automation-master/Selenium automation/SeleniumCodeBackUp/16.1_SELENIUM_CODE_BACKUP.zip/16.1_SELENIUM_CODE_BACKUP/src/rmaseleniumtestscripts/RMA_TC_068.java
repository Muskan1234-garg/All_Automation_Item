package rmaseleniumtestscripts;

import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Funds_ApproveTransactions;
import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_Login_DSNSelect_Frames;
import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
import rmaseleniumutilties.RMA_NegativeVerification_Utility;
import rmaseleniumutilties.RMA_ScreenCapture_Utility;
//RMA Package Import Completed


//================================================================================================
//TestCaseID     : RMA_TC_068
//Description    : Hold Transaction Created In RMA_TC_066 Is Not Listed In Login User's Managers List Is Validated
//Dependent On TC: TC_064, TC_065, TC_066
//Revision       : 0.0 - ImteyazAhmad-02-05-2016 
//=================================================================================================

public class RMA_TC_068 extends rmaseleniumtestscripts.RMA_TC_BaseTest {
	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;
	static String StrScreenShotTCName;

@Test 
public void RMA_TC_068_Test () throws Exception, Error

{
	try {
		parentlogger = reports.startTest("TC_068_Hold Transaction Not Listed In Login User's Managers List", "Hold Transaction Created In RMA_TC_066 Is Not Listed In Login User's Managers List Is Validated");
		String StrAccept;
		String RMAApp_Login_Txt_UserName;
		String RMAApp_Login_Txt_Password;
		String LoginUserNameActual;
		String Strlogstatement;
		//Local Variable Declaration
		
		StrAccept = "Yes";
		loggerval1 = "NotInitialized";
		testcall1 = false;
		StrScreenShotTCName = "TC_068";
		
		RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMA_Suite_02_SprVsrApprovalTestData.xlsx"); //Excel WorkBook RMASeleniumAutomationTestData Is Fetched To Retrieve Data 
		RMAApp_Login_Txt_UserName = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_068", 1, 0); //UserName Fetched From DataSheet RMA_TC_068
		RMAApp_Login_Txt_Password = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_068", 1, 1); //Password Fetched From DataSheet RMA_TC_068
		//RMA_ExcelDataRetrieval_Utility ExcelTestData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMASeleniumAutomationTestData.xlsx"); //Excel WorkBook RMASeleniumAutomationTestData IS Fetched To Retrieve Data 
		//String StrControlNumber_RMA_TC_013 = ExcelTestData.RMA_ExcelStringDataRead_Utility("RMA_TC_006", 10, 0); //Payment Control Number Is Fetched From Data Sheet RMA_TC_006
		
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMAApp_Login_Txt_UserName, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMAApp_Login_Txt_Password, 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Button On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		parentlogger.log(LogStatus.INFO, "Following Test Is Called :: RMA_TC_002 To Select The DataSource");
		testcall1 = true;
		RMA_TC_002 dsnselection = new RMA_TC_002();
		dsnselection.RMAApp_DSNSelection();
		loggerval1 = logger.toString();
		parentlogger.appendChild(logger);
		//Data Source Is Selected 
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare(RMAApp_Login_Txt_UserName, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver)); //A Switch To The Frame Containing RMA Application Menu Option Is Done
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,2), "Funds-->Approve Transactions Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Approve Transactions Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Frm_ApproveTransact(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Funds-->Approve Transactions Frame Is Done");
		//A Switch To The Frame Containing Funds-->Approve Transactions Page Is Done
		
		WebElement filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On Approve Transactions Table", RMA_TC_066.StrControlNumber_RMA_TC_066,0);
		//RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On Approve Transactions Table", StrControlNumber_RMA_TC_013, 0);		
		//Funds Transactions Available For Approval, Void Or Denial Table Is Filtered On The Basis Of The Provided Control Number
		
		Strlogstatement  = "Record With Control Number" + " " + RMA_TC_066.StrControlNumber_RMA_TC_066 + " " + "In Payment Approval Table On Approve Transactions Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment $2000 Not Listed For LoginMgr1 Verification", StrScreenShotTCName)));
	
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Non-Existence Of Payment With Control Number" + " " + String.valueOf(RMA_TC_066.StrControlNumber_RMA_TC_066)+ " " + " Is Verified In Login Manger's List");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On Approve Transactions Table", RMA_TC_066.StrControlNumber_RMA_TC_066_01,0);
		Strlogstatement  = "Record With Control Number" + " " + RMA_TC_066.StrControlNumber_RMA_TC_066_01 + " " + "In Payment Approval Table On Approve Transactions Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment $2500 Not Listed For LoginMgr1 Verification", StrScreenShotTCName)));
	
	} catch (Exception|Error e) {
		
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		
		if ((testcall1 == true) && (loggerval1.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Executing Test Case" +" "+ "RMA_TC_002: DSN Selection" + " " +  "And Hence The Test Case Is A Fail");
		parentlogger.appendChild(logger);
		}
		
		throw (e);
	}
	}

@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,0);
		}
		reports.endTest(parentlogger);
	} catch (Exception |Error e) {
		throw (e);
	}
}
}
