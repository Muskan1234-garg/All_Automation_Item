package rmaseleniumtestscripts;

import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_POM_Search;
import rmaseleniumPOM.RMA_Selenium_POM_Funds_ApproveTransactions;
import rmaseleniumPOM.RMA_Selenium_POM_Funds_ResApprove;
import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_Login_DSNSelect_Frames;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentParameterSetUp;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentsCollections;
import rmaseleniumPOM.RMA_Selenium_POM_UserPrivilegesSetUp;
import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_Functionality_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_NegativeVerification_Utility;
import rmaseleniumutilties.RMA_ScreenCapture_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_075
//Description    : TC_075_Step And Jump Functionality Of Reserve/Payment Approval Is Validated
//Depends On TC  : TC_UserCreationSASuite3 (When Running In Suite TC_UserDeletionSASuite3 Should Be Executed At The End To Delete The Created Users And Groups)
//Revision       : 0.0 - KumudNaithani-02-18-2016 
//=================================================================================================
//Note: Here: LoginUser Stands For User Containing CSC In Its Name, LoginMgr1 Stands For User Having A1 In Its Name And LoginMgr2 Stands For User Having A2 In Its Name, Users Are Arranged In Hierarchy CSC-->A1-->A2
public class RMA_TC_075 extends rmaseleniumtestscripts.RMA_TC_BaseTest {
	
static String ExceptionRecorded;
static String []ErrorMessage;
static String FinalErrorMessage;
static String ErrorMessageType;
static String StrScreenShotTCName;


@Test 
public void RMA_TC_075_Test () throws Exception, Error 
//Verify Payments Can Be Created And Is Going On Hold Because Of Exceeded Payment Limits
{
	parentlogger = reports.startTest("TC_075_Step And Jump Functionality Of Reserve/Payment Approval", "Step And Jump Functionality Of Reserve/Payment Approval Is Validated");
	parentlogger.assignAuthor("Kumud Naithani");
	try {
		String StrPrimaryWindowHandle;
		String RMAApp_UserPrev_Lst_LOB;
		int RMAApp_UserPrev_Txt_LoginUser_MaxResAmt;
		String RMAApp_UserPrev_Lst_ReserveType;
		int RMAApp_UserPrev_Txt_LoginUser_MaxAmt;
		int RMAApp_UserPrev_Txt_LoginMgr1User_MaxResAmt;
		int RMAApp_UserPrev_Txt_LoginMgr1User_MaxAmt;
		String RMAApp_ReserveCreation_Lst_MedStatus;
		int RMAApp_ReserveCreation_Txt_MedReserveAmount;
		String RMAApp_ReserveCreation_Lnk_MedReserveType;
		String StrAccept;
		String StrExpErrMessage;
		String LoginUserNameActual;
		int RMAApp_ReserveCreation_Txt_ExpReserveAmount;
		int RMAApp_ReserveCreation_Txt_IndemReserveAmount;
		String RMAApp_ReserveCreation_Lst_ExpStatus;
		String RMAApp_ReserveCreation_Lst_IndemStatus;
		String RMAApp_ReserveCreation_Lnk_ExpReserveType;
		String RMAApp_ReserveCreation_Lnk_IndemReserveType;
		String RMAApp_Payment_Lst_BankAccount;
		String RMAApp_Payment_Lst_PayeeType;
		int RMAApp_FundsSplitDetails_Txt_Amount;
		int RMAApp_FundsSplitDetails_Txt_Amount_1;
		int RMAApp_FundsSplitDetails_Txt_Amount_2;
		String RMAApp_FundsSplitDetails_Lst_TransactionType;
		String RMAApp_Payment_Txt_LastName;
		String RMAApp_Payment_Txt_DistributionType;
		String StrActualErrorMessage;
		String StrErrorMessageExpected;
		String StrControlNumber_RMA_TC_075;
		String StrControlNumber_RMA_TC_01_075;
		String StrControlNumber_RMA_TC_02_075;
		String StrClaimNumber_RMA_TC_075;
		WebElement filtertext;
		WebElement filtertext1;
		WebElement filtertext2;
		WebElement filtertext3;
		String Strlogstatement;
		String StrCheckStatusActual;
		String StrCheckStatusExpected;
		int ActualRowCount;
		String StrConLoginUserFirstAndLastName;
		String StrConLoginMgr1FirstAndLastName;
		//Local Variable Declaration
		
		StrScreenShotTCName = "TC_075";
		loggerval1 = "NotInitialized";
		loggerval2 = "NotInitialized";
		loggerval3 = "NotInitialized";
		loggerval4 = "NotInitialized";
		loggerval5 = "NotInitialized";
		loggerval6 = "NotInitialized";
		loggerval7 = "NotInitialized";
		loggerval8 = "NotInitialized";
		loggerval9 = "NotInitialized";
		testcall1 = false; 
		testcall2 = false; 
		testcall3 = false;
		testcall4 = false; 
		testcall5 = false;
		testcall6 = false;
		testcall7 = false; 
		testcall8 = false;
		testcall9 = false;
		StrAccept = "Yes";
		
	
		StrAccept = "Yes";
		StrCheckStatusExpected = "R Released";
		StrConLoginUserFirstAndLastName = RMA_TC_UserCreationSASuite3.StrUsercsc_TC_UserCreationSASuite3+", "+RMA_TC_UserCreationSASuite3.StrUsercsc_TC_UserCreationSASuite3;
		StrConLoginMgr1FirstAndLastName = RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3+", "+RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3; 

		StrExpErrMessage = "rmA-1638:This reserve has been sent for the Supervisor approval and is in the Hold status as Exceeded Reserve Limit";
		StrErrorMessageExpected = "A hold requiring supervisory approval has been placed on this payment because Exceeded Payment Limit and requires managerial approval.";
		
		RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMA_Suite_03_SprVsrApprovalTestData.xlsx"); //Excel WorkBook RMA_Suite_03_SprVsrApprovalTestData Is Fetched To Retrieve Data
		RMAApp_UserPrev_Lst_LOB = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 0); //Line Of Business Name Is Fetched From DataSheet RMA_TC_075
		RMAApp_UserPrev_Txt_LoginUser_MaxResAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 2); //Maximum Reserve Limit Amount For LoginUser Is Fetched From DataSheet RMA_TC_075
		RMAApp_UserPrev_Lst_ReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 3); //Reserve Type For LoginUser Is Fetched From DataSheet RMA_TC_075
		RMAApp_UserPrev_Txt_LoginUser_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 4); //Max Payment Limit Amount For LoginUser Is Fetched From DataSheet RMA_TC_075
		RMAApp_UserPrev_Txt_LoginMgr1User_MaxResAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 6); //Maximum Reserve Limit For LoginMgr1 User Name Is Fetched From DataSheet RMA_TC_075
		RMAApp_UserPrev_Txt_LoginMgr1User_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 7); //Maximum Payment Limit For LoginMgr1 User Name Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Txt_MedReserveAmount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 8); //Reserve Amount Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Lst_MedStatus = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 9); //Reserve Status Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Lnk_MedReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 10); //Reserve Type Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Txt_IndemReserveAmount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 13); //Reserve Amount Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Lst_IndemStatus = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 14); //Reserve Status Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Lnk_IndemReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 15); //Reserve Type Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Txt_ExpReserveAmount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 16); //Reserve Amount Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Lst_ExpStatus = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 17); //Reserve Status Is Fetched From DataSheet RMA_TC_075
		RMAApp_ReserveCreation_Lnk_ExpReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 18); //Reserve Type Is Fetched From DataSheet RMA_TC_075
		RMAApp_Payment_Lst_BankAccount = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 19); //Bank Account Is Fetched From DataSheet RMA_TC_075
		RMAApp_Payment_Lst_PayeeType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 20); // Payee Type Is Fetched From DataSheet RMA_TC_075
		RMAApp_FundsSplitDetails_Lst_TransactionType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 21); //Transaction Type Is Fetched From DataSheet RMA_TC_075
		RMAApp_FundsSplitDetails_Txt_Amount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 22); //Amount Is Fetched From DataSheet RMA_TC_075
		RMAApp_FundsSplitDetails_Txt_Amount_1 = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 24); //Amount For Second Payment Is Fetched From DataSheet RMA_TC_075
		RMAApp_Payment_Txt_LastName = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 23); //LastName Is Fetched From DataSheet RMA_TC_075
		RMAApp_Payment_Txt_DistributionType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_075", 1, 25); //Distribution Type Is Fetched From DataSheet RMA_TC_075
		RMAApp_FundsSplitDetails_Txt_Amount_2 = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_075", 1, 26); //Amount For Second Payment Is Fetched From DataSheet RMA_TC_075
		
		
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite3.StrUsercsc_TC_UserCreationSASuite3,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite3.StrUsercsc_TC_UserCreationSASuite3,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In

		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare( RMA_TC_UserCreationSASuite3.StrUsercsc_TC_UserCreationSASuite3, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		StrPrimaryWindowHandle = driver.getWindowHandle();
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,5), "Security-->User Privileges SetUp Menu Option", 0);
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
		driver.manage().window().maximize();
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page",0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginUserFirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Lst_ReserveType(driver), RMAApp_UserPrev_Lst_ReserveType,"Reserve Type List Box","RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab",0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Txt_MaxAmount(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginUser_MaxResAmt),0);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's ReserveLimits Tab",0); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Limit Max Amount For" + " " + StrConLoginUserFirstAndLastName+ " " + "Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConLoginUserFirstAndLastName, 3, RMAApp_UserPrev_Lst_ReserveType, "Reserve Limits Grid Table",0);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConLoginUserFirstAndLastName, 5, String.valueOf(RMAApp_UserPrev_Txt_LoginUser_MaxResAmt), "Reserve Limits Grid Table",0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Reserve Limit Verification For User"+ " "+ StrConLoginUserFirstAndLastName, StrScreenShotTCName)));
		// Reserve Limit Is Added To User With Name Containing CSC Above
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginMgr1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Lst_ReserveType(driver), RMAApp_UserPrev_Lst_ReserveType,"Reserve Type List Box","RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab",0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Txt_MaxAmount(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginMgr1User_MaxResAmt),0);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's ReserveLimits Tab",0); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Limit Max Amount For User" + " "+ StrConLoginMgr1FirstAndLastName+ "Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConLoginMgr1FirstAndLastName, 3, RMAApp_UserPrev_Lst_ReserveType, "Reserve Limits Grid Table",0);
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConLoginMgr1FirstAndLastName, 5, String.valueOf(RMAApp_UserPrev_Txt_LoginMgr1User_MaxResAmt), "Reserve Limits Grid Table",0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Reserve Limit Verification For User"+ " "+ StrConLoginMgr1FirstAndLastName, StrScreenShotTCName)));
		// Reserve Limit Is Added To User With Name Containing A1 Above
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "check", "Enable Reserve Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Reserve Limits Tab",0);
		//Enable Reserve Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Reserve Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_RestUnspcfdUsers(driver), "uncheck", "Restrict Unspecified Users CheckBox",  "RMA Application's User Privileges SetUp Page's Reserve Limits Tab",0);
		//Restrict Unspecified User CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab is Unchecked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Unchecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "select", "Enable Reserve Limits CheckBox",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_RestUnspcfdUsers(driver), "deselect", "Restrict Unspecified Users CheckBox",0);
		//Select/De-select State Of The Enable Reserve Limits CheckBox And Restrict Unspecified User CheckBox Is Verified
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab  On User-Privileges SetUp Page", 0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginUserFirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginUser_MaxAmt),0);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",0); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Payment Limit Max Amount For" + " " +  StrConLoginUserFirstAndLastName + " " + "Is Added");
		
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), StrConLoginUserFirstAndLastName, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginUser_MaxAmt), "Payment Limits Grid Table",0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For User" + " " +StrConLoginUserFirstAndLastName, StrScreenShotTCName)));
		// Payment Limit Is Added To User With Name Containing CSC Above
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver),  StrConLoginMgr1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginMgr1User_MaxAmt),0);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",0); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Payment Limit Max Amount For User"+ " " + StrConLoginMgr1FirstAndLastName+ " "+" Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver),  StrConLoginMgr1FirstAndLastName, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginMgr1User_MaxAmt), "Payment Limits Grid Table",0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For User"+ " " +StrConLoginMgr1FirstAndLastName , StrScreenShotTCName)));
		// Payment Limit Is Added To User With Name Containing A1 Above
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "check", "Enable Payment Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",0);
		//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted

		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "uncheck", "Restrict Unspecified Users CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",0);
		//Restrict Unspecified User CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab is UnChecked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Unchecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "select", "Enable Payment Limits CheckBox",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "deselect", "Restrict Unspecified Users CheckBox",0);
		//Select/De-select State Of The Enable Reserve Limits CheckBox And Restrict Unspecified User CheckBox Is Verified
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPayDetailLimit_Lnk_PayDetailLimits(driver), "Pay Detail Limits Tab On RMA Application's User-Privileges SetUp Page", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Pay Detail Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPayDetailLimit_chk_EnablePaymentDetailLimits(driver), "uncheck", "Enable Payment Detail Limits CheckBox",  "RMA Application's User Privileges SetUp Page's PayDetail Limits Tab",0);
		//Enable Payment Detail Limits CheckBox  On Pay Detail Limits Tab Is Unchecked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Payment Detail Limits CheckBox On RMA Application User Privilege SetUp Page's PayDetail Limits Tab Is Unchecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPayDetailLimit_chk_EnablePaymentDetailLimits(driver), "deselect", "Enable Payment Detail Limits CheckBox",0);
		//Select/De-select State Of The Enable Payment Detail Limits CheckBox On Pay Detail Limits Tab Is Verified
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tab_PerClaimIncLimits(driver), "Per Claim Incurred Limits On User Privileges Setup Page ", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Per Claim Incurred Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "uncheck", "Enable Per Claim Incurred Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Per Claim Incurred Limits Tab",0);
		//Enable Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Incurred Limits Tab Is Unchecked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's PayDetail Limits Tab Is Unchecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "deselect", "Enable Per Claim Incurred Limits CheckBox",0);
		//Select/De-select State Of The Enable Per Claim Incurred Limits CheckBox On Pay Detail Limits Tab Is Verified
		
		driver.close();
		driver.switchTo().window(StrPrimaryWindowHandle);
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Event Creation Controls IS Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "check", "Payment Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "check", "Supervisory Approval Check Box", "Payment Parameter Setup Page",0);      // Supervisory Approval CheckBox Is Checked On Payment Parameter Set Up Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "check", "Reserve Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Reserve Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "check", "Notify Immediate Supervisor Check Box", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "check", "Notify Immediate Supervisor Check Box For Reserves", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box For reserves Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "check", "Supervisory Approval Check Box For Reserves", "Payment Parameter Setup",0); //Supervisory Approval CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver), "Save Image On Payment Parameter Set Up Page",0);//Save Image Is Clicked
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "select", "Notify Immediate Supervisor Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "select", "Payment Limits Are Exceeded Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "select", "Reserve Limits Are Exceeded Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "select", "Notify Immediate SuperVisor For Reserves Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "select", "Supervisory Approval Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "select", "Use SuperVisory Approval For Reserves Check Box",0);
		
		//Required SuperVisory Approval Settings Are Saved In Payment Parameter Set Up Page
		parentlogger.log(LogStatus.INFO, "Following Test Is Called :: RMA_TC_004 To Create New Claim");
		testcall2 = true;
		RMA_TC_004 generalclaim = new RMA_TC_004();
		StrClaimNumber_RMA_TC_075 = generalclaim.GeneralClaimCreation(); //Claim Number Is Fetched And Stored In Variable StrClaimNumber_RMA_TC_075
		parentlogger.log(LogStatus.INFO, "New Claim Is Created With Claim Number::"+ " " + color.RMA_ChangeColor_Utility(StrClaimNumber_RMA_TC_075, 2));
		loggerval2 = logger.toString();
		parentlogger.appendChild(logger);
		// New Claim Is Created
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Img_GCExpander(driver), "Created General Claim Expander On Left Hand Navigation Tree",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Left Hand Navigation Tree Is Expanded");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Lnk_FinancialReserves(driver), "Financial/Reserves Link On Left Hand Navigation Tree",0); //Created General Claim's Financial/Reserves Option Is Selected //Created General Claim's Financial/Reserves Option Is Selected
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Financial/Reserves Link On Left Hand Navigation Tree Is Selected");
		//Left Hand Navigation Tree Is Expanded And Financial/Reserves Link On Left Hand Navigation Tree Is Selected

		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add Medical Reserve");
		testcall3 = true;
		RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_MedReserveAmount, RMAApp_ReserveCreation_Lst_MedStatus, 1, RMAApp_ReserveCreation_Lnk_MedReserveType, "Yes", StrExpErrMessage, "Hold", "Complete", "Added Medical Reserve Going On Hold Error Message");
		loggerval3 = logger.toString();
		parentlogger.appendChild(logger);
		driver.switchTo().parentFrame();
		//Medical Reserve Is Created And Its Going On Hold Is Verified
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add Expense Reserve");
		testcall4 = true;
		RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_ExpReserveAmount, RMAApp_ReserveCreation_Lst_ExpStatus, 1, RMAApp_ReserveCreation_Lnk_ExpReserveType, "Yes", StrExpErrMessage, "Hold", "Complete", "Added Expense Reserve Going On Hold Error Message");
		loggerval4 = logger.toString();
		parentlogger.appendChild(logger);
		driver.switchTo().parentFrame();
		//Expense Reserve Is Created And Its Going On Hold Is Verified
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add Indemnity Reserve");
		testcall5 = true;
		RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_IndemReserveAmount, RMAApp_ReserveCreation_Lst_IndemStatus, 1, RMAApp_ReserveCreation_Lnk_IndemReserveType, "No", StrExpErrMessage, "Open", "Not Required", "Not Required");
		loggerval5 = logger.toString();
		parentlogger.appendChild(logger);
		//Indemnity Reserve Is Created 
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_PaymentAddition_Utility To Add Payment Of $10");
		testcall6 = true;
		StrControlNumber_RMA_TC_075 = RMA_Functionality_Utility.RMA_PaymentAddition_Utility(RMAApp_Payment_Lst_BankAccount, RMAApp_Payment_Lst_PayeeType, RMAApp_FundsSplitDetails_Lst_TransactionType, RMAApp_FundsSplitDetails_Txt_Amount, RMAApp_Payment_Txt_LastName, RMAApp_Payment_Txt_DistributionType, 1);
		parentlogger.log(LogStatus.INFO, "New Payment With Control Number::"+ " " + color.RMA_ChangeColor_Utility(StrControlNumber_RMA_TC_075, 2)+ " "+ "Is Done");
		loggerval6 = logger.toString();
		parentlogger.appendChild(logger);
		//Payment Of Amount $10 Is Created
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Img_BackToFinancials(driver), "Back To Financial Image On Payment Creation Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(3, 0, "Wait Is Added As Back To Financials Image Is Clicked");
		
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_PaymentAddition_Utility To Add Payment Of $25");
		testcall7 = true;
		StrControlNumber_RMA_TC_01_075 = RMA_Functionality_Utility.RMA_PaymentAddition_Utility(RMAApp_Payment_Lst_BankAccount, RMAApp_Payment_Lst_PayeeType, RMAApp_FundsSplitDetails_Lst_TransactionType, RMAApp_FundsSplitDetails_Txt_Amount_1, RMAApp_Payment_Txt_LastName, RMAApp_Payment_Txt_DistributionType, 1);
		parentlogger.log(LogStatus.INFO, "New Payment With Control Number::"+ " " + color.RMA_ChangeColor_Utility(StrControlNumber_RMA_TC_01_075, 2)+ " "+ "Is Done");
		loggerval7 = logger.toString();
		parentlogger.appendChild(logger);
		//Payment Of Amount $25 Is Created
		
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Home.RMAApp_DefaultView_Err_StaticErrorText(driver), "RMA Application Error Message",0);
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "Payment On Hold Requires SuperVisory Approval Error Message",0);
		StrActualErrorMessage = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "innerHTML");
		RMA_Verification_Utility.RMA_TextCompare(StrErrorMessageExpected, StrActualErrorMessage, "Correct Error Message Display",0);
		//Payment Of Amount $25 Going On Hold Is Verified
		
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Img_BackToFinancials(driver), "Back To Financial Image On Payment Creation Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(3, 0, "Wait Is Added As Back To Financials Image Is Clicked");
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_PaymentAddition_Utility To Add Payment Of $30");
		testcall8 = true;
		StrControlNumber_RMA_TC_02_075 = RMA_Functionality_Utility.RMA_PaymentAddition_Utility(RMAApp_Payment_Lst_BankAccount, RMAApp_Payment_Lst_PayeeType, RMAApp_FundsSplitDetails_Lst_TransactionType, RMAApp_FundsSplitDetails_Txt_Amount_2, RMAApp_Payment_Txt_LastName, RMAApp_Payment_Txt_DistributionType, 1);
		parentlogger.log(LogStatus.INFO, "New Payment With Control Number::"+ " " + color.RMA_ChangeColor_Utility(StrControlNumber_RMA_TC_02_075, 2)+ " "+ "Is Done");
		loggerval8 = logger.toString();
		parentlogger.appendChild(logger);
		//Payment Of Amount $30 Is Created
		
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Home.RMAApp_DefaultView_Err_StaticErrorText(driver), "RMA Application Error Message",0);
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "Payment On Hold Requires SuperVisory Approval Error Message",0);
		StrActualErrorMessage = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "innerHTML");
		RMA_Verification_Utility.RMA_TextCompare(StrErrorMessageExpected, StrActualErrorMessage, "Correct Error Message Display",0);
		//Payment Of Amount $30 Going On Hold Is Verified
		
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		//RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite3.StrModuleGroupa1_TC_UserCreationSASuite3, LoginUserNameActual, "Correct UserName Display", 0);
		RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,2), "Funds-->Approve Transactions Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Approve Transactions Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Frm_ApproveTransact(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Funds-->Approve Transactions Frame Is Done");
		//A Switch To The Frame Containing Funds-->Approve Transactions Page Is Done
		
		filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On Approve Transactions Table", StrControlNumber_RMA_TC_01_075,0);
		Strlogstatement  = "Record With Control Number" + " " + StrControlNumber_RMA_TC_01_075 + " " + "In Payment Approval Table On Approve Transactions Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Control Number" + " " + StrControlNumber_RMA_TC_01_075 + " " + "For Payment OF $25 In Funds Approval Table Verification", StrScreenShotTCName)));
		//Record With Provided Control Number Exists Is Verified As Only Existing Record Can Be Processed Further
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 1, "input"), "check", "Header CheckBox", "In Funds Transactions Available For Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(3, 0, "Wait Is Added As Header CheckBox Is Checked And Record Is Filtered");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "Approve Button In Funds Transactions Available For Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Transaction Is Getting Approved");
		//Transaction With The Filtered Control Number Is Approved
		
		filtertext3 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext3, "Control Number Filter Text Box On Approve Transactions Table", StrControlNumber_RMA_TC_01_075,0);
		Strlogstatement  = "Record With Control Number" + " " + StrControlNumber_RMA_TC_01_075 + " " + "In Payment Approval Table On Approve Transactions Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non Existence Of Control Number" + " " + StrControlNumber_RMA_TC_01_075 + " " + "For Payment OF $25 In Funds Approval Table Verification", StrScreenShotTCName)));
		//Record With Provided Control Number Does Not Exists After Approval Is Verified 
		
		filtertext1 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext1, "Control Number Filter Text Box On Approve Transactions Table", StrControlNumber_RMA_TC_02_075,0);
		Strlogstatement  = "Record With Control Number" + " " + StrControlNumber_RMA_TC_02_075 + " " + "In Payment Approval Table On Approve Transactions Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Control Number" + " " + StrControlNumber_RMA_TC_02_075 + " " + "For Payment OF $30 In Funds Approval Table Verification", StrScreenShotTCName)));
		//Record With Provided Control Number Exists Is Verified As Only Existing Record Can Be Processed Further
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 1, "input"), "check", "Header CheckBox", "In Funds Transactions Available For Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(3, 0, "Wait Is Added As Header CheckBox Is Checked And Record Is Filtered");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Void(driver), "Void Button In Funds Transactions Available For Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Transaction Is Getting Void");
		//Transaction With The Filtered Control Number Is Voided
		
		filtertext2 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext2, "Control Number Filter Text Box On Approve Transactions Table", StrControlNumber_RMA_TC_02_075,0);
		Strlogstatement  = "Record With Control Number" + " " + StrControlNumber_RMA_TC_02_075 + " " + "In Payment Approval Table On Approve Transactions Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non Existence Of Control Number" + " " + StrControlNumber_RMA_TC_02_075 + " " + "For Payment OF $30 In Funds Approval Table Verification", StrScreenShotTCName)));
		//Record With Provided Control Number Does Not Exists After Void Is Verified 
		
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 7), "Search Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 7,9), "Search-->Funds Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait is Added as Search Page is Loaded");
		
		driver.switchTo().frame(RMA_GenericUsages_Utility.RMA_FrameNavigation("Search"));//A Switch To The Frame Containing Search Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Search Frame Is Done");;
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_POM_Search.RMAApp_SearchFunds_Txt_ControlNumber(driver), "Check Control Number Text Box On Search_Funds", StrControlNumber_RMA_TC_01_075, 0);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_POM_Search.RMAApp_Search_Chk_Soundex(driver), "uncheck", "Soundex CheckBox", " Search-->Funds Page", 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_POM_Search.RMAApp_Search_Btn_Submit(driver), "Submit Button On Search Page", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait is Added As Search Criteria Funds Page is Loaded");
		
		driver.switchTo().parentFrame();
		driver.switchTo().frame(2);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As A Switch To Specific Criteria Search Frame Is Done");
		RMA_Navigation_Utility.RMA_WebPartialLinkSelect(StrControlNumber_RMA_TC_01_075, "Specific Criteria Search Page" , 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait is Added As Transaction Page is Loaded");
		
		driver.switchTo().parentFrame();
		driver.switchTo().frame(RMA_GenericUsages_Utility.RMA_FrameNavigation("Transaction"));//A Switch To The Frame Containing Search Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Transaction Frame Is Done");;
		StrCheckStatusActual = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Txt_CheckStatus(driver), "value");
		RMA_Verification_Utility.RMA_TextCompare(StrCheckStatusExpected, StrCheckStatusActual, "Check Status ", 0);
		//Approved Transaction's Check Status Is Released Is Verified
		
		driver.switchTo().parentFrame();
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");
		
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_075, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Medical", 0);
		Strlogstatement  = "Medical Reserve With Claim Number" + " " + StrClaimNumber_RMA_TC_075 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Medical Reserve For Claim" + " " + StrClaimNumber_RMA_TC_075 + " " + "Of Amount $120 In Funds Reserve Approval Table Verification", StrScreenShotTCName)));
		//Medical Reserve Of Amount $120 Exists Is Verified As Only Existing Record Can Be Processed Further
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 1, "input"), "check", "Header CheckBox", "In Funds-->Reserve Approval Table", 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "Approve Selected Button In Funds-->Reserve Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Is Approved");
		//Medical Reserve Is Approved
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_075, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Medical", 0);
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non-Existence Of Medical Reserve For Claim" + " " + StrClaimNumber_RMA_TC_075 + " " + "Of Amount $120 In Funds Reserve Approval Table Verification", StrScreenShotTCName)));
		//Medical Reserve Of Amount $120 Does Not Exists After Approval Is Verified 
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_075, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
		Strlogstatement  = "Expense Reserve With Claim Number" + " " + StrClaimNumber_RMA_TC_075 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Expense Reserve For Claim" + " " + StrClaimNumber_RMA_TC_075 + " " + "Of Amount $150 In Funds Reserve Approval Table Verification", StrScreenShotTCName)));
		//Expense Reserve Of Amount $150 Exists Is Verified As Only Existing Record Can Be Processed Further
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 1, "input"), "check", "Header CheckBox", "In Funds-->Reserve Approval Table", 0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Lst_StatusReason(driver), "Medical Update","Status Reason List Box","Funds-->Reserve Approval Page",0);
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "Reject Selected Button In Funds-->Reserve Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Is Rejected");
		//Expense Reserve Is Rejected
		
		driver.switchTo().parentFrame();
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Payment Parameter Options Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "uncheck", "Payment Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "uncheck", "Supervisory Approval Check Box", "Payment Parameter Setup Page",0);      // Supervisory Approval CheckBox Is Checked On Payment Parameter Set Up Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "uncheck", "Reserve Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Reserve Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "uncheck", "Notify Immediate Supervisor Check Box", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "uncheck", "Notify Immediate Supervisor Check Box For Reserves", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box For reserves Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "uncheck", "Supervisory Approval Check Box For Reserves", "Payment Parameter Setup",0); //Supervisory Approval CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver), "Save Image On Payment Parameter Set Up Page",0);//Save Image Is Clicked
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "deselect", "Notify Immediate Supervisor Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "deselect", "Payment Limits Are Exceeded Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "deselect", "Reserve Limits Are Exceeded Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "deselect", "Notify Immediate SuperVisor For Reserves Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "deselect", "Supervisory Approval Check Box",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "deselect", "Use SuperVisory Approval For Reserves Check Box",0);
		
		driver.switchTo().parentFrame();
		StrPrimaryWindowHandle = driver.getWindowHandle();
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,5), "Security-->User Privileges SetUp Menu Option", 0);
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
		driver.manage().window().maximize();
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginUserFirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		ActualRowCount = RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), 0, 0, false, false, "Reserve Limits Grid Table" , 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevResLimit_Rdb_ReserveLimitsGridRadioButton(driver), "RadioButton Corresponding to User"+ " " + StrConLoginUserFirstAndLastName, 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Btn_Remove(driver), "Remove Button For Reserve Limits", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Limit Max Amount For"+ " " + StrConLoginUserFirstAndLastName+ " " + "Is Removed");
		RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), 0, ActualRowCount-1, true, false, "Reserve Limits Grid Table" , 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Reserve Limit Removal For User" + " " +StrConLoginUserFirstAndLastName + "Is Verified");
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Reserve Limit Removal Verification For User"+ " " +StrConLoginUserFirstAndLastName , StrScreenShotTCName)));
		//Reserve Limits Provided To User With Name Containing CSC Are Removed
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginMgr1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		ActualRowCount = RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), 0, 0, false, false, "Reserve Limits Grid Table" , 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevResLimit_Rdb_ReserveLimitsGridRadioButton(driver), "RadioButton Corresponding to User"+ " " + RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3, 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Btn_Remove(driver), "Remove Button For Reserve Limits", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Limit Max Amount For"+ " " + StrConLoginMgr1FirstAndLastName+ "Is Removed");
		RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), 0, ActualRowCount-1, true, false, "Reserve Limits Grid Table" , 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Reserve Limit Removal For User" + " " +StrConLoginMgr1FirstAndLastName + "Is Verified");
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Reserve Limit Removal Verification For User"+ " " +StrConLoginMgr1FirstAndLastName , StrScreenShotTCName)));
		//Reserve Limits Provided To User With Name Containing A1 Are Removed
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "uncheck", "Enable Reserve Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Reserve Limits Tab",0);
		//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Reserve Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "deselect", "Enable Reserve Limits CheckBox",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_RestUnspcfdUsers(driver), "deselect", "Restrict Unspecified Users CheckBox",0);
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab  On User-Privileges SetUp Page", 0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginUserFirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
		ActualRowCount = RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), 0, 0, false, false, "Payment Limits Grid Table" , 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Rdb_PaymentLimitsGridRadioButton(driver), "RadioButton Corresponding to Text" + " " + StrConLoginUserFirstAndLastName, 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Remove(driver), "Remove Button For Payment Limits", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Payment Limit Max Amount For User" + " " + StrConLoginUserFirstAndLastName + "Is Removed");
		RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), 0, ActualRowCount-1, true, false, "Payment Limits Grid Table" , 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limit Removal For User" + " " +StrConLoginUserFirstAndLastName + "Is Verified");
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Removal Verification For User"+ " " +StrConLoginUserFirstAndLastName , StrScreenShotTCName)));
		//Payment Limits Provided To User With Name Containing CSC Are Removed
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginMgr1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
		ActualRowCount = RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), 0, 0, false, false, "Payment Limits Grid Table" , 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Rdb_PaymentLimitsGridRadioButton(driver), "RadioButton Corresponding to Text" + " " + RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3, 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Remove(driver), "Remove Button For Payment Limits", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Payment Limit Max Amount For User" + StrConLoginMgr1FirstAndLastName + "Is Removed");
		RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), 0, ActualRowCount-1, true, false, "Payment Limits Grid Table" , 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limit Removal For User" + " " +StrConLoginMgr1FirstAndLastName + "Is Verified");
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Removal Verification For User"+ " " +StrConLoginMgr1FirstAndLastName , StrScreenShotTCName)));
		//Payment Limits Provided To User With Name Containing A1 Are Removed
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "uncheck", "Enable Payment Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",0);
		//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is UnChecked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is UnChecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "deselect", "Enable Payment Limits CheckBox",0);
		driver.close();
		driver.switchTo().window(StrPrimaryWindowHandle);
		
	} catch (Exception|Error e) {
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		
		
		if ((testcall2 == true) && (loggerval2.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Executing Test Case" +" "+ "RMA_TC_004: General Claim Creation" + " " +  "And Hence The Test Case Is A Fail");
		parentlogger.appendChild(logger);
		
		}
		else if ((testcall3 == true) && (loggerval3.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Medical reserve Of $120"  + " " +  "And Hence Reserve Creation Was Not Successful");
		parentlogger.appendChild(logger);
		}
		else if ((testcall4 == true) && (loggerval4.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Expense Reserve Of $150"  + " " +  "And Hence Reserve Creation Was Not Successful");
		parentlogger.appendChild(logger);
		}
		
		else if ((testcall5 == true) && (loggerval5.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Indemnity Reserve Of $50" +" "+ "And Hence Reserve Creation Was Not Successful");
		parentlogger.appendChild(logger);
		
		}
		else if ((testcall6 == true) && (loggerval6.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Payment of $10"  + " " +  "And Hence Payment Was Not Successful");
		parentlogger.appendChild(logger);
		}
		else if ((testcall7 == true) && (loggerval7.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Payment of $25"  + " " +  "And Hence Payment Was Not Successful");
		parentlogger.appendChild(logger);
		}
		else if ((testcall8 == true) && (loggerval8.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Payment of $30"  + " " +  "And Hence Payment Was Not Successful");
		parentlogger.appendChild(logger);
		}
		throw (e);
	}	
	}


@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,0);
		}
		reports.endTest(parentlogger);
		
	} catch (Exception |Error e) {
		throw (e);
	}
}
}

