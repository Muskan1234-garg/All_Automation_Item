package rmaseleniumtestscripts;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		String x = "3";
		
		//int sum =Integer.valueOf(x) + 2;
		
		System.out.println("hhh" + Integer.valueOf(x) + 2);
		
		

	}

}
