package rmaseleniumtestscripts;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_UserPrivilegesSetUp;
import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_ScreenCapture_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_042
//Description    : Verify That  Payment Limits Can Be Set At Group And User Level In User Privileges Setup
//Depends On TC  : None
//Revision       : 0.0 - KumudNaithani-01-21-2016 
//=================================================================================================
public class RMA_TC_042 extends rmaseleniumtestscripts.RMA_TC_BaseTest{
	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;
	static String StrScreenShotTCName;
@Test 
public void RMA_TC_042_test () throws Exception, Error 
// Verify That  Payment Limits Can Be Set At Group And User Level In User Privileges Setup
{
	try {
		logger = reports.startTest("TC_042_Group And User Level Payment Limit SetUp", "Payment Limits Set At Group And User Level In User Privileges SetUp Are Validated");

		String RMAApp_UserPrev_Lst_LOB;
		String RMAApp_UserPrev_Lst_LoginUser;
		String RMAApp_UserPrev_Lst_LoginMgr1;
		String RMAApp_UserPrev_Lst_LoginMgr2;
		String RMAApp_UserPrev_Lst_LoginMgrGrp1;
		String RMAApp_UserPrev_Lst_LoginMgrGrp2;
		String RMAApp_UserPrev_Lst_LoginUsrGrp;
		int RMAApp_UserPrev_Txt_LoginMgr2_MaxAmt;
		int RMAApp_UserPrev_Txt_LoginUser_MaxAmt;
		int RMAApp_UserPrev_Txt_LoginMgr1_MaxAmt;
		int RMAApp_UserPrev_Txt_LoginMgrGrp1_MaxAmt;
		int RMAApp_UserPrev_Txt_LoginMgrGrp2_MaxAmt;
		int RMAApp_UserPrev_Txt_LoginUsrGrp_MaxAmt;
		String StrPrimaryWindowHandle;
		String StrAccept;
		//Local Variable Declaration
		
		StrScreenShotTCName = "TC_042";
		StrAccept = "Yes";
		RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMA_Suite_01_SprVsrApprovalTestData.xlsx"); //Excel WorkBook RMASeleniumAutomationTestData IS Fetched To Retrieve Data 
		RMAApp_UserPrev_Lst_LOB = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_042", 1, 0); //Line Of Business Name Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Lst_LoginUser = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_042", 1, 1); // RMAApp_UserPrev_Lst_LoginUser Name Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Lst_LoginMgr1 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_042", 1, 2); // RMAApp_UserPrev_Lst_LoginMgr1 Name Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Lst_LoginMgr2 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_042", 1, 3); // RMAApp_UserPrev_Lst_LoginMgr2 Name Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Lst_LoginUsrGrp = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_042", 1, 6); // RMAApp_UserPrev_Lst_LoginUsrGrp Name Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Lst_LoginMgrGrp1 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_042", 1, 4); // RMAApp_UserPrev_Lst_LoginMgrGrp1 Name Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Lst_LoginMgrGrp2 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_042", 1, 5); // RMAApp_UserPrev_Lst_LoginMgrGrp2 Name Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Txt_LoginUser_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_042", 1, 7); // RMAApp_UserPrev_Lst_CurrAdjGrp_MaxAmt Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Txt_LoginMgr1_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_042", 1, 8); // RMAApp_UserPrev_Lst_CurrAdjMgrGrp1_MaxAmt Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Txt_LoginMgr2_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_042", 1, 9); // RMAApp_UserPrev_Lst_CurrAdjMgrGrp2_MaxAmt Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Txt_LoginUsrGrp_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_042", 1, 12); // RMAApp_UserPrev_Lst_LoginUsrGrp_MaxAmt Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Txt_LoginMgrGrp1_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_042", 1, 10); // RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt Is Fetched From DataSheet RMA_TC_042
		RMAApp_UserPrev_Txt_LoginMgrGrp2_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_042", 1, 11); // RMAApp_UserPrev_Lst_LoginMgrGrp1_MaxAmt Is Fetched From DataSheet RMA_TC_042
		
		StrPrimaryWindowHandle = driver.getWindowHandle();
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option On RMA Application Default View Page",1); //Security Menu Option Is Selected
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,5), "Security-->User Privileges SetUp Menu Option On RMA Application Default View Page",1); //User Privileges Set Up Menu Option Is Selected
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 1, "Wait Is Added As User-Privileges SetUp  Window Is Loaded");
		logger.log(LogStatus.INFO, "User-Privileges SetUp Page Of RMA Application Is Opened");
		//User-Privileges SetUp Page Of RMA Application Is Opened

		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab On RMA Application's User-Privileges SetUp Page",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As Payment Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), RMAApp_UserPrev_Lst_LoginUser,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginUser_MaxAmt),1);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Limit Max Amount For LoginUser Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginUser, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginUser_MaxAmt), "Payment Limits Grid Table",1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For LoginUser ", StrScreenShotTCName)));
		// Payment Limit Is Added To "LoginUser" User Above
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), RMAApp_UserPrev_Lst_LoginMgr1,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginMgr1_MaxAmt),1);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Limit Max Amount For LoginMgr1 Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginMgr1, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginMgr1_MaxAmt), "Payment Limits Grid Table",1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For LoginMgr1 ", StrScreenShotTCName)));
		// Payment Limit Is Added To "LoginMgr1" User Above
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), RMAApp_UserPrev_Lst_LoginMgr2,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginMgr2_MaxAmt),1);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Limit Max Amount For LoginMgr2 Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginMgr2, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginMgr2_MaxAmt), "Payment Limits Grid Table",1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For LoginMgr2 ", StrScreenShotTCName)));
		// Payment Limit Is Added To "LoginMgr2" User Above
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Rdb_Groups(driver), "Groups Radio Button On RMA Application's User Privileges Set Up Page's Payment Limits Tab",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Group Radio Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab Is Clicked");
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_LoginUsrGrp,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginUsrGrp_MaxAmt),1);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Limit Max Amount For LoginUsrGrp Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginUsrGrp, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginUsrGrp_MaxAmt), "Payment Limits Grid Table",1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For LoginUsrGrp ", StrScreenShotTCName)));
		// Payment Limit Is Added To "LoginUsrGrp" Group
		
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_LoginMgrGrp1,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginMgrGrp1_MaxAmt),1);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Limit Max Amount For LoginMgrGrp1 Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginMgrGrp1, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginMgrGrp1_MaxAmt), "Payment Limits Grid Table",1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For LoginMgrGrp1 ", StrScreenShotTCName)));
		// Payment Limit Is Added To "LoginMgrGrp1" Group
		
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_Group(driver), RMAApp_UserPrev_Lst_LoginMgrGrp2,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",1);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginMgrGrp2_MaxAmt),1);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",1); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Limit Max Amount For LoginMgrGrp2 Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), RMAApp_UserPrev_Lst_LoginMgrGrp2, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginMgrGrp2_MaxAmt), "Payment Limits Grid Table",1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For LoginMgrGrp2", StrScreenShotTCName)));
		// Payment Limit Is Added To "LoginMgrGrp2" Group
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "check", "Enable Payment Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",1);
		//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "check", "Restrict Unspecified Users CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",1);
		//Restrict Unspecified User CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted

		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "select", "Enable Payment Limits CheckBox",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "select", "Restrict Unspecified Users CheckBox",1);
		
		driver.close();
		driver.switchTo().window(StrPrimaryWindowHandle);
		
	} catch (Exception|Error e) {
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		throw (e);
	}
	
	}

@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		
		StrScreenShotTCName = "TC_042";
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1);
		}
		reports.endTest(logger);
	} catch (Exception |Error e) {
		throw (e);
	}
}
}
	