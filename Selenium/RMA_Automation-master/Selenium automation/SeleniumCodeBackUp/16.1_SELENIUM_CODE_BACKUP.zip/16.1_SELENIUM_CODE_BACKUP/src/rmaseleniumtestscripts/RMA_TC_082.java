package rmaseleniumtestscripts;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Funds_ResApprove;
import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_Login_DSNSelect_Frames;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentParameterSetUp;
import rmaseleniumPOM.RMA_Selenium_POM_UserPrivilegesSetUp;
import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_Functionality_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_NegativeVerification_Utility;
import rmaseleniumutilties.RMA_ScreenCapture_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_082
//Description    : TC_082_ Hold Handling In Case Of Claim Incurred Limit With Notify Immediate Manager Setting Applied Is Validated
//Depends On TC  : TC_UserCreationSASuite4 (When Running In Suite TC_UserDeletionSASuite4 Should Be Executed At The End To Delete The Created Users And Groups)
//Revision       : 0.0 - KumudNaithani-04-11-2016 
//=================================================================================================
//Note: Here: LoginUser Stands For User Containing CSC In Its Name, LoginMgr1 Stands For User Having A1 In Its Name And LoginMgr2 Stands For User Having A2 In Its Name, Users Are Arranged In Hierarchy CSC-->A1-->A2-->A3

public class RMA_TC_082 extends RMA_TC_BaseTest {
	
static String ExceptionRecorded;
static String []ErrorMessage;
static String FinalErrorMessage;
static String ErrorMessageType;
static String StrScreenShotTCName;


@Test 
public void RMA_TC_082_Test () throws Exception, Error 
//Verify Hold Handling In Case Of Claim Incurred Limit With Notify Immediate Manager Setting Applied
{
	parentlogger = reports.startTest("TC_082_Hold Handling For Per Claim Incurred Limit With Notify Immediate Manager Setting", "Hold Handling In Case Of Per Claim Incurred Limit With Notify Immediate Manager Setting Applied Is Validated");
	parentlogger.assignAuthor("Kumud Naithani");
	try {
		String StrPrimaryWindowHandle;
		String RMAApp_UserPrev_Lst_LOB;
		int RMAApp_UserPrev_Txt_LoginUser_PerClaimIncurredLimits_MaxAmt;
		int RMAApp_UserPrev_Txt_LoginUserMgr1_PerClaimIncurredLimits_MaxAmt;
		String StrAccept;
		String StrExpErrMessage;
		String LoginUserNameActual;
		int RMAApp_ReserveCreation_Txt_ExpReserveAmount;
		int RMAApp_ReserveCreation_Txt_IndemReserveAmount;
		int RMAApp_ReserveCreation_Txt_Exp_01_ReserveAmount;
		String RMAApp_ReserveCreation_Lst_ExpStatus;
		String RMAApp_ReserveCreation_Lst_Exp_01_Status;
		String RMAApp_ReserveCreation_Lst_IndemStatus;
		String RMAApp_ReserveCreation_Lnk_ExpReserveType;
		String RMAApp_ReserveCreation_Lnk_IndemReserveType;
		String RMAApp_ReserveCreation_Lnk_Exp_01_ReserveType;
		String StrClaimNumber_RMA_TC_082;
		String Strlogstatement;
		int ActualRowCount;
		String StrConLoginUserFirstAndLastName;
		String StrConLoginMgr1FirstAndLastName;
		String StrClaimNumber_RMA_TC_082_01;
		String StrErrorMessageExpected;
		String StrErrorMessageExpected_01;
		String StrActualErrorMessage;
		String StrScreenShotName;
		int logval;
		
		//Local Variable Declaration
		
		StrScreenShotTCName = "TC_082";
		loggerval1 = "NotInitialized";
		loggerval2 = "NotInitialized";
		loggerval3 = "NotInitialized";
		loggerval4 = "NotInitialized";
		loggerval5 = "NotInitialized";
		testcall1 = false; 
		testcall2 = false; 
		testcall3 = false;
		testcall4 = false; 
		testcall5 = false;
		StrAccept = "Yes";
		logval = 0;
		
		StrConLoginUserFirstAndLastName = RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4+", "+RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4;
		StrConLoginMgr1FirstAndLastName = RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4+", "+RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4; 

		StrExpErrMessage = "rmA-1638:This reserve has been sent for the Supervisor approval and is in the Hold status as Exceeded Per Claim Incurred Limit";
		StrErrorMessageExpected = "1 out of 1 selected reserves could not be processed successfully.";
		StrErrorMessageExpected_01 = "Exceeded Per Claim Incurred Limit";
		
		RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMA_Suite_04_SprVsrApprovalTestData.xlsx"); //Excel WorkBook RMA_Suite_04_SprVsrApprovalTestData Is Fetched To Retrieve Data
		RMAApp_UserPrev_Lst_LOB = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_082", 1, 0); //Line Of Business Name Is Fetched From DataSheet RMA_TC_082
		RMAApp_UserPrev_Txt_LoginUser_PerClaimIncurredLimits_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_082", 1, 1); //Maximum Reserve Limit Amount For LoginUser Is Fetched From DataSheet RMA_TC_082
		RMAApp_UserPrev_Txt_LoginUserMgr1_PerClaimIncurredLimits_MaxAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_082", 1, 2); //Maximum Reserve Limit For LoginMgr1 User Name Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Txt_Exp_01_ReserveAmount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_082", 1, 3); //Reserve Amount Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Lst_Exp_01_Status = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_082", 1, 4); //Reserve Status Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Lnk_Exp_01_ReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_082", 1, 5); //Reserve Type Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Txt_IndemReserveAmount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_082", 1, 6); //Reserve Amount Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Lst_IndemStatus = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_082", 1, 7); //Reserve Status Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Lnk_IndemReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_082", 1, 8); //Reserve Type Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Txt_ExpReserveAmount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_082", 1, 9); //Reserve Amount Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Lst_ExpStatus = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_082", 1, 10); //Reserve Status Is Fetched From DataSheet RMA_TC_082
		RMAApp_ReserveCreation_Lnk_ExpReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_082", 1, 11); //Reserve Type Is Fetched From DataSheet RMA_TC_082
		
		/*---------------------------Logging In The Application With Credentials Of User Containing CSC In Its Name Is Started------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Button On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In

		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare( RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*---------------------------Logging In The Application With Credentials Of User Containing CSC In Its Name Is Completed--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------Assignment Of Per Claim Incurred Limits To Users Containing CSC And A1 In Their Names Is Started---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		StrPrimaryWindowHandle = driver.getWindowHandle();
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,5), "Security-->User Privileges SetUp Menu Option", 0);
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
		driver.manage().window().maximize();
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page",0);
		RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Reserve Limits", "Reserver Limits Tab On User Privileges Setup Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Reserve Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "uncheck", "Enable Reserve Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Reserve Limits Tab",logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Reserve Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is UnChecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "deselect", "Enable Reserve Limits CheckBox",logval);
		//Check Box For Reserve Limits Tab Is Unchecked 

		RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Print Check Limits", "Print Check Limits Tab On User Privileges Setup Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Print Check Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPrintCheckLimits_Chk_EnablePrintCheckLimits(driver), "uncheck", "Enable Print Check Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Print Check Limits Tab",logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Print Check Limits CheckBox On RMA Application User Privilege SetUp Page's Printc Check Limits Tab Is UnChecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPrintCheckLimits_Chk_EnablePrintCheckLimits(driver), "deselect", "Enable Print Check Limits CheckBox",logval);
		//Check Box For Print Check Limits Tab Is Unchecked 

		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab  On User-Privileges SetUp Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Payment Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "uncheck", "Enable Payment Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is UnChecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "deselect", "Enable Payment Limits CheckBox",logval);
		//Check Box For Payment Limits Tab Is Unchecked 

		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPayDetailLimit_Lnk_PayDetailLimits(driver), "Pay Detail Limits Tab On RMA Application's User-Privileges SetUp Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As PayDetail Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPayDetailLimit_chk_EnablePaymentDetailLimits(driver), "uncheck", "Enable Payment Detail Limits CheckBox",  "RMA Application's User Privileges SetUp Page's PayDetail Limits Tab",logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Payment Detail Limits CheckBox On RMA Application User Privilege SetUp Page's PayDetail Limits Tab Is UnChecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPayDetailLimit_chk_EnablePaymentDetailLimits(driver), "deselect", "Enable Payment Detail Limits CheckBox",logval);
		//Check Box For Pay Detail Limits Tab Is Unchecked 	
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPer_Tab_ClaimLimits(driver), "Claim Limits Tab On User-Privileges SetUp Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Claim Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevEventTypeLimit_Chk_EnbClaimLimits(driver), "uncheck", "Enable Claim Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Claim Limits Tab",logval);
		//Enable Claim Limits CheckBox On RMA Application User Privilege SetUp Page's Claim Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Claim Limits CheckBox On RMA Application User Privilege SetUp Page's Claim Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevEventTypeLimit_Chk_EnbClaimLimits(driver), "deselect", "Enable Claim Limits CheckBox",logval);
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPer_Tab_EventTypeLimits(driver), "Event Type Limits Tab On User-Privileges SetUp Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Event Type Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevEventTypeLimit_Chk_EnbEventTypeLimits(driver), "uncheck", "Enable Event Type Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Event Type Limits Tab",logval);
		//Enable Event Type Limits CheckBox On RMA Application User Privilege SetUp Page's Event Type Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Event Type Limits CheckBox On RMA Application User Privilege SetUp Page's Event Type Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevEventTypeLimit_Chk_EnbEventTypeLimits(driver), "deselect", "Enable Event Type Limits CheckBox",logval);
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClaimPayLimit_Tab_PerClaimPayLimit(driver), "Per Claim Pay Limits Tab On User-Privileges SetUp Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Per Claim Pay Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClaimPayLimit_Chk_EnablePerClaimPayLimits(driver), "uncheck", "Enable Per Claim Pay Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Per Claim Pay Limits Tab",logval);
		//Enable Per Claim Pay Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Pay Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Per Claim Pay Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Pay Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClaimPayLimit_Chk_EnablePerClaimPayLimits(driver), "deselect", "Enable Per Claim Pay Limits CheckBox",logval);
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tab_PerClaimIncLimits(driver), "Per Claim Incurred Limits Tab On User-Privileges SetUp Page", logval);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Per Claim Incurred Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "uncheck", "Enable Per Claim Incurred Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Per Claim Incurred Limits Tab",logval);
		//Enable Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Incurred Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, logval, "Wait Is Added As Enable Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Incurred Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "deselect", "Enable Per Claim Incurred Limits CheckBox",logval);
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tab_PerClaimIncLimits(driver), "Per Claim Incurred Limits On User Privileges Setup Page ", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Per Claim Incurred Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginUserFirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Txt_MaxAmount(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Per Claim Incurred Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginUser_PerClaimIncurredLimits_MaxAmt),0);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Per Claim Incurred Limits",0); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Per Claim Incurred Limit Max Amount For" + " " + StrConLoginUserFirstAndLastName+ " " + "Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tbl_UsersGroups(driver), StrConLoginUserFirstAndLastName, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginUser_PerClaimIncurredLimits_MaxAmt), "Per Claim Incurr Limits Grid Table",0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Per Claim Incurred Limit Verification For User"+ " "+ StrConLoginUserFirstAndLastName, StrScreenShotTCName)));
		// Per Claim Incurred Limit Is Added To User With Name Containing CSC Above
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginMgr1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Txt_MaxAmount(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Per Claim Incurred Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_LoginUserMgr1_PerClaimIncurredLimits_MaxAmt),0);	
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Per Claim Incurred Limits",0); 
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Per Claim Incurred Limit Max Amount For" + " " + StrConLoginMgr1FirstAndLastName+ " " + "Is Added");
		RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tbl_UsersGroups(driver), StrConLoginMgr1FirstAndLastName, 3, String.valueOf(RMAApp_UserPrev_Txt_LoginUserMgr1_PerClaimIncurredLimits_MaxAmt), "Per Claim Incurr Limits Grid Table",0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Per Claim Incurred Limit Verification For User"+ " "+ StrConLoginMgr1FirstAndLastName, StrScreenShotTCName)));
		// Per Claim Incurred Limit Is Added To User With Name Containing A1 Above
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "check", "Enable Per Claim Incurred Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Per Claim Incurred Limits Tab",0);
		//Enable Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Incurred Limits Tab Is Checked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's PayDetail Limits Tab Is Checked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_RestrictUnspecifiedUsers(driver), "uncheck", "Restrict Unspecified Users CheckBox",  "RMA Application's User Privileges SetUp Page's Per Claim Incurred Limits Tab",0);
		//Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is UnChecked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Pay Detail Limits Tab Is UnChecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "select", "Enable Per Claim Incurred Limits CheckBox On User Privileges SetUp Page's Per Claim Incurred Limits Tab",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_RestrictUnspecifiedUsers(driver), "deselect", "Restrict Unspecified Users CheckBox On User Privileges SetUp Page's Per Claim Incurred Limits Tab",0);
		//Select/De-select State Of The Enable Per Claim Incurred Limits CheckBox And Restrict Unspecified User CheckBox Is Verified		
		
		driver.close();
		driver.switchTo().window(StrPrimaryWindowHandle);
			
		/*---------------------------Assignment Of Per Claim Incurred Limits To User Containing CSC And A1 In Their Names Is Completed-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------Selection Of Required Settings In Payment Parameter SetUp Page Is Started---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Utilities Option Is Clicked");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Event Creation Controls IS Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");   
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "uncheck", "Payment Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Limits Are Exceeded Check Box Is Unchecked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayDetailLimitExceed(driver), "uncheck", "Payment Detail Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Limits Are Exceeded Check Box Is Unchecked on Payment Parameter Setup Page		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "uncheck", "Supervisory Approval Check Box", "Payment Parameter Setup Page",0);      // Supervisory Approval CheckBox Is Unchecked On Payment Parameter Set Up Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "uncheck", "Notify Immediate Supervisor Check Box", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box Is Unchecked on Payment Parameter Setup Page		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "uncheck", "Reserve Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Reserve Limits Are Exceeded Check Box Is Unchecked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "check", "Incurred Limits Are Exceeded Check Box For Reserves", "Payment Parameter Setup Page",0); //Incurred Limits Are Exceeded CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "uncheck", "Notify Immediate Supervisor Check Box For Reserves", "Payment Parameter Setup Page",0); //Notify Immediate SuperVisor Check Box For reserves Is Unchecked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "check", "Supervisory Approval Check Box For Reserves", "Payment Parameter Setup Page",0); //Supervisory Approval CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PerClaimPayLimitsExceeded(driver), "uncheck", "Per Claim Pay Limits Are Exceeded", "Payment Parameter Setup Page",0); //Per Claim Pay Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver), "Save Image On Payment Parameter Set Up Page",0); //Save image is clicked
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");
		
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "deselect", "Payment Limits Are Exceeded Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayDetailLimitExceed(driver), "deselect", "Payment Detail Limits Are Exceeded Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "deselect", "Notify Immediate Supervisor Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "deselect", "Supervisory Approval Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "deselect", "Reserve Limits Are Exceeded Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "select", "Incurred Limits Are Exceeded Check Box For Reserves On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "deselect", "Notify Immediate SuperVisor For Reserves Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "select", "Use SuperVisory Approval For Reserves Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PerClaimPayLimitsExceeded(driver), "deselect", "Per Claim Pay Limits Are Exceeded On Payment Parameter Setup Page",0);
		//Required SuperVisory Approval Settings Are Saved In Payment Parameter Set Up Page
		
		/*---------------------------Selection Of Required Settings In Payment Parameter SetUp Page Is Completed---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------General Claim Creation Is Started --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		parentlogger.log(LogStatus.INFO, "Following Test Is Called :: RMA_TC_004 To Create New Claim");
		testcall1 = true;
		RMA_TC_004 generalclaim = new RMA_TC_004();
		StrClaimNumber_RMA_TC_082 = generalclaim.GeneralClaimCreation(); //Claim Number Is Fetched And Stored In Variable StrClaimNumber_RMA_TC_082
		parentlogger.log(LogStatus.INFO, "New Claim Is Created With Claim Number::"+ " " + color.RMA_ChangeColor_Utility(StrClaimNumber_RMA_TC_082, 2));
		loggerval1 = logger.toString();
		parentlogger.appendChild(logger);
		// New Claim Is Created
		
		/*---------------------------General Claim Creation Is Completed -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------Creation Of Expense Reserve Of $700 And Its Going On Hold Verification Is Started ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Img_GCExpander(driver), "Created General Claim Expander On Left Hand Navigation Tree",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Left Hand Navigation Tree Is Expanded");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Lnk_FinancialReserves(driver), "Financial/Reserves Link On Left Hand Navigation Tree",0); //Created General Claim's Financial/Reserves Option Is Selected //Created General Claim's Financial/Reserves Option Is Selected
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Financial/Reserves Link On Left Hand Navigation Tree Is Selected");
		//Left Hand Navigation Tree Is Expanded And Financial/Reserves Link On Left Hand Navigation Tree Is Selected
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add Expense Reserve Of Amount $700");
		testcall2 = true;
		RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_ExpReserveAmount, RMAApp_ReserveCreation_Lst_ExpStatus, 1, RMAApp_ReserveCreation_Lnk_ExpReserveType, "Yes", StrExpErrMessage, "Hold", "Complete", "Added Expense Reserve Going On Hold Error Message");
		loggerval2 = logger.toString();
		parentlogger.appendChild(logger);
		driver.switchTo().parentFrame();
		//Expense Reserve Is Created And Its Going On Hold Is Verified

		
		/*---------------------------Creation Of Expense Reserve Of $700 And Its Going On Hold Verification Is Completed --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------User With Name Starting With CSC Is Logged Out And User With Name Staring With A1 Is Logged In  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*-------------------------- User With Name Staring With A1 Is Successfully Logged In The Application  --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A1 In Its Name Is Started -------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");
		
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
		Strlogstatement  = "Expense Reserve Of Amount $700 With Claim Number" + " " + StrClaimNumber_RMA_TC_082 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non Existence Of Expense Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082 + " " + "Of Amount $700 In Funds Reserve Approval Table For A1 User Verification", StrScreenShotTCName)));
		//Expense Reserve Of Amount $700 Does Not Exists In The Funds-->Reserve Approval List For User Containing A1 In Its Name Is Verified
		
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A1 In Its Name Is Completed ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------User With Name Containing A1 Is Logged Out And User With Name Containing A2 Is Logged In  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*-------------------------- User With Name Containing A2 Is Successfully Logged In The Application  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Displayed To User Containing A2 In Its Name Is Started --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");
		
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
		Strlogstatement  = "Expense Reserve Of Amount $700 With Claim Number" + " " + StrClaimNumber_RMA_TC_082 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Expense Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082 + " " + "Of Amount $700 In Funds Reserve Approval Table For A2 User Verification", StrScreenShotTCName)));
		//Expense Reserve Of Amount $700 Exists In The Funds-->Reserve Approval List For User Containing A2 In Its Name Is Verified 
		
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Visible To User Containing A2 In Its Name Is Completed ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------User With Name Containing A2 Is Logged Out And User With Name Containing A3 Is Logged In  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera3_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera3_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite4.StrUsera3_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*-------------------------- User With Name Containing A3 Is Successfully Logged In The Application  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A3 In Its Name Is Started ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");
		
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
		Strlogstatement  = "Expense Reserve Of Amount $700 With Claim Number" + " " + StrClaimNumber_RMA_TC_082 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non Existence Of Expense Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082 + " " + "Of Amount $700 In Funds Reserve Approval Table For A3 User Verification", StrScreenShotTCName)));
		//Expense Reserve Of Amount $700 Does Not Exists In The Funds-->Reserve Approval List For User Containing A3 In Its Name Is Verified
		
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A3 In Its Name Is Completed ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		/*---------------------------User With Name Containing A2 Is Logged Out And User With Name Containing CSC Is Logged In  -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In

		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare( RMA_TC_UserCreationSASuite4.StrUsercsc_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*---------------------------Logging In The Application With Credentials Of User Containing CSC In Its Name Is Completed--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------Selection Of Required Settings In Payment Parameter SetUp Page Is Started---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Event Creation Controls IS Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");   
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "check", "Notify Immediate Supervisor Check Box For Reserves", "Payment Parameter Setup Page",0); //Notify Immediate SuperVisor Check Box For reserves Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver), "Save Image On Payment Parameter Set Up Page",0); //Save image is clicked
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "select", "Notify Immediate SuperVisor For Reserves Check Box On Payment Parameter Setup Page",0);
		//Required SuperVisory Approval Settings Are Saved In Payment Parameter Set Up Page
		
		/*---------------------------Selection Of Required Settings In Payment Parameter SetUp Page Is Completed-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------General Claim Creation Is Started ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		parentlogger.log(LogStatus.INFO, "Following Test Is Called :: RMA_TC_004 To Create New Claim");
		testcall3 = true;
		RMA_TC_004 generalclaim_01 = new RMA_TC_004();
		StrClaimNumber_RMA_TC_082_01 = generalclaim_01.GeneralClaimCreation(); //Claim Number Is Fetched And Stored In Variable StrClaimNumber_RMA_TC_082_01
		parentlogger.log(LogStatus.INFO, "New Claim Is Created With Claim Number::"+ " " + color.RMA_ChangeColor_Utility(StrClaimNumber_RMA_TC_082_01, 2));
		loggerval3 = logger.toString();
		parentlogger.appendChild(logger);
		// New Claim Is Created
		
		/*---------------------------General Claim Creation Is Completed --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------Creation Of Indemnity Reserve Of $800 And Its Going On Hold Verification Is Started ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Img_GCExpander(driver), "Created General Claim Expander On Left Hand Navigation Tree",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Left Hand Navigation Tree Is Expanded");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Lnk_FinancialReserves(driver), "Financial/Reserves Link On Left Hand Navigation Tree",0); //Created General Claim's Financial/Reserves Option Is Selected //Created General Claim's Financial/Reserves Option Is Selected
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Financial/Reserves Link On Left Hand Navigation Tree Is Selected");
		//Left Hand Navigation Tree Is Expanded And Financial/Reserves Link On Left Hand Navigation Tree Is Selected
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add Indemnity Reserve Of Amount $800");
		testcall4 = true;
		RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_IndemReserveAmount, RMAApp_ReserveCreation_Lst_IndemStatus, 1, RMAApp_ReserveCreation_Lnk_IndemReserveType, "Yes", StrExpErrMessage, "Hold", "Complete", "Added Expense Reserve Going On Hold Error Message");
		loggerval4 = logger.toString();
		parentlogger.appendChild(logger);
		driver.switchTo().parentFrame();
		//Indemnity Reserve Is Created And Its Going On Hold Is Verified
		
		/*---------------------------Creation Of Indemnity Reserve Of $800 And Its Going On Hold Verification  Is Completed-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------Creation Of Expense Reserve Of $700 And Its Going On Hold Verification Is Started-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add Expense Reserve Of Amount $700");
		testcall5 = true;
		RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_Exp_01_ReserveAmount, RMAApp_ReserveCreation_Lst_Exp_01_Status, 1, RMAApp_ReserveCreation_Lnk_Exp_01_ReserveType, "Yes", StrExpErrMessage, "Hold", "Complete", "Added Expense Reserve Going On Hold Error Message");
		loggerval5 = logger.toString();
		parentlogger.appendChild(logger);
		driver.switchTo().parentFrame();
		//Expense Reserve Is Created And Its Going On Hold Is Verified
		
		/*---------------------------Creation Of Expense Reserve Of $700 And Its Going On Hold Verification Is Completed------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------User With Name Containing CSC Is Logged Out And User With Name Containing A2 Is Logged In  ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*-------------------------- User With Name Containing CSC Is Successfully Out And User With Name Containing A2 Is Successfully Logged In The Application  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A2 In Its Name Is Started -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");
		
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082_01, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
		Strlogstatement  = "Expense Reserve Of Amount $700 With Claim Number" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non Existence Of Expense Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "Of Amount $700 In Funds Reserve Approval Table For A2 User Verification", StrScreenShotTCName)));
		//Expense Reserve Of Amount $700 Does Not Exists In The Funds-->Reserve Approval List For User Containing A2 In Its Name Is Verified 
		
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A2 In Its Name Is Completed -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Indemnity Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A2 In Its Name Started --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082_01, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Indemnity", 0);
		Strlogstatement  = "Indemnity Reserve Of Amount $800 With Claim Number" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non-Existence Of Indemnity Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "Of Amount $800 In Funds Reserve Approval Table For A2 User Verification", StrScreenShotTCName)));
		//Indemnity Reserve Of Amount $800 Does Not Exists In The Funds-->Reserve Approval List For User Containing A2 In Its Name Is Verified 
		
		/*-------------------------- Verification That Indemnity Reserve Created By User Containing CSC In Its Name Is Not Displayed To User Containing A2 In Its Name Completed ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------User With Name Containing A2 Is Logged Out And User With Name Containing A1 Is Logged In  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite4.StrUsera1_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*-------------------------- User With Name Containing A1 Is Successfully Logged In And User With Name Containing A2 Is Logged Out ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Indemnity Reserve Created By User Containing CSC In Its Name Is Displayed To User Containing A1 And Can Be Approved Is Started -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");
		
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082_01, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Indemnity", 0);
		Strlogstatement  = "Indemnity Reserve Of Amount $800 With Claim Number" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Indemnity Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "Of Amount $800 In Funds Reserve Approval Table For A1 User Verification", StrScreenShotTCName)));
		//Indemnity Reserve Of Amount $800 Exists Is Verified As Only Existing Record Can Be Processed Further
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 1, "input"), "check", "Header CheckBox", "In Funds-->Reserve Approval Table", 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "Approve Selected Button In Funds-->Reserve Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Is Approved");
		//Indemnity Reserve Is Approved
		
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Home.RMAApp_DefaultView_Err_StaticErrorText_01(driver), "RMA Application Error Message",0);
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Home.RMAApp_Err_GenericErrMsg1(driver), "Reserve On Hold Requires SuperVisory Approval Error Message",0);
		StrActualErrorMessage = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_Home.RMAApp_Err_GenericErrMsg1(driver), "innerHTML");
		RMA_Verification_Utility.RMA_PartialTextVerification(StrErrorMessageExpected, StrActualErrorMessage, "Correct Partial Error Message Display",0);
		RMA_Verification_Utility.RMA_PartialTextVerification(StrErrorMessageExpected_01, StrActualErrorMessage, "Correct Partial Error Message Display",0);
		StrErrorMessageExpected = StrClaimNumber_RMA_TC_082_01;
		RMA_Verification_Utility.RMA_PartialTextVerification(StrErrorMessageExpected, StrActualErrorMessage, "Correct Error Message Display",0);
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082_01, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Indemnity", 0);
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non-Existence Of Indemnity Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "Of Amount $800 In Funds Reserve Approval Table After Approval For A1 User Verification", StrScreenShotTCName)));
		//Indemnity Reserve Of Amount $800 Does Not Exists After Approval Is Verified
		
		/*-------------------------- Verification That Indemnity Reserve Created By User Containing CSC In Its Name Is Displayed To User Containing A1 And Can Be Approved Is Completed -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Displayed To User Containing A1 And Can Be Rejected Is Started ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082_01, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
		Strlogstatement  = "Expense Reserve Of Amount $700 With Claim Number" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Expense Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "Of Amount $700 In Funds Reserve Approval Table For A1 User Verification", StrScreenShotTCName)));
		//Expense Reserve Of Amount $700 Exists Is Verified As Only Existing Record Can Be Processed Further
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 1, "input"), "check", "Header CheckBox", "In Funds-->Reserve Approval Table", 0);
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Lst_StatusReason(driver), "Medical Update","Status Reason List Box","Funds-->Reserve Approval Page",0);
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "Reject Selected Button In Funds-->Reserve Approval Table", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Is Rejected");
		//Expense Reserve Is Rejected
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082_01, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Non-Existence Of Expense Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "Of Amount $700 In Funds Reserve Approval Table After Rejection For A1 User Verification", StrScreenShotTCName)));
		//Expense Reserve Of Amount $700 Does Not Exists After Rejection Is Verified 
		
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Displayed To User Containing A1 And Can Be Rejected Is Completed-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*---------------------------User With Name Containing A1 Is Logged Out And User With Name Containing A2 Is Logged In  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0); //Web Page Is Refreshed
		driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		//Application Is Logged Out
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4,0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4,0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
		// Application Is Logged In
		
		LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
		RMA_Verification_Utility.RMA_TextCompare(RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4, LoginUserNameActual, "Correct UserName Display", 0);
		// Correct User Is Logged In Verification Is Done
		
		/*-------------------------- User With Name Containing A2 Is Successfully Logged In The Application  -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Verification That Indemnity Reserve Created By User Containing CSC In Its Name Is Displayed To User Containing A2 Is Started----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");
		
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_082_01, 0);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Indemnity", 0);
		Strlogstatement  = "Indemnity Reserve Of Amount $800 With Claim Number" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "In Funds-->Reserve Approval Table On Approve Reserves Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 2, "span"), Strlogstatement , 0);
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Existence Of Indemnity Reserve For Claim" + " " + StrClaimNumber_RMA_TC_082_01 + " " + "Of Amount $800 In Funds Reserve Approval Table For A2 User Verification", StrScreenShotTCName)));
		//Indemnity Reserve Of Amount $800 Exists Is Verified
		
		RMA_Verification_Utility.RMA_FilterNGGridVerify_Utility(RMA_TC_UserCreationSASuite4.StrUsera2_TC_UserCreationSASuite4, "Pending Transactions Table On Funds-->Reserve Approval Page", RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 6, "span"), 0);
		/*-------------------------- Verification That Expense Reserve Created By User Containing CSC In Its Name Is Displayed To User Containing A2 Is Started-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Revert Of Settings Applied On Payment Parameter Set Up Page Is Started-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		driver.switchTo().parentFrame();
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Payment Parameter Options Is Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",0);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "uncheck", "Incurred Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Reserve Limits Are Exceeded Check Box Is Unchecked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "uncheck", "Notify Immediate Supervisor Check Box For Reserves", "Payment Parameter Setup Page",0); //Notify Immediate SuperVisor Check Box For reserves Is Unchecked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "uncheck", "Supervisory Approval Check Box For Reserves", "Payment Parameter Setup Page",0); //Supervisory Approval CheckBox For Reserves Check Box Is Unchecked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver), "Save Image On Payment Parameter Set Up Page",0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "deselect", "Incurred Limits Are Exceeded Check Box On Payment Parameter Setup Page",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "deselect", "Notify Immediate SuperVisor For Reserves Check Box On Payment Parameter Setup Page ",0);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "deselect", "Use SuperVisory Approval For Reserves Check Box On Payment Parameter Setup Page",0);
		driver.switchTo().parentFrame();
		/*-------------------------- Revert Of Settings Applied On Payment Parameter Set Up Page Is Completed-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/*-------------------------- Removal Of Reserve Limits Applied To User Containing CSC And A1 In Its Name Is Started-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		StrPrimaryWindowHandle = driver.getWindowHandle();
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,5), "Security-->User Privileges SetUp Menu Option", 0);
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
		driver.manage().window().maximize();
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page",0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tab_PerClaimIncLimits(driver), "Per Claim Incurred Limits On User Privileges Setup Page ", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Per Claim Incurred Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginUserFirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		ActualRowCount = RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tbl_UsersGroups(driver), 0, 0, false, false, "Per Claim Incurred Limits Table" , 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Rdb_PerClaimIncurredLimitsGridRadioButton(driver), "RadioButton Corresponding to User"+ " " + StrConLoginUserFirstAndLastName, 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Btn_Remove(driver), "Remove Button For Per Claim Incurred Limit", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Per Claim Incurred Limit Max Amount For User" + StrConLoginUserFirstAndLastName + "Is Removed");
		RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tbl_UsersGroups(driver), 0, ActualRowCount-1, true, false, "Per Claim Incurred Limits Table" , 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limit Removal For User" + " " +StrConLoginUserFirstAndLastName + "Is Verified");
		StrScreenShotName = "Per Claim Incurred Limit Removed Corresponding To User "+" "+StrConLoginUserFirstAndLastName;
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, StrScreenShotName, StrScreenShotTCName)));
		
		RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginMgr1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page",0);
		ActualRowCount = RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tbl_UsersGroups(driver), 0, 0, false, false, "Per Claim Incurred Limits Table" , 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Rdb_PerClaimIncurredLimitsGridRadioButton(driver), "RadioButton Corresponding to User"+ " " + StrConLoginMgr1FirstAndLastName, 0);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Btn_Remove(driver), "Remove Button For Per Claim Incurred Limit", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Per Claim Incurred Limit Max Amount For User" + StrConLoginMgr1FirstAndLastName + "Is Removed");
		RMA_Verification_Utility.RMA_RowColCountVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Tbl_UsersGroups(driver), 0, ActualRowCount-1, true, false, "Per Claim Incurred Limits Table" , 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limit Removal For User" + " " +StrConLoginMgr1FirstAndLastName + "Is Verified");
		StrScreenShotName = "Per Claim Incurred Limit Removed Corresponding To User "+" "+StrConLoginMgr1FirstAndLastName;
		parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, StrScreenShotName, StrScreenShotTCName)));
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "uncheck", "Enable Per Claim Incurred Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Per Claim Incurred Limits Tab",0);
		//Enable Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Incurred Limit Tab Is UnChecked
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Per Claim Incurred Limits CheckBox On RMA Application User Privilege SetUp Page's Per Claim Incurred Limits Tab Is UnChecked");
		RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPerClmIncLmts_Chk_EnbPerClmIncurredLmts(driver), "deselect", "Enable Per Claim Incurred Limits CheckBox On Per Claim Incurred Limits Tab",0);
		
		/*-------------------------- Removal Of Reserve Limits Applied To User Containing CSC And A1 In Its Name Is Completed-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		driver.close();
		driver.switchTo().window(StrPrimaryWindowHandle);
		
	} catch (Exception|Error e) {
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		
		
		if ((testcall1 == true) && (loggerval1.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Executing Test Case" +" "+ "RMA_TC_004: General Claim Creation" + " " +  "And Hence The Test Case Is A Fail");
		parentlogger.appendChild(logger);
		}
		else if ((testcall3 == true) && (loggerval3.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Executing Test Case" +" "+ "RMA_TC_004: General Claim Creation" + " " +  "And Hence The Test Case Is A Fail");
		parentlogger.appendChild(logger);
		}
		
		else if ((testcall2 == true) && (loggerval2.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Expense reserve Of $700"  + " " +  "And Hence Reserve Creation Was Not Successful");
		parentlogger.appendChild(logger);
		}
		else if ((testcall4 == true) && (loggerval4.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Indemnity Reserve Of $800"  + " " +  "And Hence Reserve Creation Was Not Successful");
		parentlogger.appendChild(logger);
		}
		
		else if ((testcall5 == true) && (loggerval5.equalsIgnoreCase("NotInitialized")))
		{
		logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Expense Reserve Of $700" +" "+ "And Hence Reserve Creation Was Not Successful");
		parentlogger.appendChild(logger);
		
		}
		
		throw (e);
	}	
	}


@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,0);
		}
		reports.endTest(parentlogger);
		
	} catch (Exception |Error e) {
		throw (e);
	}
}
}

