package rmaseleniumtestscripts;

import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Funds_ApproveTransactions;
import rmaseleniumPOM.RMA_Selenium_POM_Funds_ResApprove;
import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_Login_DSNSelect_Frames;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentParameterSetUp;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentsCollections;
import rmaseleniumPOM.RMA_Selenium_POM_UserPrivilegesSetUp;
import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_Functionality_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_NegativeVerification_Utility;
import rmaseleniumutilties.RMA_ScreenCapture_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_078
//Description    : TC_078_Verify the functionalities available over Supervisory approval screen
//Depends On TC  : TC_UserCreationSASuite3
//Revision       : 0.0 - ImteyazAhmad-03-10-2016 
//=================================================================================================
//Note: Here: LoginUser Stands For User Containing CSC In Its Name, LoginMgr1 Stands For User Having A1 In Its Name And LoginMgr2 Stands For User Having A2 In Its Name, Users Are Arranged In Hierarchy CSC-->A1-->A2
public class RMA_TC_078 extends rmaseleniumtestscripts.RMA_TC_BaseTest {
	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;
	static String StrScreenShotTCName;


	@Test 
	public void RMA_TC_078_Test () throws Exception, Error

	{
		try {
			parentlogger = reports.startTest("TC_078_Functionalities Avaialable On Supervisory Approval Screen", "Verify The Functionalities Availble Over Supervisory Approval Screen");
			parentlogger.assignAuthor("Imteyaz Ahmad");
			int RMAApp_UserPrev_Txt_Usercsc_MaxResAmt, RMAApp_UserPrev_Txt_Usercsc_MaxPaymentAmt, RMAApp_UserPrev_Txt_Userq1_MaxResAmt, RMAApp_UserPrev_Txt_Userq1_MaxPaymentAmt;
			int RMAApp_UserPrev_Txt_Userb1_MaxResAmt, RMAApp_UserPrev_Txt_Userb1_MaxPaymentAmt, RMAApp_ReserveCreation_Txt_ExpReserveAmount;
			int RMAApp_FundsSplitDetails_Txt_Amount, RMAApp_FundsSplitDetails_Txt_Amount_1, RMAApp_FundsSplitDetails_Txt_Amount_2, RMAApp_ReserveCreation_Txt_ExpReserveAmount_1, RMAApp_ReserveCreation_Txt_ExpReserveAmount_2;
			String RMAApp_UserPrev_Lst_LOB, RMAApp_UserPrev_Lst_ReserveType, LoginUserNameActual, RMAApp_Login_Txt_UserName, RMAApp_Login_Txt_Password;
			String StrAccept, StrCheckStatusExpected,StrConLoginUserFirstAndLastName, StrUserq1, StrUserb1, StrConUserq1FirstAndLastName, StrConUserb1FirstAndLastName;
			String StrPrimaryWindowHandle, StrClaimNumber_RMA_TC_078_01,StrClaimNumber_RMA_TC_078_02, StrClaimNumber_RMA_TC_078_03, RMAApp_ReserveCreation_Lst_ExpStatus, RMAApp_ReserveCreation_Lnk_ExpReserveType, StrExpExceededReserveMsg;
			String StrControlNumber_RMA_TC_078_01, StrControlNumber_RMA_TC_078_02, StrControlNumber_RMA_TC_078_03, RMAApp_FundsSplitDetails_Lst_TransactionType, RMAApp_Payment_Lst_BankAccount;
			String RMAApp_Payment_Lst_PayeeType, RMAApp_Payment_Txt_LastName, RMAApp_Payment_Txt_DistributionType, StrActualCheckStatus, StrActualErrorMessage, StrErrorMessageExpected1;
			String StrUsera1, StrUserq2, ObjDescription;
			WebElement filtertext, filtertext1, filtertext2;
			//Local Variable Declaration Completed

			RMAApp_Login_Txt_UserName = RMA_TC_UserCreationSASuite3.StrUsercsc_TC_UserCreationSASuite3;
			RMAApp_Login_Txt_Password = RMA_TC_UserCreationSASuite3.StrUsercsc_TC_UserCreationSASuite3;// User Name And Password Are Same 
			StrUserq1 = RMA_TC_UserCreationSASuite3.StrUserq1_TC_UserCreationSASuite3; 
			StrUserb1 = RMA_TC_UserCreationSASuite3.StrUserb1_TC_UserCreationSASuite3;
			StrUsera1 = RMA_TC_UserCreationSASuite3.StrUsera1_TC_UserCreationSASuite3;
			StrUserq2 = RMA_TC_UserCreationSASuite3.StrUserq2_TC_UserCreationSASuite3;
			StrAccept = "Yes";
			StrCheckStatusExpected = "H Hold";
			StrConLoginUserFirstAndLastName = RMAApp_Login_Txt_UserName+", "+RMAApp_Login_Txt_UserName;
			StrConUserq1FirstAndLastName = StrUserq1+", "+StrUserq1;
			StrConUserb1FirstAndLastName = StrUserb1+", "+StrUserb1;
			StrErrorMessageExpected1 = "A hold requiring supervisory approval has been placed on this payment because Exceeded Payment Limit and requires managerial approval";
			StrExpExceededReserveMsg = "This reserve has been sent for the Supervisor approval and is in the Hold status as Exceeded Reserve Limit";
			testcall1 = false;
			testcall2 = false;
			testcall3 = false;
			testcall4 = false;
			testcall5 = false;
			testcall6 = false;
			testcall7 = false;
			testcall8 = false;
			testcall9 = false;
			loggerval1 = "NotInitialized";
			loggerval2 = "NotInitialized";
			loggerval3 = "NotInitialized";
			loggerval4 = "NotInitialized";
			loggerval5 = "NotInitialized";
			loggerval6 = "NotInitialized";
			loggerval7 = "NotInitialized";
			loggerval8 = "NotInitialized";
			loggerval9 = "NotInitialized";
			StrScreenShotTCName = "TC_078";			

			RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMA_Suite_03_SprVsrApprovalTestData.xlsx"); //Excel WorkBook RMA_Suite_03_SprVsrApprovalTestData Is Fetched To Retrieve Data
			RMAApp_UserPrev_Lst_LOB = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 0); // LOB Type Is Fetched From DataSheet RMA_TC_076
			RMAApp_UserPrev_Lst_ReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 1); //Reserve Type Is Fetched From DataSheet RMA_TC_076
			RMAApp_UserPrev_Txt_Usercsc_MaxResAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 2); //Reserve Amount For LoginUser Is Fetched From DataSheet RMA_TC_076
			RMAApp_UserPrev_Txt_Usercsc_MaxPaymentAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 3); //Reserve Amount For LoginUser Is Fetched From DataSheet RMA_TC_076
			RMAApp_UserPrev_Txt_Userq1_MaxResAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 4); //Reserve Amount For LoginUser Is Fetched From DataSheet RMA_TC_076
			RMAApp_UserPrev_Txt_Userq1_MaxPaymentAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 5); //Reserve Amount For LoginUser Is Fetched From DataSheet RMA_TC_076
			RMAApp_UserPrev_Txt_Userb1_MaxResAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 6); //Reserve Amount For LoginUser Is Fetched From DataSheet RMA_TC_076
			RMAApp_UserPrev_Txt_Userb1_MaxPaymentAmt = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 7); //Reserve Amount For LoginUser Is Fetched From DataSheet RMA_TC_076
			RMAApp_ReserveCreation_Txt_ExpReserveAmount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 8); //Reserve Amount Is Fetched From DataSheet RMA_TC_076
			RMAApp_ReserveCreation_Lst_ExpStatus = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 9); //Reserve Status Is Fetched From DataSheet RMA_TC_076
			RMAApp_ReserveCreation_Lnk_ExpReserveType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 10); //Reserve Type Is Fetched From DataSheet RMA_TC_076
			RMAApp_Payment_Lst_BankAccount = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 11); //Bank Account Is Fetched From DataSheet RMA_TC_076
			RMAApp_Payment_Lst_PayeeType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 12); // Payee Type Is Fetched From DataSheet RMA_TC_076
			RMAApp_FundsSplitDetails_Lst_TransactionType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 13); //Transaction Type Is Fetched From DataSheet RMA_TC_076
			RMAApp_FundsSplitDetails_Txt_Amount = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 14); //Amount Is Fetched From DataSheet RMA_TC_076
			RMAApp_Payment_Txt_LastName = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 15); //LastName Is Fetched From DataSheet RMA_TC_076
			RMAApp_Payment_Txt_DistributionType = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_078", 1, 16); //Distribution Type Is Fetched From DataSheet RMA_TC_076
			RMAApp_ReserveCreation_Txt_ExpReserveAmount_1 = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 17); // Expense Reserve Amount Is Fetched From DataSheet RMA_TC_078
			RMAApp_FundsSplitDetails_Txt_Amount_1 = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 18); //Fund Split Amount Is Fetched From DataSheet RMA_TC_078
			RMAApp_ReserveCreation_Txt_ExpReserveAmount_2 = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 19); // Expense Reserve Amount Is Fetched From DataSheet RMA_TC_078
			RMAApp_FundsSplitDetails_Txt_Amount_2 = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_078", 1, 20); //Fund Split Amount Is Fetched From DataSheet RMA_TC_078


			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);
			driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			//Application Is Logged Out

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", RMAApp_Login_Txt_UserName,0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", RMAApp_Login_Txt_Password,0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
			// Application Is Logged In

			LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
			RMA_Verification_Utility.RMA_TextCompare(RMAApp_Login_Txt_UserName, LoginUserNameActual, "UserName", 0);
			// Correct User Is Logged In Verification Is Done

			//******************************************Following Code Is To Enable Required Settings On Payment Parameter SetUp Page *****************************************************

			driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
			driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Event Creation Controls IS Done
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "check", "Payment Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayDetailLimitExceed(driver), "uncheck", "Payment Detail Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Detail Limits Are Exceeded Check Box Is UnChecked on Payment Parameter Setup Page		
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "check", "Supervisory Approval Check Box", "Payment Parameter Setup Page",0);      // Supervisory Approval CheckBox Is Checked On Payment Parameter Set Up Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "check", "Notify Immediate Supervisor Check Box", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "check", "Reserve Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Reserve Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "check", "Notify Immediate Supervisor Check Box For Reserves", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box For reserves Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "check", "Supervisory Approval Check Box For Reserves", "Payment Parameter Setup",0); //Supervisory Approval CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "uncheck", "Incurred Limits Are Exceeded Check Box For Reserves", "Payment Parameter Setup",0); //Incurred Limits Are Exceeded CheckBox For Reserves Check Box Is UnChecked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApprove(driver), "check", "Allow The Group Of Supervisor To Approve  Check Box For Payment ", "Payment Parameter Setup",0); //Allow The Group Of Supervisor To Approve CheckBox For Payemnt For Reserves Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApproveReserve(driver), "check", "Allow The Group Of Supervisor To Approve Check Box For Reserve", "Payment Parameter Setup",0); //Incurred Limits Are Exceeded CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page

			RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver).click(); //Save image is clicked		
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");

			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "select", "Payment Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayDetailLimitExceed(driver), "deselect", "Payment Detail Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "select", "Notify Immediate Supervisor Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "select", "Supervisory Approval Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "select", "Notify Immediate SuperVisor For Reserves Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "select", "Use SuperVisory Approval For Reserves Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "select", "Reserve Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "deselect", "Incurred Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApprove(driver), "select", "Allow The Group Of Supervisor To Approve CheckBox For Payment",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApproveReserve(driver), "select", "Allow The Group Of Supervisor To Approve Check Box For Reserve",0);
			//**************************Payment Parameter Setup Setiing Is Completed Here **********************************************************************************************

			//******************************Below Code Is To Provide All Required Settings On User Privilege Setup Page **********************************************************************/
			StrPrimaryWindowHandle = driver.getWindowHandle();
			driver.switchTo().parentFrame();
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", 0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,5), "Security-->User Privileges SetUp Menu Option", 0);
			RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
			driver.manage().window().maximize();		
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page",0);
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Reserve Limits", "User Privilege Page", 0);		
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConLoginUserFirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Lst_ReserveType(driver), RMAApp_UserPrev_Lst_ReserveType,"Reserve Type List Box","RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab",0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Txt_MaxAmount(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_Usercsc_MaxResAmt),0);	
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's ReserveLimits Tab",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Limit Max Amount For" + " " + StrConLoginUserFirstAndLastName+ " " + "Is Added");
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConLoginUserFirstAndLastName, 3, RMAApp_UserPrev_Lst_ReserveType, "Reserve Limits Grid Table",0);
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConLoginUserFirstAndLastName, 5, String.valueOf(RMAApp_UserPrev_Txt_Usercsc_MaxResAmt), "Reserve Limits Grid Table",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Reserve Limit Verification For Usercsc ", StrScreenShotTCName)));
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "check", "Enable Reserve Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Reserve Limits Tab",0);
			//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Checked
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Reserve Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Checked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_RestUnspcfdUsers(driver), "uncheck", "Restrict Unspecified Users CheckBox",  "RMA Application's User Privileges SetUp Page's Reserve Limits Tab",0);
			//Restrict Unspecified User CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab is Unchecked
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Unchecked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "select", "Enable Reserve Limits CheckBox",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_RestUnspcfdUsers(driver), "deselect", "Restrict Unspecified Users CheckBox",0);
			// Reserve Limit Of $100 Is Added To Usercsc User Above

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab On RMA Application's User-Privileges SetUp Page",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_Usercsc_MaxPaymentAmt),0);	
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Payment Limit Max Amount For" +" "+ StrConLoginUserFirstAndLastName+" " +" Is Added");
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), StrConLoginUserFirstAndLastName, 3, String.valueOf(RMAApp_UserPrev_Txt_Usercsc_MaxPaymentAmt), "Payment Limits Grid Table",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For Usercsc ", StrScreenShotTCName)));
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "check", "Enable Payment Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",0);
			//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "uncheck", "Restrict Unspecified Users CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",0);
			//Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is UnChecked
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Restrict Unspecified Users CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is UnChecked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "select", "Enable Payment Limits CheckBox",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "deselect", "Restrict Unspecified Users CheckBox",0);
			//Payment Limit Of $20 Is Added To Usercsc


			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Reserve Limits", "User Privilege Page", 0);
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConUserq1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Lst_ReserveType(driver), RMAApp_UserPrev_Lst_ReserveType,"Reserve Type List Box","RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab",0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Txt_MaxAmount(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_Userq1_MaxResAmt),0);	
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's ReserveLimits Tab",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Limit Max Amount For" + " " + StrConUserq1FirstAndLastName+ " " + "Is Added");
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConUserq1FirstAndLastName, 3, RMAApp_UserPrev_Lst_ReserveType, "Reserve Limits Grid Table",0);
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConUserq1FirstAndLastName, 5, String.valueOf(RMAApp_UserPrev_Txt_Userq1_MaxResAmt), "Reserve Limits Grid Table",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Reserve Limit Verification For Userq1 ", StrScreenShotTCName)));
			// Reserve Limit Of $150 Is Added To Userq1 User Above

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab On RMA Application's User-Privileges SetUp Page",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_Userq1_MaxPaymentAmt),0);	
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Payment Limit Max Amount For" +" "+ StrConUserq1FirstAndLastName+" " +" Is Added");
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), StrConUserq1FirstAndLastName, 3, String.valueOf(RMAApp_UserPrev_Txt_Userq1_MaxPaymentAmt), "Payment Limits Grid Table",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For Userq1 ", StrScreenShotTCName)));
			//Payment Limit Of $30 Is Added To Userq1


			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Reserve Limits", "User Privilege Page", 0);
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_UserGroup(driver), StrConUserb1FirstAndLastName,"User/Group List Box","RISKMASTER User-Privileges SetUp Page's Payment Limits Tab",0);
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Lst_ReserveType(driver), RMAApp_UserPrev_Lst_ReserveType,"Reserve Type List Box","RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab",0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Txt_MaxAmount(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Reserve Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_Userb1_MaxResAmt),0);	
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's ReserveLimits Tab",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Reserve Limit Max Amount For" + " " + StrConUserb1FirstAndLastName+ " " + "Is Added");
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConUserb1FirstAndLastName, 3, RMAApp_UserPrev_Lst_ReserveType, "Reserve Limits Grid Table",0);
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Tbl_ReserveLimitsGrid(driver), StrConUserb1FirstAndLastName, 5, String.valueOf(RMAApp_UserPrev_Txt_Userb1_MaxResAmt), "Reserve Limits Grid Table",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Reserve Limit Verification For Userb1 ", StrScreenShotTCName)));
			// Reserve Limit Of $200 Is Added To Userb1 User Above

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab On RMA Application's User-Privileges SetUp Page",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Txt_MaxAmt(driver), "Max Amount TextBox On RISKMASTER User-Privileges SetUp Page's Payment Limits Tab", String.valueOf(RMAApp_UserPrev_Txt_Userb1_MaxPaymentAmt),0);	
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Btn_Add(driver), "Add Button On RMA Application's User-Privileges SetUp Page's Payment Limits Tab",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Payment Limit Max Amount For" +" "+ StrConUserb1FirstAndLastName+" " +" Is Added");
			RMA_Verification_Utility.RMA_TableSingleTextVerify_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tbl_PaymentLimitsGrid(driver), StrConUserb1FirstAndLastName, 3, String.valueOf(RMAApp_UserPrev_Txt_Userb1_MaxPaymentAmt), "Payment Limits Grid Table",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Verification For Userb1 ", StrScreenShotTCName)));
			//Payment Limit Of $50 Is Added To Userb1

			driver.close();
			driver.switchTo().window(StrPrimaryWindowHandle);
			// ***************************User Privileges Setup Settings Are Completed Here ******************************************************************************************************

			//***********************************Following Code Is To Create A General Claim**********************************************************************
			parentlogger.log(LogStatus.INFO, "Following Test Is Called :: RMA_TC_004 To Create New Claim");
			testcall1 = true;
			RMA_TC_004 generalclaim = new RMA_TC_004();
			StrClaimNumber_RMA_TC_078_01 = generalclaim.GeneralClaimCreation(); //Claim Number Is Fetched And Stored In Variable StrClaimNumber_RMA_TC_078_01
			parentlogger.log(LogStatus.INFO, "New Claim Is Created With Claim Number::"+ " " + color.RMA_ChangeColor_Utility(StrClaimNumber_RMA_TC_078_01, 2));
			loggerval1 = logger.toString();
			parentlogger.appendChild(logger);
			//***************************************** New Claim Creation Is Completed Here ********************************************************************

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Img_GCExpander(driver), "Created General Claim Expander On Left Hand Navigation Tree",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Left Hand Navigation Tree Is Expanded");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Lnk_FinancialReserves(driver), "Financial/Reserves Link On Left Hand Navigation Tree",0); //Created General Claim's Financial/Reserves Option Is Selected //Created General Claim's Financial/Reserves Option Is Selected
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Financial/Reserves Link On Left Hand Navigation Tree Is Selected");
			//Left Hand Navigation Tree Is Expanded And Financial/Reserves Link On Left Hand Navigation Tree Is Selected

			//************************************** Following Code Is To Create Expense Reserves********************************************************************************************************

			parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add An Expense Reserve Of $111");
			testcall2 = true;
			RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_ExpReserveAmount, RMAApp_ReserveCreation_Lst_ExpStatus, 1, RMAApp_ReserveCreation_Lnk_ExpReserveType, "Yes", StrExpExceededReserveMsg, "Hold", "Partially", "Added Expense Reserve Going On Hold Warning Message");
			loggerval2 = logger.toString();
			parentlogger.appendChild(logger);
			//Expense Reserve Is Created And Its Going On Hold Is Verified

			//**************************** Code To Create Expense Reserves Is Completed Here***************************************************************************************************************


			//*********************************Following Piece Of Code Is To Create Payment Of $25 And Hold Message Verification ************************************************************************************
			parentlogger.log(LogStatus.INFO, "Following Function Is Called To Create A Payment Of $25 :: RMA_PaymentAddition_Utility");		
			testcall3 = true;
			StrControlNumber_RMA_TC_078_01 = RMA_Functionality_Utility.RMA_PaymentAddition_Utility(RMAApp_Payment_Lst_BankAccount, RMAApp_Payment_Lst_PayeeType, RMAApp_FundsSplitDetails_Lst_TransactionType, RMAApp_FundsSplitDetails_Txt_Amount, RMAApp_Payment_Txt_LastName,RMAApp_Payment_Txt_DistributionType,1);
			parentlogger.log(LogStatus.INFO, "New Payment Is Created With Control Number::"+ " " + color.RMA_ChangeColor_Utility(StrControlNumber_RMA_TC_078_01, 2));
			loggerval3 = logger.toString();
			parentlogger.appendChild(logger);
			//New Payment Of $25 Is Done

			StrActualCheckStatus = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Txt_CheckStatus(driver), "value");
			RMA_Verification_Utility.RMA_TextCompare(StrCheckStatusExpected, StrActualCheckStatus, "Correct Check Status",0);
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Home.RMAApp_DefaultView_Err_StaticErrorText(driver), "RMA Application Error Message",0);
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "Payment On Hold Requires SuperVisory Approval Error Message",0);
			StrActualErrorMessage = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "innerHTML");
			RMA_Verification_Utility.RMA_PartialTextVerification(StrErrorMessageExpected1, StrActualErrorMessage, "Correct Error Message Display",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Exceeded Verification", StrScreenShotTCName)));
			//One Warning Message - Payment Limit Exceeded - Is Verified

			//*****************Payment Creation Of $25 And Hold Message Verification Are Completed Here********************************************************************

			//********************************Usercsc Is Logged out and Userq1 is Logged In Into Application****************************************************
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);
			driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			//Application Is Logged Out

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", StrUserq1,0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", StrUserq1,0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
			// Application Is Logged In

			LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
			RMA_Verification_Utility.RMA_TextCompare(StrUserq1, LoginUserNameActual, "UserName", 0);
			// Correct User- Userq1- Is Logged In Verification Is Done
			//*****************************************************************************************************************************************************

			//***********************************Following Code Is To Create A General Claim**********************************************************************
			parentlogger.log(LogStatus.INFO, "Following Test Is Called :: RMA_TC_004 To Create New Claim");
			testcall4 = true;
			StrClaimNumber_RMA_TC_078_02 = generalclaim.GeneralClaimCreation(); //Claim Number Is Fetched And Stored In Variable StrClaimNumber_RMA_TC_078_02
			parentlogger.log(LogStatus.INFO, "New Claim Is Created With Claim Number::"+ " " + color.RMA_ChangeColor_Utility(StrClaimNumber_RMA_TC_078_02, 2));
			loggerval4 = logger.toString();
			parentlogger.appendChild(logger);
			//***************************************** New Claim Creation Is Completed Here ********************************************************************

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Img_GCExpander(driver), "Created General Claim Expander On Left Hand Navigation Tree",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Left Hand Navigation Tree Is Expanded");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Lnk_FinancialReserves(driver), "Financial/Reserves Link On Left Hand Navigation Tree",0); //Created General Claim's Financial/Reserves Option Is Selected //Created General Claim's Financial/Reserves Option Is Selected
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Financial/Reserves Link On Left Hand Navigation Tree Is Selected");
			//Left Hand Navigation Tree Is Expanded And Financial/Reserves Link On Left Hand Navigation Tree Is Selected

			//************************************** Following Code Is To Create Expense Reserves Of $170********************************************************************************************************

			parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add An Expense Reserve Of $170");
			testcall5 = true;
			RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1, RMAApp_ReserveCreation_Lst_ExpStatus, 1, RMAApp_ReserveCreation_Lnk_ExpReserveType, "Yes", StrExpExceededReserveMsg, "Hold", "Partially", "Added Expense Reserve Going On Hold Warning Message");
			loggerval5 = logger.toString();
			parentlogger.appendChild(logger);
			//Expense Reserve Is Created And Its Going On Hold Is Verified

			//**************************** Code To Create Expense Reserves Is Completed Here***************************************************************************************************************


			//*********************************Following Piece Of Code Is To Create Payment Of $35 And Hold Message Verification ************************************************************************************
			parentlogger.log(LogStatus.INFO, "Following Function Is Called To Create A Payment Of $35 :: RMA_PaymentAddition_Utility");		
			testcall6 = true;
			StrControlNumber_RMA_TC_078_02 = RMA_Functionality_Utility.RMA_PaymentAddition_Utility(RMAApp_Payment_Lst_BankAccount, RMAApp_Payment_Lst_PayeeType, RMAApp_FundsSplitDetails_Lst_TransactionType, RMAApp_FundsSplitDetails_Txt_Amount_1, RMAApp_Payment_Txt_LastName,RMAApp_Payment_Txt_DistributionType,1);
			parentlogger.log(LogStatus.INFO, "New Payment Is Created With Control Number::"+ " " + color.RMA_ChangeColor_Utility(StrControlNumber_RMA_TC_078_02, 2));
			loggerval6 = logger.toString();
			parentlogger.appendChild(logger);
			//New Payment Of $35 Is Done

			StrActualCheckStatus = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Txt_CheckStatus(driver), "value");
			RMA_Verification_Utility.RMA_TextCompare(StrCheckStatusExpected, StrActualCheckStatus, "Correct Check Status",0);
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Home.RMAApp_DefaultView_Err_StaticErrorText(driver), "RMA Application Error Message",0);
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "Payment On Hold Requires SuperVisory Approval Error Message",0);
			StrActualErrorMessage = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "innerHTML");
			RMA_Verification_Utility.RMA_PartialTextVerification(StrErrorMessageExpected1, StrActualErrorMessage, "Correct Error Message Display",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Exceeded Verification", StrScreenShotTCName)));
			//One Warning Message - Payment Limit Exceeded - Is Verified

			//*****************Payment Creation Of $35 And Hold Message Verification Are Completed Here********************************************************************

			//********************************Userq1 Is Logged out and Userb1 is Logged In Into Application****************************************************
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);
			driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			//Application Is Logged Out

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", StrUserb1,0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", StrUserb1,0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
			// Application Is Logged In

			LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
			RMA_Verification_Utility.RMA_TextCompare(StrUserb1, LoginUserNameActual, "UserName", 0);
			// Correct User- Userb1- Is Logged In Verification Is Done
			//*****************************************************************************************************************************************************


			//***********************************Following Code Is To Create A General Claim**********************************************************************
			parentlogger.log(LogStatus.INFO, "Following Test Is Called :: RMA_TC_004 To Create New Claim");
			testcall7 = true;
			StrClaimNumber_RMA_TC_078_03 = generalclaim.GeneralClaimCreation(); //Claim Number Is Fetched And Stored In Variable StrClaimNumber_RMA_TC_078_02
			parentlogger.log(LogStatus.INFO, "New Claim Is Created With Claim Number::"+ " " + color.RMA_ChangeColor_Utility(StrClaimNumber_RMA_TC_078_03, 2));
			loggerval7 = logger.toString();
			parentlogger.appendChild(logger);
			//***************************************** New Claim Creation Is Completed Here ********************************************************************

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Img_GCExpander(driver), "Created General Claim Expander On Left Hand Navigation Tree",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Left Hand Navigation Tree Is Expanded");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_LeftHandNavTree_Lnk_FinancialReserves(driver), "Financial/Reserves Link On Left Hand Navigation Tree",0); //Created General Claim's Financial/Reserves Option Is Selected //Created General Claim's Financial/Reserves Option Is Selected
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Financial/Reserves Link On Left Hand Navigation Tree Is Selected");
			//Left Hand Navigation Tree Is Expanded And Financial/Reserves Link On Left Hand Navigation Tree Is Selected

			//************************************** Following Code Is To Create Expense Reserves Of $250********************************************************************************************************

			parentlogger.log(LogStatus.INFO, "Following Function Is Called :: RMA_ReserveAddition_Utility To Add An Expense Reserve Of $250");
			testcall8 = true;
			RMA_Functionality_Utility.RMA_ReserveAddition_Utility(RMAApp_ReserveCreation_Txt_ExpReserveAmount_2, RMAApp_ReserveCreation_Lst_ExpStatus, 1, RMAApp_ReserveCreation_Lnk_ExpReserveType, "Yes", StrExpExceededReserveMsg, "Hold", "Partially", "Added Expense Reserve Going On Hold Warning Message");
			loggerval8 = logger.toString();
			parentlogger.appendChild(logger);
			//Expense Reserve Is Created And Its Going On Hold Is Verified

			//**************************** Code To Create Expense Reserves Is Completed Here***************************************************************************************************************


			//*********************************Follwing Piece Of Code Is To Create Payment Of $55 And Hold Message Verification ************************************************************************************
			parentlogger.log(LogStatus.INFO, "Following Function Is Called To Create A Payment Of $55 :: RMA_PaymentAddition_Utility");		
			testcall9 = true;
			StrControlNumber_RMA_TC_078_03 = RMA_Functionality_Utility.RMA_PaymentAddition_Utility(RMAApp_Payment_Lst_BankAccount, RMAApp_Payment_Lst_PayeeType, RMAApp_FundsSplitDetails_Lst_TransactionType, RMAApp_FundsSplitDetails_Txt_Amount_2, RMAApp_Payment_Txt_LastName,RMAApp_Payment_Txt_DistributionType,1);
			parentlogger.log(LogStatus.INFO, "New Payment Is Created With Control Number::"+ " " + color.RMA_ChangeColor_Utility(StrControlNumber_RMA_TC_078_03, 2));
			loggerval9 = logger.toString();
			parentlogger.appendChild(logger);
			//New Payment Of $55 Is Done

			StrActualCheckStatus = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Txt_CheckStatus(driver), "value");
			RMA_Verification_Utility.RMA_TextCompare(StrCheckStatusExpected, StrActualCheckStatus, "Correct Check Status",0);
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Home.RMAApp_DefaultView_Err_StaticErrorText(driver), "RMA Application Error Message",0);
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "Payment On Hold Requires SuperVisory Approval Error Message",0);
			StrActualErrorMessage = RMA_Verification_Utility.RMA_AttributeFetch_Utility(RMA_Selenium_POM_PaymentsCollections.RMAApp_Payment_Err_SprApprovalHoldText(driver), "innerHTML");
			RMA_Verification_Utility.RMA_PartialTextVerification(StrErrorMessageExpected1, StrActualErrorMessage, "Correct Error Message Display",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Payment Limit Exceeded Verification", StrScreenShotTCName)));
			//One Warning Message - Payment Limit Exceeded - Is Verified

			//*****************Payment Creation Of $55 And Hold Message Verification Are Completed Here********************************************************************

			//********************************Userb1 Is Logged out and Usera1 is Logged In Into Application****************************************************
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);
			driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			//Application Is Logged Out

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", StrUsera1,0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", StrUsera1,0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
			// Application Is Logged In

			LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
			RMA_Verification_Utility.RMA_TextCompare(StrUsera1, LoginUserNameActual, "UserName", 0);
			// Correct User- Usera1- Is Logged In Verification Is Done
			//*****************************************************************************************************************************************************

			//********************************************Reserve Approval For Expense Reserves Created By User Usercsc, Userq1 And Userb1, Is Verified Below By Logged In Usera1 ***********************************
			driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");

			driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_01, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_01+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 111 Verification", StrScreenShotTCName)));
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "enable", "Approve Selected Button On Reserve Approval Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "enable", "Reject Selected Button On Reserve Approval Page", 0);


			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_02, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_02+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 170 Not Visisble Verification", StrScreenShotTCName)));

			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Chk_ShowAllTransactionWithinMyAuthority(driver), "check", "Show All Transaction Within My Authority", "Reserve Approval Page", 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Records In Reserve NgGrid Is Reloaded");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_01, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_01+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 111 Visible Verification", StrScreenShotTCName)));
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "enable", "Approve Selected Button On Reserve Approval Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "enable", "Reject Selected Button On Reserve Approval Page", 0);

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_02, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_02+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 170 Visible Verification", StrScreenShotTCName)));
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "enable", "Approve Selected Button On Reserve Approval Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "enable", "Reject Selected Button On Reserve Approval Page", 0);

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_03, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_2), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_2)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_03+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 250 Not Visisble Verification", StrScreenShotTCName)));
			//********************************* Reserve Approval Verification Is Completed Here ********************************************

			//******************Following Code Is To Verify Hold Transactions By Logged In User Usera1***************************************

			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);		
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,2), "Funds-->Approve Transactions Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Approve Transactions Page Is Loaded");
			driver.switchTo().frame(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Frm_ApproveTransact(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Funds-->Approve Transactions Frame Is Done");
			//A Switch To The Frame Containing Funds-->Approve Transactions Page Is Done

			filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_01,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_01 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Verification "+" "+StrControlNumber_RMA_TC_078_01, StrScreenShotTCName)));
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Control Number Existence Is Verified");
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "enable", "Approve Button On Approve Transaction Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Deny(driver), "enable", "Deny Button On Approve Transaction Page", 0);
			
			
			filtertext1 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext1, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_02,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_02 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Not Visible Verification "+" "+StrControlNumber_RMA_TC_078_02, StrScreenShotTCName)));

			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_ShowAllTransWinthinMyAuthority(driver), "check", "Show All Transactions Within My Authority Checkbox ", "Approve Transaction Page", 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Reloaded");

			filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_01,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_01 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Verification "+" "+StrControlNumber_RMA_TC_078_01, StrScreenShotTCName)));
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Control Number Existence Is Verified");
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "enable", "Approve Button On Approve Transaction Page ", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Deny(driver), "enable", "Deny Button On Approve Transaction Page ", 0);

			filtertext1 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext1, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_01,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_02 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Verification "+" "+StrControlNumber_RMA_TC_078_02, StrScreenShotTCName)));
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Control Number Existence Is Verified");
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "enable", "Approve Button On Approve Transaction Page ", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Deny(driver), "enable", "Deny Button On Approve Transaction Page ", 0);

			filtertext2 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext2, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_03,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_03 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Not Visible Verification "+" "+StrControlNumber_RMA_TC_078_03, StrScreenShotTCName)));

			//********************************Usera1 Is Logged out and Userq2 is Logged In Into Applcation****************************************************
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);
			driver.switchTo().parentFrame(); // A Switch To The Parent Web Frame Is Made
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Lnk_LogOut(driver), "LogOut Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			//Application Is Logged Out

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_UserName(driver), "UserName Text Box On RMA Application Login Page", StrUserq2,0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Txt_PassWord(driver), "Password Text Box On RMA Application Login Page", StrUserq2,0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Login_DSNSelect_Frames.RMAApp_Login_Btn_Login(driver), "LogIn Link On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Application Is Being Logged In");
			// Application Is Logged In

			LoginUserNameActual = RMA_Selenium_POM_Home.RMAApp_DefaultView_LoginUserName(driver).getText();
			RMA_Verification_Utility.RMA_TextCompare(StrUserq2, LoginUserNameActual, "UserName", 0);
			// Correct User- Userq2- Is Logged In Verification Is Done
			//*****************************************************************************************************************************************************

			//********************************************Reserve Approval For Expense Reserves Created By User Usercsc, Userq1 And Userb1, Is Verified Below By Logged In Usera1 ***********************************
			driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver));
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,14), "Funds-->Reserve Approval Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Reserve Approval Page Is Loaded");

			driver.switchTo().frame(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Frm_ResApproval(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Reserve Approval Frame Is Done");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_02, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_02+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 170 Verification", StrScreenShotTCName)));
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "enable", "Approve Selected Button On Reserve Approval Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "enable", "Reject Selected Button On Reserve Approval Page", 0);


			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_01, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_01+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 111 Not Visisble Verification", StrScreenShotTCName)));

			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Chk_ShowAllTransactionWithinMyAuthority(driver), "check", "Show All Transaction Within My Authority", "Reserve Approval Page", 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Records In Reserve NgGrid Is Reloaded");
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_01, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_01+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 111 Visible Verification", StrScreenShotTCName)));
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "enable", "Approve Selected Button On Reserve Approval Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "enable", "Reject Selected Button On Reserve Approval Page", 0);

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_02, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_1)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_02+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 170 Visible Verification", StrScreenShotTCName)));
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_ApprSelected(driver), "enable", "Approve Selected Button On Reserve Approval Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Btn_RjctSelected(driver), "enable", "Reject Selected Button On Reserve Approval Page", 0);

			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 2, "input"), "Claim Number TextBox On Funds-->ReserveApproval Test NG Grid", StrClaimNumber_RMA_TC_078_03, 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 4, "input"), "Reserve Type Code TextBox On Funds-->ReserveApproval Test NG Grid", "Expense", 0);
			RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApproval(driver, 5, "input"), "Reserve Amount TextBox On Funds-->ReserveApproval Test NG Grid", String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_2), 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Records In Reserve NgGrid Is Filtered");
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ResApprove.RMAApp_ResApprove_Tbl_ResApprovalNG(driver, 5, "span"), "Expense Reserve Of Amount:"+" "+String.valueOf(RMAApp_ReserveCreation_Txt_ExpReserveAmount_2)+" "+"For Claim :"+" "+StrClaimNumber_RMA_TC_078_03+" "+"In Reserve Apprival Grid",0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Expense Reserve 250 Not Visisble Verification", StrScreenShotTCName)));
			//********************************* Reserve Approval Verification Is Completed Here ********************************************

			//******************Following Code Is To Verify Hold Transactions By Logged In User Usera1***************************************

			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);		
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,2), "Funds-->Approve Transactions Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Funds-->Approve Transactions Page Is Loaded");
			driver.switchTo().frame(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Frm_ApproveTransact(driver));
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Switch To Funds-->Approve Transactions Frame Is Done");
			//A Switch To The Frame Containing Funds-->Approve Transactions Page Is Done

			filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_02,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_02 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Verification "+" "+StrControlNumber_RMA_TC_078_02, StrScreenShotTCName)));
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Control Number Existence Is Verified");
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "enable", "Approve Button On Approve Transaction Page", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Deny(driver), "enable", "Deny Button On Approve Transaction Page", 0);
			
			filtertext1 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext1, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_01,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_01 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Not Visible Verification "+" "+StrControlNumber_RMA_TC_078_01, StrScreenShotTCName)));

			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_ShowAllTransWinthinMyAuthority(driver), "check", "Show All Transactions Within My Authority Checkbox ", "Approve Transaction Page", 0);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Reloaded");

			filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_01,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_01 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Verification "+" "+StrControlNumber_RMA_TC_078_01, StrScreenShotTCName)));
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Control Number Existence Is Verified");
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "enable", "Approve Button On Approve Transaction Page ", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Deny(driver), "enable", "Deny Button On Approve Transaction Page ", 0);

			filtertext1 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext1, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_01,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_02 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Verification "+" "+StrControlNumber_RMA_TC_078_02, StrScreenShotTCName)));
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Control Number Existence Is Verified");
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "enable", "Approve Button On Approve Transaction Page ", 0);
			RMA_Verification_Utility.RMA_EnbDisbStateVerify_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Deny(driver), "enable", "Deny Button On Approve Transaction Page ", 0);

			filtertext2 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext2, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_078_03,0);	
			RMA_GenericUsages_Utility.RMA_StaticWait(3, 1, "Wait Is Added As Payment Approval Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
			ObjDescription = "Control Number :" +" " + StrControlNumber_RMA_TC_078_03 +" " +"In Payment Approval Table On Approve Transactions Page";
			RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 0);
			parentlogger.log(LogStatus.INFO, parentlogger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "Control Number Not Visible Verification "+" "+StrControlNumber_RMA_TC_078_03, StrScreenShotTCName)));

			//******************************************Following Code Is To Revert  Settings On Payment Parameter SetUp Page *****************************************************
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(4, 0, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
			driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Event Creation Controls IS Done
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",0);
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "uncheck", "Payment Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayDetailLimitExceed(driver), "uncheck", "Payment Detail Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Payment Detail Limits Are Exceeded Check Box Is UnChecked on Payment Parameter Setup Page		
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "uncheck", "Supervisory Approval Check Box", "Payment Parameter Setup Page",0);      // Supervisory Approval CheckBox Is Checked On Payment Parameter Set Up Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "uncheck", "Notify Immediate Supervisor Check Box", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "uncheck", "Reserve Limits Are Exceeded Check Box", "Payment Parameter Setup Page",0);   // Reserve Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "uncheck", "Notify Immediate Supervisor Check Box For Reserves", "Payment Parameter Setup",0); //Notify Immediate SuperVisor Check Box For reserves Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "uncheck", "Supervisory Approval Check Box For Reserves", "Payment Parameter Setup",0); //Supervisory Approval CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "uncheck", "Incurred Limits Are Exceeded Check Box For Reserves", "Payment Parameter Setup",0); //Incurred Limits Are Exceeded CheckBox For Reserves Check Box Is UnChecked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApprove(driver), "uncheck", "Allow The Group Of Supervisor To Approve  Check Box For Payment ", "Payment Parameter Setup",0); //Allow The Group Of Supervisor To Approve CheckBox For Payemnt For Reserves Check Box Is Checked on Payment Parameter Setup Page
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApproveReserve(driver), "uncheck", "Allow The Group Of Supervisor To Approve Check Box For Reserve", "Payment Parameter Setup",0); //Incurred Limits Are Exceeded CheckBox For Reserves Check Box Is Checked on Payment Parameter Setup Page

			RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver).click(); //Save image is clicked		
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 0, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");

			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "deselect", "Payment Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayDetailLimitExceed(driver), "deselect", "Payment Detail Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "deselect", "Notify Immediate Supervisor Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "deselect", "Supervisory Approval Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "deselect", "Notify Immediate SuperVisor For Reserves Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "deselect", "Use SuperVisory Approval For Reserves Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "deselect", "Reserve Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "deselect", "Incurred Limits Are Exceeded Check Box",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApprove(driver), "deselect", "Allow The Group Of Supervisor To Approve CheckBox For Payment",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApproveReserve(driver), "deselect", "Allow The Group Of Supervisor To Approve Check Box For Reserve",0);
			//**************************Payment Parameter Setup Setiing Is Completed Here **********************************************************************************************

			//**************************************Following Code Is To Revert User Privileges Setting********************************************************************
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(0);
			StrPrimaryWindowHandle = driver.getWindowHandle();			
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8), "Security Menu Option", 0);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8,5), "Security-->User Privileges SetUp Menu Option", 0);
			RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains User Privileges Set Up Page Is Done
			driver.manage().window().maximize();		
			RMA_Input_Utility.RMA_ElementWebListSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrev_Lst_LOB(driver), RMAApp_UserPrev_Lst_LOB,"LineOfBusiness List Box","RISKMASTER User-Privileges SetUp Page",0);
			RMA_Navigation_Utility.RMA_WebPartialLinkSelect("Reserve Limits", "User Privilege Page", 0);		
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "uncheck", "Enable Reserve Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Reserve Limits Tab",0);
			//Enable Reserve Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is UnChecked
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Reserve Limits CheckBox On RMA Application User Privilege SetUp Page's Reserve Limits Tab Is Checked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_EnableReserveLimits(driver), "deselect", "Enable Reserve Limits CheckBox",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevReserve_Chk_RestUnspcfdUsers(driver), "deselect", "Restrict Unspecified Users CheckBox",0);

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Tab_PymntLimit(driver), "Payment Limits Tab On RMA Application's User-Privileges SetUp Page",0); 
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Payment Limits Tab On RMA Application's User-Privileges SetUp Page Is Clicked");
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "uncheck", "Enable Payment Limits CheckBox",  "RMA Application's User Privileges SetUp Page's Payment Limits Tab",0);
			//Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is UnChecked
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 0, "Wait Is Added As Enable Payment Limits CheckBox On RMA Application User Privilege SetUp Page's Payment Limits Tab Is Checked");
			RMA_GenericUsages_Utility.RMA_WindowsMessageHandler_Utility(driver, StrAccept); //Windows Pop Up Dialog Is Accepted
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_EnbPymntLmt(driver), "deselect", "Enable Payment Limits CheckBox",0);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_UserPrivilegesSetUp.RMAApp_UserPrevPymntLimit_Chk_RstUnspecifiedUsr(driver), "deselect", "Restrict Unspecified Users CheckBox",0);
			driver.close();
			driver.switchTo().window(StrPrimaryWindowHandle);
			// ***************************Code To Revert User Privileges Setup Settings Is Completed Here ******************************************************************************************************

		} catch (Exception|Error e) {

			ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
			ErrorMessageType = e.toString();
			if (ExceptionRecorded.contains("Command"))
			{
				ErrorMessage = ExceptionRecorded.split("Command");
				FinalErrorMessage = ErrorMessage[0];
			}
			else
			{
				FinalErrorMessage = ExceptionRecorded;
			}
			if (testcall1 == true && loggerval1.equalsIgnoreCase("NotInitialized"))				
			{
				logger.log(LogStatus.FAIL, "Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Executing Test Case" +" "+ "RMA_TC_004: GeneralClaim Creation" + " " +  "And Hence The Test Case Is A Fail");
				parentlogger.appendChild(logger);
			}
			else if ((testcall2 == true) && (loggerval2.equalsIgnoreCase("NotInitialized")))
			{
				logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Expense Reserve Of $111"  + " " +  "And Hence Reserve Creation Was Not Successful");
				parentlogger.appendChild(logger);
			}

			else if ((testcall3 == true) && (loggerval3.equalsIgnoreCase("NotInitialized")))
			{
				logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Payment of $25"  + " " +  "And Hence Payment Was Not Successful");
				parentlogger.appendChild(logger);
			}

			else if ((testcall4 == true) && (loggerval4.equalsIgnoreCase("NotInitialized")))
			{
				logger.log(LogStatus.FAIL, "Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Executing Test Case" +" "+ "RMA_TC_004: GeneralClaim Creation" + " " +  "And Hence The Test Case Is A Fail");
				parentlogger.appendChild(logger);
			}		
			else if ((testcall5 == true) && (loggerval5.equalsIgnoreCase("NotInitialized")))
			{
				logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Expense Reserve Of $170"  + " " +  "And Hence Reserve Creation Was Not Successful");
				parentlogger.appendChild(logger);
			}
			else if ((testcall6 == true) && (loggerval6.equalsIgnoreCase("NotInitialized")))
			{
				logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Payment of $35"  + " " +  "And Hence Payment Was Not Successful");
				parentlogger.appendChild(logger);
			}
			else if (testcall7 == true && loggerval7.equalsIgnoreCase("NotInitialized"))				
			{
				logger.log(LogStatus.FAIL, "Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Executing Test Case" +" "+ "RMA_TC_004: GeneralClaim Creation" + " " +  "And Hence The Test Case Is A Fail");
				parentlogger.appendChild(logger);
			}
			else if ((testcall8 == true) && (loggerval8.equalsIgnoreCase("NotInitialized")))
			{
				logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Expense Reserve Of $250"  + " " +  "And Hence Reserve Creation Was Not Successful");
				parentlogger.appendChild(logger);
			}

			else if ((testcall9 == true) && (loggerval9.equalsIgnoreCase("NotInitialized")))
			{
				logger.log(LogStatus.FAIL,"Following Error Occurred  ::" + " "+  color.RMA_ChangeColor_Utility(FinalErrorMessage,1)+ " " + "While Creating Payment of $55"  + " " +  "And Hence Payment Was Not Successful");
				parentlogger.appendChild(logger);
			}

			throw (e);
		}
	}

	@AfterMethod
	public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
	{
		try {

			String TestCaseName;

			if (ITestResult.FAILURE == result.getStatus())
			{
				TestCaseName = result.getName();
				RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,0);
			}
			reports.endTest(parentlogger);
		} catch (Exception |Error e) {
			throw (e);
		}
	}
}

