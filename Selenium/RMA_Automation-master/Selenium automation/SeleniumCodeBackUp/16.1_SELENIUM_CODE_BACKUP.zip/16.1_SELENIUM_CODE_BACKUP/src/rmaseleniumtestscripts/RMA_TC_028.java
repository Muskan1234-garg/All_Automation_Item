package rmaseleniumtestscripts;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentParameterSetUp;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed 

/*================================================================================================
TestCaseID     : RMA_TC_028
Description    : Verify that chain of  login user with jump Fuctionality can be  chosen in Payment Parameter Setup.
Depends On TC  : None
Revision       : 0.0 - ImteyazAhmad-01-14-2016
================================================================================================= */

public class RMA_TC_028 extends RMA_TC_BaseTest{

	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;	

	@Test
	public void RMA_TC_028_Test() throws Exception,Error
	{
		try{

			logger = reports.startTest("TC_028_Login User With Jump Functionality"," Verify that chain of  login user with jump Fuctionality can be  chosen in Payment Parameter Setup.");
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option", 1); //Utilities is clicked 
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameter Setup Menu Option", 1);  //System Parameter Setup is clicked 
			RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Payment Parameter Setup Menu Option", 1);// Payment Parameter Setup is clicked
			Thread.sleep(4000);
			driver.switchTo().frame(RMA_GenericUsages_Utility.RMA_FrameNavigation("ParameterSetupPayment")); //Switched to Payment Parameter Frame
			Thread.sleep(2000);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "Supervisor Approval Configuration Tab On Payment Parameter Setup", 1); //Supervisor Approval Configuration tab is clicked on Payment Parameter Setup
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "check", "Payment Limits are exceeded CheckBox ", "Payment Parameter Setup",1);   // Checkbox "Payment Limits are exceeded" is checked on Payment Parameter Setup
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "check", "Supervisor Approval CheckBox", "Payment Parameter Setup",1);  // Checkbox "Supervisor Approval" is checked on Payment Parameter Setup
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseCurrentAdjuster(driver), "uncheck", "Use Current Adjuster Supervisory Chain CheckBox", "Payment Parameter Setup",1); //Checkbox "Use Current Adjuster Chain " is checked on Payment Parameter Setup
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtDiary(driver), "check", "Enable Payment Approval Diary CheckBox ", "Payment Parameter Setup",1); //Checkbox "Enable Payment Approval Diary " is checked on Payment Parameter Setup
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtEmail(driver), "check", "Enable Payment Approval Email CheckBox", "Payment Parameter Setup",1); //Checkbox "Enable Payment Approval Email " is checked on Payment Parameter Setup
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "uncheck", "Notify Immediate Supervisor CheckBox", "Payment Parameter Setup",1); //Checkbox "Enable Payment Approval Email " is unchecked on Payment Parameter Setup
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver), "Save Image On Payment Parameter Setup", 1);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Payment Parameter Setup Page is Saved");
			
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "select", "Payment Limits Are Exceeded Check Box",1);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "select", "Supervisory Approval Check Box",1);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseCurrentAdjuster(driver), "deselect", "Use Current Adjuster SuperVisory Chain Check Box",1);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtDiary(driver), "select", "Enable Payment Approval Diary Check Box",1);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtEmail(driver), "select", "Enable Payment Approval Email Check Box",1);
			RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "deselect", "Notify Immediate Supervisor Check Box",1);
			logger.log(LogStatus.PASS, "Chain of  Login User with jump Fuctionality is chosen successfully in Payment Parameter Setup ");

		}catch(Exception|Error e)		
		{	

			ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
			ErrorMessageType = e.toString();
			if (ExceptionRecorded.contains("Command"))
			{
				ErrorMessage = ExceptionRecorded.split("Command");
				FinalErrorMessage = ErrorMessage[0];
			}
			else
			{
				FinalErrorMessage = ExceptionRecorded;
			}
			throw (e);	
		}
	}

	@AfterMethod
	public void RMA_FailureReport(ITestResult result) throws Exception,Error //All The Information Associated With The Test Case Is Stored In Result Variable
	{
		try {

			String StrScreenShotTCName;
			String TestCaseName;
			StrScreenShotTCName = "TC_028";

			if (ITestResult.FAILURE == result.getStatus())
			{
				TestCaseName = result.getName();
				RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1);
			}
			reports.endTest(logger);
		} catch (Exception|Error e) {
			throw (e);
		}
	}
}
