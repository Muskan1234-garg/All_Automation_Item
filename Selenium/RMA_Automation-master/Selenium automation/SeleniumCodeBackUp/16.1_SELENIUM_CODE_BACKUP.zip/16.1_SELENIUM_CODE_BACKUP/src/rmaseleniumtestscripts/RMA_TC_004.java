package rmaseleniumtestscripts;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumPOM.RMA_Selenium_POM_Document_GeneralClaims;
import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_NegativeVerification_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
// RMA Package Import Completed

//================================================================================================
//TestCaseID   	 : RMA_TC_004
//Description    : Successful General Claim Creation Is Validated
//Depends On TC  : None
//Revision       : 0.0 - KumudNaithani-10-22-2015 
//=================================================================================================
public class RMA_TC_004 extends rmaseleniumtestscripts.RMA_TC_BaseTest
{
static String ExceptionRecorded;
static String []ErrorMessage;
static String FinalErrorMessage;
static String ErrorMessageType;
static String StrEventNumber_RMA_TC_004;
static String StrClaimNumber_RMA_TC_004;

@Test 
public String GeneralClaimCreation() throws Exception, Error
{
	try {
		logger = reports.startTest("TC_004_General Claim Creation", "A New General Claim Is Created");
		String RMAApp_GeneralClaimCreation_Txt_Claimype;
		String RMAApp_GeneralClaimCreation_Txt_DepteId;
		int RMAApp_GeneralClaimCreation_Txt_TimeOfEvent;
		int RMAApp_GeneralClaimCreation_Txt_DateOfClaim;
		int RMAApp_GeneralClaimCreation_Txt_TimeOfClaim;
		int RMAApp_GeneralClaimCreation_Txt_DateOfEvent;
		String StrPrimaryWindowHandle;
		//Local Variable Declaration
		
		//String EventNumber = RMA_TC_003.StrEventNumber_RMA_TC_003;
		//logger.log(LogStatus.INFO, "Event Number Generated In Test Case RMA_TC_003 Is::" + " " + EventNumber);
		RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMASeleniumAutomationTestData.xlsx"); //Excel WorkBook RMASeleniumAutomationTestData IS Fetched To Retrieve Data 
		RMAApp_GeneralClaimCreation_Txt_Claimype = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_004", 1, 0); //ClaimType Is Fetched From DataSheet RMA_TC_004
		RMAApp_GeneralClaimCreation_Txt_DepteId = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_004", 1, 6); //Department Id Is Fetched From DataSheet RMA_TC_004
		RMAApp_GeneralClaimCreation_Txt_TimeOfEvent = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_004", 1, 2); //TimeOfEvent Is Fetched From DataSheet RMA_TC_004
		RMAApp_GeneralClaimCreation_Txt_DateOfClaim = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_004", 1, 4); //DateOfReporting Is Fetched From DataSheet RMA_TC_004
		RMAApp_GeneralClaimCreation_Txt_TimeOfClaim = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_004", 1, 5); //TimeOfReporting Is Fetched From DataSheet RMA_TC_004
		RMAApp_GeneralClaimCreation_Txt_DateOfEvent = ExcelData.RMA_ExcelNumberDataRead_Utility("RMA_TC_004", 1, 1); //DateOfEvent Is Fetched From DataSheer RMA_TC_004		
		
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1); //Web Page Is Refreshed
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 1), "Document Menu Option Is Clicked On RISKMASTER Default View Page",1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 1, 2), "Document-->General Claim Menu Option Is Clicked On RISKMASTER Default View Page",1);
		Thread.sleep(4000);
		
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_GeneralClaim(driver)); //A Switch To The Frame Containing General Claim Creation Controls IS Done
		RMA_Input_Utility.RMA_SetTextValueandTabOut_Utility(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_Dept_Id(driver), "DeptId TextBox On General Claim Creation Page", RMAApp_GeneralClaimCreation_Txt_DepteId,1);
		Thread.sleep(5000);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_TimeOfEvent(driver), "TimeOfEvent TextBox On General Claim Creation Page", String.valueOf(RMAApp_GeneralClaimCreation_Txt_TimeOfEvent),1);		
		
		StrPrimaryWindowHandle = driver.getWindowHandle();
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Img_ClaimStatusSrchBtn(driver), "Claim Status Search Button On RMA Application General Claim Creation Page",1);
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility(); //Switch To The Window Which Contains Claim Status Link Is Done
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Lnk_Open(driver), "Open Link On RMA Application's General Claim Status Selection Page",1);
		
		Thread.sleep(7000);
		driver.switchTo().window(StrPrimaryWindowHandle);
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver)); //A Switch To The Frame Containing RMA Application Menu Option Is Done
		driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_GeneralClaim(driver)); //A Switch To The Frame Containing General Claim Creation Controls IS Done
		
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_DateOfClaim(driver), "DateOfClaim TextBox On GeneralClaim Creation Page", String.valueOf(RMAApp_GeneralClaimCreation_Txt_DateOfClaim),1);
		RMA_Input_Utility.RMA_SetTextValueandTabOut_Utility(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_ClaimType(driver), "Claim Type TextBox On General Claim Creation Page", RMAApp_GeneralClaimCreation_Txt_Claimype,1);
		Thread.sleep(5000);
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_TimeOfClaim(driver), "TimeOfClaim TextBox On GeneralClaim Creation Page", String.valueOf(RMAApp_GeneralClaimCreation_Txt_TimeOfClaim),1);	
		RMA_Input_Utility.RMA_SetValue_Utility(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_DateOfEvent(driver), "DateOfEvent TextBox On General Claim Creation Page", String.valueOf(RMAApp_GeneralClaimCreation_Txt_DateOfEvent),1);	
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Btn_Save(driver), "Save Button Is Clicked On General Claim Creation Page",1);		
		
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Home.RMAApp_DefaultView_Err_StaticErrorText(driver), "RMA Application Error Message",1);
		StrEventNumber_RMA_TC_004 = RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_EventNumber(driver).getAttribute("value"); //Value Of the Generated Event Number Is Fetched In The Variable StrEventNumber
		StrClaimNumber_RMA_TC_004 = RMA_Selenium_POM_Document_GeneralClaims.RMAApp_GeneralClaim_Txt_ClaimNumber(driver).getAttribute("value"); //Value Of the Generated Claim Number Is Fetched In The Variable StrClaimNumber
		String StrlogClaimNumber_RMA_TC_004 = color.RMA_ChangeColor_Utility(StrClaimNumber_RMA_TC_004, 2);
		String StrlogEventNumber_RMA_TC_004 = color.RMA_ChangeColor_Utility(StrEventNumber_RMA_TC_004, 2);
		
		logger.log(LogStatus.PASS, "Claim Creation Is Successful And Generated Claim And Event Number Are Respectively" + " " + "::"+ " "+ StrlogClaimNumber_RMA_TC_004 +" " + "And" + " " + StrlogEventNumber_RMA_TC_004);		
				
		RMA_ExcelDataRetrieval_Utility.WriteDataToExcel(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMASeleniumAutomationTestData.xlsx","RMA_TC_004",10, 0, StrEventNumber_RMA_TC_004);
		logger.log(LogStatus.INFO, "Generated Event Number:" +  " " + StrlogEventNumber_RMA_TC_004 + " "  + "Is Also Written In The Corresponding Excel Data Sheet RMA_TC_004");
		
		RMA_ExcelDataRetrieval_Utility.WriteDataToExcel(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMASeleniumAutomationTestData.xlsx","RMA_TC_004", 10, 1, StrClaimNumber_RMA_TC_004);
		logger.log(LogStatus.INFO, "Generated Claim Number:" + " " + StrlogClaimNumber_RMA_TC_004 + " " + "Is Also Written In The Corresponding Excel Data Sheet RMA_TC_004");
		
		driver.switchTo().parentFrame(); //A Switch To The Parent Frame That Contains Menu Options And Left Hand Navigation Tree Is Done
		return StrClaimNumber_RMA_TC_004;
		
	} catch (Exception|Error e) {
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		throw (e);
	}
	}
	
@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String StrScreenShotTCName = "RMA_TC_004";
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1 );
		}
		reports.endTest(logger);
	} catch (Exception|Error e) {
		throw (e);
	}
}
}