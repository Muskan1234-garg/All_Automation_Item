package rmaseleniumtestscripts;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;

public class Test1  extends RMA_TC_BaseTest {



	@Test

	public void table () throws Exception,Error



	{
		try{
			
			logger = reports.startTest("test started", "description");
			
			//Thread.sleep(10000);

			String text2 = "Claim:440C27352601";
			
			//driver.switchTo().parentFrame();
			driver.switchTo().frame(RMA_Selenium_POM_Home.RMAApp_DefaultView_Frm_MenuOptionFrame(driver)); 
			
			//RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8).click();
			
			//RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 8, 5).click();
			
			
			
			//WebElement x1 = driver.findElement(By.tagName("iframe"));
			
			//System.out.println(x1.getAttribute("id"));    
			
			driver.switchTo().frame(driver.findElement(By.id("DiarieszDiaryListDiaryListDiary ListUI/Diaries/Diary ListFalseFalse")));
			
			
			//driver.switchTo().frame(driver.findElement(By.id("DiarieszDiaryListDiaryListDiary ListUI/Diaries/Diary ListFalseFalse")));
			
			//driver.switchTo().frame(1);
			
			//driver.findElement(By.id("chkActiveDiaryChecked")).click();
			
		

			WebElement Element = driver.findElement(By.id("lstDiary_ctl00"));
			
		Thread.sleep(6000);
		
		RMA_GenericUsages_Utility.RMA_WindowSwitching_Utility();
			
		//Thread.sleep(6000);
			//WebElement Element = driver.findElement(By.id("ReserveLimitsGrid_gvData_ctl00"));
			
			
			RMA_Navigation_Utility.RMA_SelectWTObjectByValue_Utility(Element, text2, "WebCheckbox");
			
			
			
			
			

			/*List<WebElement> tableRows = Element.findElements(By.tagName("tr"));

			outerloop:
				for (int i=0; i<= tableRows.size()-1; i++)

				{
					List<WebElement> tablecol = tableRows.get(i).findElements(By.tagName("td"));
                    System.out.println("The size is " +tablecol.size());
					for (int j =0; j<=tablecol.size()-1;j++)

					{

						String text = tablecol.get(j).getText();	
                        System.out.println(text);
						if (text.equalsIgnoreCase(text2)) 

						{
	                     System.out.println(text);
							tablecol.get(0).click();

							break outerloop;

						}



					}


				}   */




			
			
			
			
			
			
			
			
			
			
			
			
			
			

			
		
		
		}catch(Exception e)

		{System.out.println(e.getMessage() +"and " + e.toString());

		reports.endTest(logger);
		throw (e);







		}
		reports.endTest(logger);}     

		}
