package rmaseleniumtestscripts;

import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
//import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
import rmaseleniumPOM.RMA_Selenium_POM_Funds_ApproveTransactions;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_014
//Description    : Listing Of Transactions Created In RMA_TC_013 In Pending Transaction's Submitted Column Under Current Adjuster's Hierarchy Having  Sufficient Limits To Approve Is Validated. 
//Depends On TC  : TC_011, TC_012, TC_013
//Revision       : 0.0 - KumudNaithani-12-21-2015 
//=================================================================================================
public class RMA_TC_014 extends rmaseleniumtestscripts.RMA_TC_BaseTest {
	public static String ExceptionRecorded;
	public static String []ErrorMessage;
	public static String FinalErrorMessage;
	public static String ErrorMessageType;
	
	
@Test 
public void RMA_TC_014_Test () throws Exception, Error 
//Listing Of Transactions Created In RMA_TC_013 In Pending Transaction's Submitted Column Under Current Adjuster's Hierarchy Having  Sufficient Limits To Approve Is Validated. 	
{
	try {
		logger = reports.startTest("TC_014_Listing Of Transactions In Submitted Pending Transactions", "Listing Of Transactions In Submitted Pending Transactions Under Current Adjuster's Hierarchy Having  Sufficient Limits To Approve Is Validated");
		
		String StrExpSubmittedVal;
		//Local Variable Declaration
		
		StrExpSubmittedVal = "curradj";
		//RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMASeleniumAutomationTestData.xlsx"); //Excel WorkBook RMASeleniumAutomationTestData IS Fetched To Retrieve Data 
		//String StrControlNumber_RMA_TC_013 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_006", 10, 0); //Payment Control Number Is Fetched From Data Sheet RMA_TC_006
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,2), "Funds-->Approve Transactions Menu Option On RMA Application Default View Page",1);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 1, "Wait Is Added As Funds-->Approve Transactions Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Frm_ApproveTransact(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As A Switch To Funds-->Approve Transactions Frame Is Done");
		//A Switch To The Frame Containing Funds-->Approve Transactions Page Is Done
		
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_ShowMyPendingTransact(driver), "check", " Show My Pending Transactions CheckBox", "Approve Transactions Page",1);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As My Pending Funds Transactions Table Is Getting Loaded");
		WebElement filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PendingTransactions(driver,2,"input");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", RMA_TC_013.StrControlNumber_RMA_TC_013,1);	
		//RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_013,1);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As My Pending Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number");
		//My Pending Funds Transactions Table Is Filtered On The Basis Of The Provided Control Number
		
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Lst_PendingTransactCol(driver), "Columns List Of My Pending Transactions Table", 1);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_TransactDate(driver), "uncheck", "TransDate CheckBox", "Columns List Of My Pending Transactions Table", 1);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_PrimClaimant(driver), "uncheck", "Primary Claimant CheckBox", "Columns List Of My Pending Transactions Table", 1);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_Amt(driver), "uncheck", "Amount CheckBox", "Columns List Of My Pending Transactions Table", 1);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_Payee(driver), "uncheck", "Payee CheckBox", "Columns List Of My Pending Transactions Table", 1);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_Comments(driver), "uncheck", "Comments CheckBox", "Columns List Of My Pending Transactions Table", 1);
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_FromToDate(driver), "uncheck", "From/ToDate CheckBox", "Columns List Of My Pending Transactions Table", 1);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Coulmns To Be Displayed Are Selected");
		//Columns Are Unselected From My Pending Funds Transactions Table
		
		WebElement submittouser = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PendingTransactionsNG(driver,6,"span");
		RMA_Verification_Utility.RMA_FilterNGGridVerify_Utility(StrExpSubmittedVal, "Pending Transaction Table On Approve Transactions Page", submittouser,1);
		
	} catch (Exception|Error e) {
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		throw (e);
	}
	}

@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception,Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String StrScreenShotTCName;
		String TestCaseName;
		StrScreenShotTCName = "TC_014";
		
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1);
		}
		reports.endTest(logger);	
	} catch (Exception|Error e) {
		throw (e);
	}
}
}
