package rmaseleniumtestscripts;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
import rmaseleniumPOM.RMA_Selenium_POM_PaymentParameterSetUp;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_051
//Description    : Chain Of Current Adjuster With Notify Immediate User Functionality Settings In Payment Parameter Set-Up Is Validated
//Depends On TC  : None
//Revision       : 0.0 - KumudNaithani-29-01-2016
//=================================================================================================
public class RMA_TC_051 extends rmaseleniumtestscripts.RMA_TC_BaseTest {
	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;
	static String StrScreenShotTCName;


@Test 
public void RMA_TC_051_Test () throws Exception, Error 
//Verify That Chain Of Current Adjuster With Notify Immediate User Functionality Can Be  Chosen In Payment Parameter Set-Up
{
	try {
		logger = reports.startTest("TC_051_CurrAdjuster Chain With Notify Immediate User Setting", "Chain Of Current Adjuster With Notify Immediate User Functionality Setting In Payment Parameter Set-Up Is Validated");
		
		StrScreenShotTCName = "TC_051";
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10), "Utilities Menu Option On RMA Application Default View Page",1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3), "Utilities-->System Parameters Menu Option On RMA Application Default View Page",1);
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As Payment Parameter Set Up Option Is Not Visible");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 10,3,4), "Utilities-->System Parameters-->Payment Parameter Set Up Menu Option On RMA Application Default View Page",1);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 1, "Wait Is Added As Payment Parameter SetUp Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUp_Frm_PaymentParameterSetUp(driver)); //A Switch To The Frame Containing Event Creation Controls IS Done
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As A Swich To Payment Parameter Frame Is Done");
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Tab_SupervisorApproval(driver), "SuperVisor Approval Configuration Tab On Payment Parameter Set Up Page",1);
		
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As SuperVisor Approval Configuration Tab Is Clicked");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "check", "Payment Limits Are Exceeded Check Box", "Payment Parameter Setup Page",1);   // Payment Limits Are Exceeded Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "check", "Supervisory Approval Check Box", "Payment Parameter Setup Page",1);      // Supervisory Approval CheckBox Is Checked On Payment Parameter Set Up Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseCurrentAdjuster(driver), "check", "Use Current Adjuster SuperVisory Chain Check Box", "Payment Parameter Setup Page",1); //Use Current Adjuster SuperVisory Chain Check Box Is Checked on Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtDiary(driver), "check", "Enable Payment Approval Diary Check Box", "Payment Parameter Setup Page",1); //Enable Payment Approval Diary Check Box Is Checked On Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtEmail(driver), "check", "Enable Payment Approval Email Check Box", "Payment Parameter Setup",1); //Enable Payment Approval Email Check Box Is Checked On Payment Parameter Setup Page
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "check", "Notify Immediate Supervisor Check Box", "Payment Parameter Setup",1); //Immediate SuperVisor Check Box Is Checked on Payment Parameter Setup Page
		RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PaymentParaSetup_Img_Save(driver).click(); //Save image is clicked
		
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Newly Selected Settings On SuperVisor Approval Configuration Tab On Payment Parameter SetUp Page Are Saved");
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayLimitExceed(driver), "select", "Payment Limits Are Exceeded Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SupervisoryApproval(driver), "select", "Supervisory Approval Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseCurrentAdjuster(driver), "select", "Use Current Adjuster SuperVisory Chain Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtDiary(driver), "select", "Enable Payment Approval Diary Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_EnbPmtEmail(driver), "select", "Enable Payment Approval Email Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifyImmSupervisor(driver), "select", "Notify Immediate Supervisor Check Box",1);
		
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayDetailLimitExceed(driver), "deselect", "Pay Detail Limits Are Exceeded Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PayeeNotExist(driver), "deselect", "Payee DoesNot Exist In System Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_PerClaimPayLimitsExceeded(driver), "deselect", "Per Claim Pay Limits Exceeded Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_QueuePayment(driver), "deselect", "Queue Payments Instead Of Placing On Hold Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApprove(driver), "deselect", "Allow The Group Of SuperVisor To Approve Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_ZeroEscalationValue(driver), "deselect", "Consider Zero As Valid Value For Escalation Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_DisbDiaryNotify(driver), "deselect", "Disable Diary Notification To SuperVisor Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_DisbEmailNotify(driver), "deselect", "Disable Email Notification To SuperVisor Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppSearch(driver), "deselect", "Use SuperVisor Approval Search Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_RsvLimitExceed(driver), "deselect", "Reserve Limits Are Exceeded Check Box",1);
		
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseSupAppRsv(driver), "deselect", "Use SuperVisory Approval For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_AllowGrpSupervisorToApproveReserve(driver), "deselect", "Allow The Group Of SuperVisor To Approve For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_ZeroEscalationRsv(driver), "deselect", "Consider Zero As Valid Value For Escalation For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_NotifySupRsv(driver), "deselect", "Notify Immediate SuperVisor For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_UseCurrAdjRsv(driver), "deselect", "Use Current Adjustor SuperVisory Chain For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_DisbEmailSprVsrRes(driver), "deselect", "Disable Email Notification To SuperVisor For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_DisbDiaryNotUnapprovedEntity(driver), "deselect", "Disable Diary Notification For Unapproved Entity Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_DisbDiarySprVsrRes(driver), "deselect", "Disable Email Notification To SuperVisor For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_LssCollecOnHold(driver), "deselect", "Put Collections From LSS On Hold CheckBox Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_IncLmtExceed(driver), "deselect", "Incurred Limits Exceeded For Reserves Check Box",1);
		RMA_Verification_Utility.RMA_SelectDeselecStateVerification_Utility(RMA_Selenium_POM_PaymentParameterSetUp.RMAApp_PmntSetUpSprVsr_Chk_SpecTranTypeCodes(driver), "deselect", "Specific Transaction Type Codes Check Box",1);
	
	
	} catch (Exception|Error e) {
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		throw (e);
	}
}

@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1);
		}
		reports.endTest(logger);
	} catch (Exception |Error e) {
		throw (e);
	}
}
}
