package rmaseleniumtestscripts;

import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Funds_ApproveTransactions;
import rmaseleniumPOM.RMA_Selenium_POM_Home;
//import rmaseleniumutilties.RMA_ExcelDataRetrieval_Utility;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed

/*================================================================================================
TestCaseId     : RMA_TC_030
Description    : Verify transaction is listed in my pending transactions and in submitted to column, listed user should be the one in login user's  hierarchy having  sufficient limits to approve.  
Depends On TC  : TC_011, TC_028 & TC_029
Revision       : 0.0 - ImteyazAhmad-01-18-2016 
================================================================================================= */


public class RMA_TC_030 extends RMA_TC_BaseTest{

	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;	
	String StrExpSubmittedVal_030;

	@Test
	public void RMA_TC_030_Test() throws Exception,Error

	{
		try{

			logger = reports.startTest("TC_030_Listing Of Transactions In Submitted Pending Transactions","Verify transaction is listed in my pending transactions and in submitted to column, listed user should be the one in login user's  hierarchy having  sufficient limits to approve");
			StrExpSubmittedVal_030 = "LoginMgr2";
			//RMA_ExcelDataRetrieval_Utility ExcelData = new RMA_ExcelDataRetrieval_Utility(System.getProperty("user.dir")+"\\RMASeleniumTestDataSheets\\RMASeleniumAutomationTestData.xlsx"); //Excel WorkBook RMASeleniumAutomationTestData IS Fetched To Retrieve Data 
			//String StrControlNumber_RMA_TC_029 = ExcelData.RMA_ExcelStringDataRead_Utility("RMA_TC_006", 10, 0); //Payment Control Number Is Fetched From Data Sheet RMA_TC_006
			RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1);
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",1);// Funds is clicked 
			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,2), "Funds-->Approve Transactions Menu Option On RMA Application Default View Page",1); //Approve Transactions is clicked 
			RMA_GenericUsages_Utility.RMA_StaticWait(4,1,"Wait is added as Funds Approve page is loaded");
			driver.switchTo().frame(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Frm_ApproveTransact(driver));// Switched to Approve Transactions Frame
			RMA_GenericUsages_Utility.RMA_StaticWait(2,1,"Wait is added as switch to Approve Transaction Frame is done"); 
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_ShowMyPendingTransact(driver), "check", " Show My Pending Transactions CheckBox", "Approve Transactions Page",1);  // Show My Pending Transactions CheckBox is checked
			RMA_GenericUsages_Utility.RMA_StaticWait(5,1,"Wait is added as Approve Transaction Table is loaded"); 
			WebElement filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PendingTransactions(driver,2,"input");
			RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", RMA_TC_029.StrControlNum_029,1);	
			//RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On My Pending Funds Transactions Table ", StrControlNumber_RMA_TC_029,1);
			RMA_GenericUsages_Utility.RMA_StaticWait(2,1,"Wait is added As Control Number is Filtered"); 
			

			RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Lst_PendingTransactCol(driver), "Columns List Of My Pending Transactions Table", 1);
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_TransactDate(driver), "uncheck", "TransDate CheckBox", "Columns List Of My Pending Transactions Table", 1);
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_PrimClaimant(driver), "uncheck", "Primary Claimant CheckBox", "Columns List Of My Pending Transactions Table", 1);
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_Amt(driver), "uncheck", "Amount CheckBox", "Columns List Of My Pending Transactions Table", 1);
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_Payee(driver), "uncheck", "Payee CheckBox", "Columns List Of My Pending Transactions Table", 1);
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_Comments(driver), "uncheck", "Comments CheckBox", "Columns List Of My Pending Transactions Table", 1);
			RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_FromToDate(driver), "uncheck", "From/ToDate CheckBox", "Columns List Of My Pending Transactions Table", 1);
			RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Coulmns To Be Displayed Are Selected");
			
			
			WebElement submittouser = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PendingTransactionsNG(driver,6,"span");
			RMA_Verification_Utility.RMA_FilterNGGridVerify_Utility(StrExpSubmittedVal_030, "Pending Transaction Table On Approve Transactions Page", submittouser,1);
			
		}catch(Exception|Error e)

		{	
			ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
			ErrorMessageType = e.toString();
			if (ExceptionRecorded.contains("Command"))
			{
				ErrorMessage = ExceptionRecorded.split("Command");
				FinalErrorMessage = ErrorMessage[0];
			}
			else
			{
				FinalErrorMessage = ExceptionRecorded;
			}
			throw (e);	
		}
	}

	@AfterMethod
	public void RMA_FailureReport(ITestResult result) throws Exception,Error //All The Information Associated With The Test Case Is Stored In Result Variable
	{
		try {

			String StrScreenShotTCName;
			String TestCaseName;
			StrScreenShotTCName = "TC_030";

			if (ITestResult.FAILURE == result.getStatus())
			{
				TestCaseName = result.getName();
				RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1);
			}
			reports.endTest(logger);
		} catch (Exception|Error e) {
			throw (e);
		}
	}
}
