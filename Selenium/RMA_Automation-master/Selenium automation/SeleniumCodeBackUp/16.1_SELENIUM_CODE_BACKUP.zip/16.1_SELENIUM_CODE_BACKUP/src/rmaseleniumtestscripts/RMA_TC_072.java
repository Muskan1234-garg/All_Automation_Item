package rmaseleniumtestscripts;

import org.openqa.selenium.WebElement;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.LogStatus;
//Default Package Import Completed

import rmaseleniumPOM.RMA_Selenium_POM_Funds_ApproveTransactions;
import rmaseleniumPOM.RMA_Selenium_POM_Home;
import rmaseleniumutilties.RMA_ExtentReports_Utility;
import rmaseleniumutilties.RMA_GenericUsages_Utility;
import rmaseleniumutilties.RMA_Input_Utility;
import rmaseleniumutilties.RMA_Navigation_Utility;
import rmaseleniumutilties.RMA_NegativeVerification_Utility;
import rmaseleniumutilties.RMA_ScreenCapture_Utility;
import rmaseleniumutilties.RMA_Verification_Utility;
//RMA Package Import Completed

//================================================================================================
//TestCaseID     : RMA_TC_072
//Description    : Verify user is able to approve the transaction  
//Depends On TC  : TC_064, TC_065 , TC_066 & TC_071
//Revision       : 0.0 - ImteyazAhmad-02-10-2016 
//=================================================================================================

public class RMA_TC_072 extends rmaseleniumtestscripts.RMA_TC_BaseTest {
	static String ExceptionRecorded;
	static String []ErrorMessage;
	static String FinalErrorMessage;
	static String ErrorMessageType;
	static String StrScreenShotTCName;

@Test 
public void RMA_TC_072_Test () throws Exception, Error
{
	try {
		logger = reports.startTest("TC_072_ $2500 Hold Transactions Is Approved By Top Level Manager", "Verify Top Level Manager Is Able To Approve The Transactions");
		
		String ObjDescription;
		WebElement filtertext;
		WebElement filtertext1;
		//Local Variable Declaration
				
		StrScreenShotTCName = "TC_072";
			
		RMA_GenericUsages_Utility.RMA_WebPageRefresh_Utility(1); //Web Page Is Refreshed
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3), "Funds Menu Option On RMA Application Default View Page",1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Home.RMAApp_DefaultView_Mnu_Options(driver, 3,2), "Funds-->Approve Transactions Menu Option On RMA Application Default View Page",1);
		RMA_GenericUsages_Utility.RMA_StaticWait(4, 1, "Wait Is Added As Funds-->Approve Transactions Page Is Loaded");
		driver.switchTo().frame(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Frm_ApproveTransact(driver));
		RMA_GenericUsages_Utility.RMA_StaticWait(2, 1, "Wait Is Added As A Switch To Funds-->Approve Transactions Frame Is Done");
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Chk_ShowAllTransWinthinMyAuthority(driver), "check", "Show All Transactions Within My Authority CheckBox ", " Funds=> Approve Transactions Page", 0);
		RMA_GenericUsages_Utility.RMA_StaticWait(5, 1, "Wait Is Added As Funds-->Approve Transactions Page Is Loaded After Selecting Show All Transactions Within My Authority CheckBox ");
		filtertext = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");		
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext, "Control Number Filter Text Box On Approve Transactions Table", RMA_TC_066.StrControlNumber_RMA_TC_066_01,1);	
		ObjDescription = "Control Number :" +" " + RMA_TC_066.StrControlNumber_RMA_TC_066_01 +" " +"In Payment Approval Table On Approve Transactions Page";
		RMA_Verification_Utility.RMA_ElementExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "$2500 Hold Transaction Listed In Top Level Manager's List", StrScreenShotTCName)));
		RMA_Navigation_Utility.RMA_WebCheckBoxSelect_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 1, "input"), "check", "Header CheckBox", " Funds Transactions Available For Approval Table", 1);
		RMA_Navigation_Utility.RMA_ObjectClick(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Btn_Approve(driver), "Approve Button In Funds Transactions Available For Approval Table", 1);
		RMA_GenericUsages_Utility.RMA_StaticWait(6, 1, "Wait Is Added As Transaction Is Approved");
		filtertext1 = RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApproval(driver, 2, "input");
		RMA_Input_Utility.RMA_SetValue_Utility(filtertext1, "Control Number Filter Text Box On Approve Transactions Table", RMA_TC_066.StrControlNumber_RMA_TC_066_01,1);	//Searched the Same Transaction Again
		ObjDescription = "Control Number :" +" " + RMA_TC_066.StrControlNumber_RMA_TC_066_01 +" " +"In Payment Approval Table On Approve Transactions Page";
		RMA_NegativeVerification_Utility.RMA_ElementNotExist_Utility(RMA_Selenium_POM_Funds_ApproveTransactions.RMAApp_ApproveTrans_Tbl_PaymentApprovalNG(driver, 2, "span"), ObjDescription, 1);
		logger.log(LogStatus.INFO, logger.addScreenCapture(RMA_ScreenCapture_Utility.RMA_ScreenShotCapture_Utility(driver, "$2500 Hold Transaction Approved By Top Level Manager's List", StrScreenShotTCName)));
		//$2500 Transaction Is Approved
				
} catch (Exception|Error e) {
		
		ExceptionRecorded = e.getMessage();	//Try Catch Statement Is Used To Handle Any Type Of Not Handled Exception And Print Log Of It
		ErrorMessageType = e.toString();
		if (ExceptionRecorded.contains("Command"))
		{
		ErrorMessage = ExceptionRecorded.split("Command");
		FinalErrorMessage = ErrorMessage[0];
		}
		else
		{
			FinalErrorMessage = ExceptionRecorded;
		}
		throw (e);
	}
	}

@AfterMethod
public void RMA_FailureReport(ITestResult result) throws Exception, Error //All The Information Associated With The Test Case Is Stored In Result Variable
{
	try {
		String TestCaseName;
		if (ITestResult.FAILURE == result.getStatus())
		{
			TestCaseName = result.getName();
			RMA_ExtentReports_Utility.RMA_ExtentFailureReport(FinalErrorMessage, TestCaseName, StrScreenShotTCName,1);
		}
		reports.endTest(logger);
	} catch (Exception |Error e) {
		throw (e);
	}
}
}
	