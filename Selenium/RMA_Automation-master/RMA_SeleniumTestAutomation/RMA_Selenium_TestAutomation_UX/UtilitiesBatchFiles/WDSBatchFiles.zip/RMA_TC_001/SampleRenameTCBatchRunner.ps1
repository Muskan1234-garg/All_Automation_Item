(Get-Content BPP_TS_7_1_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_1_1_ANT.bat
(Get-Content BPP_TS_7_1_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_1_2_ANT.bat
(Get-Content BPP_TS_7_1_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_1_3_ANT.bat
(Get-Content BPP_TS_7_1_4_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_1_4_ANT.bat

(Get-Content BPP_TS_7_5_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_5_1_ANT.bat
(Get-Content BPP_TS_7_5_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_5_2_ANT.bat
(Get-Content BPP_TS_7_5_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_5_3_ANT.bat

(Get-Content BPP_TS_7_10_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_10_1_ANT.bat
(Get-Content BPP_TS_7_10_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_10_2_ANT.bat
(Get-Content BPP_TS_7_10_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_10_3_ANT.bat

(Get-Content BPP_TS_7_20_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_20_1_ANT.bat
(Get-Content BPP_TS_7_20_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_20_2_ANT.bat
(Get-Content BPP_TS_7_20_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_20_3_ANT.bat

(Get-Content BPP_TS_7_50_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_50_1_ANT.bat
(Get-Content BPP_TS_7_50_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_50_2_ANT.bat
(Get-Content BPP_TS_7_50_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_50_3_ANT.bat

(Get-Content BPP_TS_7_60_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_60_1_ANT.bat
(Get-Content BPP_TS_7_60_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_60_2_ANT.bat
(Get-Content BPP_TS_7_60_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_60_3_ANT.bat

(Get-Content BPP_TS_7_70_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_70_1_ANT.bat
(Get-Content BPP_TS_7_70_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_70_2_ANT.bat
(Get-Content BPP_TS_7_70_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_70_3_ANT.bat

(Get-Content BPP_TS_7_80_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_80_1_ANT.bat
(Get-Content BPP_TS_7_80_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_80_2_ANT.bat
(Get-Content BPP_TS_7_80_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_80_3_ANT.bat

(Get-Content BPP_TS_7_90_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_90_1_ANT.bat
(Get-Content BPP_TS_7_90_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_90_2_ANT.bat
(Get-Content BPP_TS_7_90_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_90_3_ANT.bat

(Get-Content BPP_TS_7_100_1_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_100_1_ANT.bat
(Get-Content BPP_TS_7_100_2_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_100_2_ANT.bat
(Get-Content BPP_TS_7_100_3_ANT.bat) | ForEach-Object { $_ -replace "BPP_TS_6", "BPP_TS_7" } | Set-Content BPP_TS_7_100_3_ANT.bat

