(Get-Content RMA_TC_026_1_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_1_1_ANT.bat
(Get-Content RMA_TC_026_1_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_1_2_ANT.bat
(Get-Content RMA_TC_026_1_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_1_3_ANT.bat
(Get-Content RMA_TC_026_1_4_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_1_4_ANT.bat

(Get-Content RMA_TC_026_5_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_5_1_ANT.bat
(Get-Content RMA_TC_026_5_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_5_2_ANT.bat
(Get-Content RMA_TC_026_5_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_5_3_ANT.bat

(Get-Content RMA_TC_026_10_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_10_1_ANT.bat
(Get-Content RMA_TC_026_10_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_10_2_ANT.bat
(Get-Content RMA_TC_026_10_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_10_3_ANT.bat

(Get-Content RMA_TC_026_20_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_20_1_ANT.bat
(Get-Content RMA_TC_026_20_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_20_2_ANT.bat
(Get-Content RMA_TC_026_20_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_20_3_ANT.bat

(Get-Content RMA_TC_026_50_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_50_1_ANT.bat
(Get-Content RMA_TC_026_50_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_50_2_ANT.bat
(Get-Content RMA_TC_026_50_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_50_3_ANT.bat


(Get-Content RMA_TC_026_100_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_100_1_ANT.bat
(Get-Content RMA_TC_026_100_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_100_2_ANT.bat
(Get-Content RMA_TC_026_100_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_026_18.2", "RMA_TC_026_18.4" } | Set-Content RMA_TC_026_100_3_ANT.bat

