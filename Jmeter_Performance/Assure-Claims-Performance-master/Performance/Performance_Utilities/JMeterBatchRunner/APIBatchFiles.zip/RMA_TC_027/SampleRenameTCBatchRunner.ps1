(Get-Content RMA_TC_027_1_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_1_1_ANT.bat
(Get-Content RMA_TC_027_1_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_1_2_ANT.bat
(Get-Content RMA_TC_027_1_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_1_3_ANT.bat
(Get-Content RMA_TC_027_1_4_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_1_4_ANT.bat

(Get-Content RMA_TC_027_5_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_5_1_ANT.bat
(Get-Content RMA_TC_027_5_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_5_2_ANT.bat
(Get-Content RMA_TC_027_5_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_5_3_ANT.bat

(Get-Content RMA_TC_027_10_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_10_1_ANT.bat
(Get-Content RMA_TC_027_10_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_10_2_ANT.bat
(Get-Content RMA_TC_027_10_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_10_3_ANT.bat

(Get-Content RMA_TC_027_20_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_20_1_ANT.bat
(Get-Content RMA_TC_027_20_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_20_2_ANT.bat
(Get-Content RMA_TC_027_20_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_20_3_ANT.bat

(Get-Content RMA_TC_027_50_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_50_1_ANT.bat
(Get-Content RMA_TC_027_50_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_50_2_ANT.bat
(Get-Content RMA_TC_027_50_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_50_3_ANT.bat


(Get-Content RMA_TC_027_100_1_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_100_1_ANT.bat
(Get-Content RMA_TC_027_100_2_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_100_2_ANT.bat
(Get-Content RMA_TC_027_100_3_ANT.bat) | ForEach-Object { $_ -replace "RMA_TC_027_18.2", "RMA_TC_027_18.4" } | Set-Content RMA_TC_027_100_3_ANT.bat

